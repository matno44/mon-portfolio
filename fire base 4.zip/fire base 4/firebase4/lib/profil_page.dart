import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';

import 'image_picture.dart';
import 'profil_text_section.dart';
import 'widgets.dart';

/// Application affichée quand un utilisateur est connecté (voir main.dart).
class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: ProfilPage(),
    );
  }
}

/// Page de profil : bandeau (photo + pseudo + bio + localisation),
/// modification de la photo et déconnexion.
class ProfilPage extends StatefulWidget {
  const ProfilPage({super.key});

  @override
  State<ProfilPage> createState() => _ProfilPageState();
}

class _ProfilPageState extends State<ProfilPage> {
  /// Photo choisie par l'utilisateur, pas encore envoyée (null = aucune)
  File? _image;

  /// true pendant l'envoi vers Firebase Storage (pour désactiver le bouton)
  bool _isUploading = false;

  /// Numéro de version du bandeau. On l'augmente pour forcer le rechargement de la
  /// photo et des textes : il sert de clé (Key) aux widgets ImagePicture et
  /// ProfilTextSection. Une clé différente = Flutter recrée le widget = initState()
  /// est rappelé = nouvelle requête à Firebase.
  int _refreshVersion = 0;

  /// Recharge le bandeau sans recharger toute la page
  /// (le tutoriel utilisait Navigator.pushReplacement, ce qui est inutile ici).
  void _refreshProfil() {
    setState(() => _refreshVersion++);
  }

  // ---------- 1. Choisir une photo ----------

  /// Ouvre la caméra ou la galerie selon [source], puis stocke la photo dans _image.
  Future<void> pickImage(ImageSource source) async {
    try {
      final XFile? picked = await ImagePicker().pickImage(
        source: source,
        maxWidth: 800, // on réduit la taille : envoi plus rapide, moins de stockage
        imageQuality: 85,
      );

      // L'utilisateur a annulé la sélection : on ne change rien
      if (picked == null) return;

      if (!mounted) return;
      setState(() => _image = File(picked.path));
    } on PlatformException catch (e) {
      // Ex : pas de caméra (simulateur) ou permission refusée
      debugPrint('Erreur image_picker : ${e.code} ${e.message}');
      if (mounted) showMessage(context, 'Impossible d\'accéder à l\'image : ${e.message ?? e.code}');
    }
  }

  /// Menu du bas avec les deux choix : Caméra ou Bibliothèque photo
  void showPickerMenu() {
    showModalBottomSheet<void>(
      context: context,
      builder: (sheetContext) {
        return SafeArea(
          child: Wrap(
            children: [
              ListTile(
                leading: const Icon(Icons.photo_camera),
                title: const Text('Caméra'),
                onTap: () {
                  Navigator.pop(sheetContext); // on ferme le menu avant d'ouvrir la caméra
                  pickImage(ImageSource.camera);
                },
              ),
              ListTile(
                leading: const Icon(Icons.photo_library),
                title: const Text('Bibliothèque photo'),
                onTap: () {
                  Navigator.pop(sheetContext);
                  pickImage(ImageSource.gallery);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  // ---------- 2. Envoyer la photo dans Firebase Storage ----------

  /// Envoie _image dans Firebase Storage à l'adresse Users/{uid}.png
  Future<void> uploadFile() async {
    // On copie les valeurs dans des variables locales : Dart sait alors qu'elles
    // ne sont pas null après le test, sans avoir besoin de "!"
    final image = _image;
    final user = auth.currentUser;
    if (image == null) return;
    if (user == null) {
      showMessage(context, 'Vous devez être connecté pour envoyer une photo');
      return;
    }

    setState(() => _isUploading = true);

    try {
      final Reference ref = profilImageRef(user.uid);

      // putFile() lance l'envoi ; "await" attend qu'il soit complètement terminé
      final UploadTask uploadTask = ref.putFile(
        image,
        SettableMetadata(contentType: _contentType(image.path)),
      );
      await uploadTask;

      if (!mounted) return;
      showMessage(context, 'Photo de profil mise à jour');
      setState(() {
        _image = null; // l'aperçu n'est plus utile
        _refreshVersion++; // la photo du bandeau se recharge
      });
    } on FirebaseException catch (e) {
      // e.message contient le message d'erreur de Firebase (ex : permission refusée)
      debugPrint('Erreur Firebase Storage : ${e.code} ${e.message}');
      if (mounted) showMessage(context, 'Échec de l\'envoi : ${e.message ?? e.code}');
    } finally {
      if (mounted) setState(() => _isUploading = false);
    }
  }

  /// Type MIME du fichier d'après son extension. Le fichier s'appelle toujours
  /// {uid}.png dans Storage, mais on indique le vrai format (souvent du JPEG)
  /// pour que le navigateur ou l'application sache comment l'afficher.
  String _contentType(String path) {
    final extension = path.split('.').last.toLowerCase();
    switch (extension) {
      case 'png':
        return 'image/png';
      case 'heic':
        return 'image/heic';
      case 'webp':
        return 'image/webp';
      default:
        return 'image/jpeg';
    }
  }

  // ---------- Affichage ----------

  @override
  Widget build(BuildContext context) {
    final user = auth.currentUser;

    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: const Text('Page de profil'),
        centerTitle: true,
        backgroundColor: Colors.amber,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Rafraîchir',
            onPressed: _refreshProfil,
          ),
        ],
      ),
      // Normalement impossible (main.dart n'affiche cette page que si l'utilisateur
      // est connecté), mais on évite tout plantage si currentUser est null.
      body: user == null
          ? const Center(child: Text('Aucun utilisateur connecté'))
          : ListView(
              children: [
                _buildHeader(user.uid),
                Padding(
                  padding: const EdgeInsets.all(30),
                  child: _buildPhotoSection(),
                ),
              ],
            ),
    );
  }

  /// Bandeau du haut : dégradé jaune -> orange, photo ronde et textes en blanc
  Widget _buildHeader(String uid) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 30, horizontal: 20),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFFFFD54F), Color(0xFFFF9800)],
        ),
      ),
      child: Column(
        children: [
          ImagePicture(key: ValueKey('photo-$_refreshVersion'), uid: uid),
          const SizedBox(height: 16),
          ProfilTextSection(key: ValueKey('textes-$_refreshVersion'), uid: uid),
        ],
      ),
    );
  }

  /// Partie basse : modifier la photo, aperçu, envoi et déconnexion
  Widget _buildPhotoSection() {
    final image = _image;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        MainButton(
          text: 'Modifier ma photo',
          background: Colors.black,
          foreground: Colors.white,
          onPressed: _isUploading ? null : showPickerMenu,
        ),
        const SizedBox(height: 12),
        const Text(
          'Sélectionnez une image\nPuis enregistrez-la dans Firebase',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.black54, fontSize: 15),
        ),

        // L'aperçu et le bouton d'envoi n'apparaissent qu'une fois une photo choisie
        if (image != null) ...[
          const SizedBox(height: 20),
          Center(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Image.file(image, height: 220, fit: BoxFit.cover),
            ),
          ),
          const SizedBox(height: 20),
          MainButton(
            text: _isUploading ? 'Envoi en cours…' : 'Envoyer dans Firebase',
            background: Colors.orange,
            foreground: Colors.white,
            onPressed: _isUploading ? null : uploadFile,
          ),
        ],

        const SizedBox(height: 40),
        MainButton(
          text: 'DÉCONNEXION',
          background: rouge,
          foreground: Colors.white,
          onPressed: () => auth.signOut(),
        ),
      ],
    );
  }
}
