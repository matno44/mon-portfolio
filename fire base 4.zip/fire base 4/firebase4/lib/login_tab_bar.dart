import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'widgets.dart';

class LoginTabBar extends StatelessWidget {
  const LoginTabBar({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('Firebase Login'),
            centerTitle: true,
            backgroundColor: Colors.amber,
            foregroundColor: Colors.white,
            bottom: const TabBar(
              indicatorColor: rouge,
              labelColor: Colors.white,
              unselectedLabelColor: Colors.white70,
              tabs: [
                Tab(text: 'Connexion'),
                Tab(text: 'Inscription'),
              ],
            ),
          ),
          body: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFFFFD54F), Color(0xFFFF9800), Color(0xFFE65100)],
              ),
            ),
            child: const TabBarView(
              children: [
                LoginSection(),
                SignUpSection(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ---------- Onglet Connexion ----------

class LoginSection extends StatefulWidget {
  const LoginSection({super.key});

  @override
  State<LoginSection> createState() => _LoginSectionState();
}

class _LoginSectionState extends State<LoginSection> {
  final emailField = TextEditingController();
  final passwordField = TextEditingController();

  Future<void> loginToFirebase() async {
    try {
      await auth.signInWithEmailAndPassword(
        email: emailField.text.trim(),
        password: passwordField.text.trim(),
      );
      // Pas besoin de changer de page ici : main.dart écoute authStateChanges()
      // et affiche automatiquement la page de profil.
    } on FirebaseAuthException catch (e) {
      debugPrint(e.toString());
      if (mounted) showMessage(context, 'Connexion impossible : ${e.code}');
    }
  }

  Future<void> resetPassword() async {
    if (emailField.text.trim().isEmpty) {
      showMessage(context, 'Entrez votre adresse email');
      return;
    }
    try {
      await auth.sendPasswordResetEmail(email: emailField.text.trim());
      if (mounted) showMessage(context, 'Email de réinitialisation envoyé');
    } on FirebaseAuthException catch (e) {
      if (mounted) showMessage(context, 'Erreur : ${e.code}');
    }
  }

  @override
  void dispose() {
    emailField.dispose();
    passwordField.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(30),
      children: [
        const LogoSection(),
        const SizedBox(height: 30),
        InputField(controller: emailField, hint: 'Adresse email', icon: Icons.people_outline),
        InputField(controller: passwordField, hint: 'Mot de passe', icon: Icons.lock_outline, obscure: true),
        const SizedBox(height: 10),
        MainButton(text: 'CONNEXION', onPressed: loginToFirebase),
        const SizedBox(height: 20),
        TextButton(
          onPressed: resetPassword,
          child: const Text('Mot de passe oublié ?', style: TextStyle(color: Colors.white)),
        ),
      ],
    );
  }
}

// ---------- Onglet Inscription ----------

class SignUpSection extends StatefulWidget {
  const SignUpSection({super.key});

  @override
  State<SignUpSection> createState() => _SignUpSectionState();
}

class _SignUpSectionState extends State<SignUpSection> {
  final emailField = TextEditingController();
  final passwordField = TextEditingController();
  final pseudoField = TextEditingController();
  final birthdateField = TextEditingController();
  // Nouveaux champs du TP 4, affichés dans le bandeau de la page de profil
  final bioField = TextEditingController();
  final locationField = TextEditingController();

  /// Crée le document Firestore Users/{userID} avec les informations du profil.
  /// En cas d'échec, l'erreur FirebaseException est relancée à l'appelant.
  Future<void> addUser({
    required String userID,
    required String pseudo,
    required String birthdate,
    required String bio,
    required String location,
  }) async {
    await firestore.collection('Users').doc(userID).set({
      'pseudo': pseudo,
      'birthdate': birthdate,
      'bio': bio,
      'location': location,
    });
    debugPrint('Utilisateur ajouté dans Firestore');
  }

  Future<void> signUpToFirebase() async {
    try {
      final credential = await auth.createUserWithEmailAndPassword(
        email: emailField.text.trim(),
        password: passwordField.text.trim(),
      );

      // credential.user peut en théorie être null : on vérifie avant de l'utiliser
      final user = credential.user;
      if (user == null) return;

      await addUser(
        userID: user.uid,
        pseudo: pseudoField.text.trim(),
        birthdate: birthdateField.text.trim(),
        bio: bioField.text.trim(),
        location: locationField.text.trim(),
      );
    } on FirebaseAuthException catch (e) {
      // Erreur d'authentification (email déjà utilisé, mot de passe trop faible…)
      debugPrint(e.toString());
      if (mounted) showMessage(context, 'Inscription impossible : ${e.code}');
    } on FirebaseException catch (e) {
      // Erreur Firestore lors de l'enregistrement du profil
      debugPrint(e.toString());
      if (mounted) showMessage(context, 'Profil non enregistré : ${e.message ?? e.code}');
    }
  }

  // Sélecteur de date pour remplir le champ au format JJ/MM/AAAA
  Future<void> pickBirthdate() async {
    final date = await showDatePicker(
      context: context,
      initialDate: DateTime(2000),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );
    if (date != null) {
      birthdateField.text =
          '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';
    }
  }

  @override
  void dispose() {
    emailField.dispose();
    passwordField.dispose();
    pseudoField.dispose();
    birthdateField.dispose();
    bioField.dispose();
    locationField.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(30),
      children: [
        const Text(
          'Créez-vous un compte',
          textAlign: TextAlign.center,
          style: TextStyle(color: rouge, fontSize: 16, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 30),
        InputField(controller: pseudoField, hint: 'Pseudo', icon: Icons.people_outline),
        InputField(controller: emailField, hint: 'Adresse email', icon: Icons.mail_outline),
        InputField(controller: passwordField, hint: 'Mot de passe', icon: Icons.lock_outline, obscure: true),
        InputField(
          controller: birthdateField,
          hint: 'Date de naissance',
          icon: Icons.calendar_month,
          readOnly: true,
          onTap: pickBirthdate,
        ),
        InputField(controller: bioField, hint: 'Bio', icon: Icons.info_outline),
        InputField(controller: locationField, hint: 'Localisation', icon: Icons.location_on),
        const SizedBox(height: 10),
        MainButton(text: 'INSCRIPTION', onPressed: signUpToFirebase),
      ],
    );
  }
}

// ---------- Logo de l'écran de connexion ----------

class LogoSection extends StatelessWidget {
  const LogoSection({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 130,
          height: 130,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(30),
            boxShadow: [
              BoxShadow(color: Colors.white.withValues(alpha: 0.3), blurRadius: 0, spreadRadius: 15),
            ],
          ),
          child: const Icon(Icons.local_fire_department, size: 90, color: Colors.orange),
        ),
        const SizedBox(height: 35),
        const Text.rich(
          TextSpan(
            style: TextStyle(fontSize: 36, fontWeight: FontWeight.w900),
            children: [
              TextSpan(text: 'Firebase', style: TextStyle(color: Colors.white)),
              TextSpan(text: 'Login', style: TextStyle(color: rouge)),
            ],
          ),
        ),
        const Text(
          'Connectez-vous avec vos identifiants',
          style: TextStyle(color: rouge, fontSize: 14),
        ),
      ],
    );
  }
}
