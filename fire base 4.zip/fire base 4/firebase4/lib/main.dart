import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';

import 'login_tab_bar.dart';
import 'profil_page.dart';
import 'widgets.dart';

/// true  = les photos sont envoyées dans l'émulateur Firebase Storage local
///         (lancé sur le Mac avec : firebase emulators:start --only storage)
/// false = les photos sont envoyées dans le vrai Firebase Storage en ligne
///         (nécessite d'avoir activé Storage, donc le forfait Blaze)
/// L'authentification et Firestore restent toujours ceux du vrai projet Firebase.
const bool useStorageEmulator = true;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  if (useStorageEmulator) {
    // Depuis l'émulateur Android, l'ordinateur hôte s'appelle 10.0.2.2
    // (sur le simulateur iOS ou sur le Mac, c'est simplement localhost).
    final host = defaultTargetPlatform == TargetPlatform.android ? '10.0.2.2' : 'localhost';
    await FirebaseStorage.instance.useStorageEmulator(host, 9199);
  }

  // Redirection : on écoute l'état de connexion et on lance le bon widget
  auth.authStateChanges().listen((User? user) {
    if (user == null) {
      debugPrint('Utilisateur non connecté');
      runApp(const LoginTabBar());
    } else {
      // email peut être null (ex : connexion anonyme) : on évite le "!"
      debugPrint('Utilisateur connecté : ${user.email ?? user.uid}');
      runApp(const HomePage());
    }
  });
}
