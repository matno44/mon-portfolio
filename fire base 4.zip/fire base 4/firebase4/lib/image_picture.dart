import 'package:flutter/material.dart';
import 'package:firebase_storage/firebase_storage.dart';

/// Référence de la photo de profil d'un utilisateur dans Firebase Storage : Users/{uid}.png
/// Cette fonction est utilisée à la fois pour l'envoi (profil_page.dart) et pour
/// la récupération (ci-dessous) : on est sûr d'utiliser exactement le même chemin.
Reference profilImageRef(String uid) {
  return FirebaseStorage.instance.ref('Users').child('$uid.png');
}

/// Photo de profil ronde, avec une bordure blanche.
/// L'URL de téléchargement est récupérée dans initState() via getProfilImage().
/// Si la photo n'existe pas encore (ou en cas d'erreur), on affiche une icône par défaut.
class ImagePicture extends StatefulWidget {
  /// Identifiant de l'utilisateur connecté
  final String uid;

  /// Rayon de la photo (sans la bordure)
  final double radius;

  const ImagePicture({super.key, required this.uid, this.radius = 60});

  @override
  State<ImagePicture> createState() => _ImagePictureState();
}

class _ImagePictureState extends State<ImagePicture> {
  /// URL de la photo ; null = pas de photo (on affiche l'icône par défaut)
  String? _url;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    getProfilImage();
  }

  /// Demande à Firebase Storage l'URL de téléchargement de Users/{uid}.png
  Future<void> getProfilImage() async {
    String? url;
    try {
      final downloadUrl = await profilImageRef(widget.uid).getDownloadURL();

      // Anti-cache : Flutter garde en mémoire les images déjà téléchargées, rangées
      // par URL. Après un nouvel envoi, l'URL peut rester la même et l'ancienne
      // photo resterait affichée. On ajoute donc un paramètre "v" différent à
      // chaque chargement (Firebase l'ignore, mais pour le cache c'est une autre URL).
      url = '$downloadUrl&v=${DateTime.now().millisecondsSinceEpoch}';
    } on FirebaseException catch (e) {
      // 'object-not-found' = l'utilisateur n'a encore jamais envoyé de photo : cas normal
      if (e.code != 'object-not-found') {
        debugPrint('Erreur de récupération de la photo : ${e.message}');
      }
    }

    // Après un await, le widget a pu être retiré de l'écran (déconnexion…)
    if (!mounted) return;
    setState(() {
      _url = url;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final url = _url;

    Widget photo;
    if (_isLoading) {
      photo = CircleAvatar(
        radius: widget.radius,
        backgroundColor: Colors.white24,
        child: const CircularProgressIndicator(color: Colors.white),
      );
    } else if (url == null) {
      photo = _defaultPicture();
    } else {
      photo = CircleAvatar(
        radius: widget.radius,
        backgroundColor: Colors.white24,
        backgroundImage: NetworkImage(url),
        // Si le téléchargement de l'image échoue (réseau, fichier corrompu…),
        // on repasse sur la photo par défaut
        onBackgroundImageError: (error, stackTrace) {
          debugPrint('Impossible d\'afficher la photo : $error');
          if (mounted) setState(() => _url = null);
        },
      );
    }

    // Un CircleAvatar blanc un peu plus grand derrière la photo = bordure blanche
    return CircleAvatar(
      radius: widget.radius + 4,
      backgroundColor: Colors.white,
      child: photo,
    );
  }

  /// Photo de profil par défaut : une simple icône, sans dépendre d'une URL externe
  Widget _defaultPicture() {
    return CircleAvatar(
      radius: widget.radius,
      backgroundColor: Colors.grey.shade300,
      child: Icon(Icons.person, size: widget.radius * 1.2, color: Colors.grey.shade600),
    );
  }
}
