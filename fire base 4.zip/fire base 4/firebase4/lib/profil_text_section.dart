import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'widgets.dart';

/// Textes du bandeau de profil : pseudo (en gras), bio, puis localisation
/// précédée de l'icône Icons.location_on. Tout est écrit en blanc.
class ProfilTextSection extends StatelessWidget {
  /// Identifiant de l'utilisateur connecté (= identifiant du document Firestore)
  final String uid;

  const ProfilTextSection({super.key, required this.uid});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        GetUserData(
          uid,
          'pseudo',
          const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 6),
        GetUserData(
          uid,
          'bio',
          const TextStyle(color: Colors.white, fontSize: 16),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.location_on, color: Colors.white, size: 20),
            const SizedBox(width: 4),
            // Flexible : un nom de ville très long passe à la ligne au lieu de déborder
            Flexible(
              child: GetUserData(
                uid,
                'location',
                const TextStyle(color: Colors.white, fontSize: 16),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

/// Affiche UN champ du document Firestore Users/{documentId} avec le style [fieldStyle].
///
/// Différences avec la version du TP précédent :
/// - le style est passé en paramètre (fieldStyle) pour réutiliser le widget partout ;
/// - on écoute le document en temps réel (snapshots) au lieu d'une seule lecture (get) :
///   juste après une inscription, la page de profil s'affiche avant que addUser()
///   ait fini d'écrire le document ; avec un flux, le texte se met à jour tout seul ;
/// - si le document ou le champ n'existe pas (ancien compte sans bio/location),
///   on affiche « Non renseigné » au lieu de planter.
class GetUserData extends StatefulWidget {
  final String documentId;
  final String fieldName;
  final TextStyle fieldStyle;

  const GetUserData(this.documentId, this.fieldName, this.fieldStyle, {super.key});

  @override
  State<GetUserData> createState() => _GetUserDataState();
}

class _GetUserDataState extends State<GetUserData> {
  // Le flux est créé UNE seule fois dans initState() : s'il était créé dans build(),
  // chaque setState() de la page (ex : choix d'une photo) relancerait une requête.
  late final Stream<DocumentSnapshot<Map<String, dynamic>>> _userStream;

  @override
  void initState() {
    super.initState();
    _userStream = firestore.collection('Users').doc(widget.documentId).snapshots();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: _userStream,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Text('Un problème est survenu', style: widget.fieldStyle, textAlign: TextAlign.center);
        }

        if (!snapshot.hasData) {
          return Text('Chargement…', style: widget.fieldStyle, textAlign: TextAlign.center);
        }

        // data() renvoie null si le document n'existe pas : on ne force rien avec "!"
        final data = snapshot.data?.data();
        final value = data?[widget.fieldName];

        // On n'affiche la valeur que si c'est un texte non vide
        final text = (value is String && value.trim().isNotEmpty) ? value : 'Non renseigné';

        return Text(text, style: widget.fieldStyle, textAlign: TextAlign.center);
      },
    );
  }
}
