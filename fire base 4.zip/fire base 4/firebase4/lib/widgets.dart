import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

// Instances Firebase partagées par toute l'application.
// On ne stocke PAS l'identifiant de l'utilisateur dans une variable globale :
// on le lit toujours via auth.currentUser, qui reflète l'utilisateur réellement connecté.
final FirebaseAuth auth = FirebaseAuth.instance;
final FirebaseFirestore firestore = FirebaseFirestore.instance;

const Color rouge = Color(0xFFF44336);

/// Champ de saisie arrondi avec une icône dans un rond blanc à gauche
/// (utilisé dans les onglets Connexion et Inscription).
class InputField extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final IconData icon;
  final bool obscure;
  final bool readOnly;
  final VoidCallback? onTap;

  const InputField({
    super.key,
    required this.controller,
    required this.hint,
    required this.icon,
    this.obscure = false,
    this.readOnly = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: Colors.white.withValues(alpha: 0.3)),
      ),
      child: Row(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
            child: Icon(icon, color: rouge),
          ),
          Expanded(
            child: TextField(
              controller: controller,
              obscureText: obscure,
              readOnly: readOnly,
              onTap: onTap,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white, fontSize: 18),
              decoration: InputDecoration(
                border: InputBorder.none,
                hintText: hint,
                hintStyle: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600),
              ),
            ),
          ),
          const SizedBox(width: 50),
        ],
      ),
    );
  }
}

/// Gros bouton arrondi réutilisable.
/// [onPressed] peut être null : le bouton est alors désactivé (grisé).
class MainButton extends StatelessWidget {
  final String text;
  final VoidCallback? onPressed;
  final Color background;
  final Color foreground;

  const MainButton({
    super.key,
    required this.text,
    required this.onPressed,
    this.background = Colors.white,
    this.foreground = rouge,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 55,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: background,
          foregroundColor: foreground,
          elevation: 5,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
        ),
        onPressed: onPressed,
        child: Text(text, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      ),
    );
  }
}

/// Affiche un message en bas de l'écran (SnackBar).
void showMessage(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
}
