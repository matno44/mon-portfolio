import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

FirebaseAuth auth = FirebaseAuth.instance;
FirebaseFirestore firestore = FirebaseFirestore.instance;

const Color rouge = Color(0xFFF44336);

class LoginTabBar extends StatelessWidget {
  const LoginTabBar({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('Firebase Login'),
            centerTitle: true,
            backgroundColor: Colors.amber,
            foregroundColor: Colors.white,
            bottom: const TabBar(
              indicatorColor: rouge,
              labelColor: Colors.white,
              unselectedLabelColor: Colors.white70,
              tabs: [
                Tab(text: 'Connexion'),
                Tab(text: 'Inscription'),
              ],
            ),
          ),
          body: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFFFFD54F), Color(0xFFFF9800), Color(0xFFE65100)],
              ),
            ),
            child: const TabBarView(
              children: [
                LoginSection(),
                SignUpSection(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ---------- Onglet Connexion ----------

class LoginSection extends StatefulWidget {
  const LoginSection({super.key});

  @override
  State<LoginSection> createState() => _LoginSectionState();
}

class _LoginSectionState extends State<LoginSection> {
  final emailField = TextEditingController();
  final passwordField = TextEditingController();

  Future<void> loginToFirebase() async {
    print(emailField.text.trim());
    try {
      final value = await auth.signInWithEmailAndPassword(
        email: emailField.text.trim(),
        password: passwordField.text.trim(),
      );
      print(value.toString());
    } on FirebaseAuthException catch (e) {
      print(e.toString());
      if (mounted) showMessage(context, 'Connexion impossible : ${e.code}');
    }
  }

  Future<void> resetPassword() async {
    if (emailField.text.trim().isEmpty) {
      showMessage(context, 'Entrez votre adresse email');
      return;
    }
    try {
      await auth.sendPasswordResetEmail(email: emailField.text.trim());
      if (mounted) showMessage(context, 'Email de réinitialisation envoyé');
    } on FirebaseAuthException catch (e) {
      if (mounted) showMessage(context, 'Erreur : ${e.code}');
    }
  }

  @override
  void dispose() {
    emailField.dispose();
    passwordField.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(30),
      children: [
        const LogoSection(),
        const SizedBox(height: 30),
        InputField(controller: emailField, hint: 'Adresse email', icon: Icons.people_outline),
        InputField(controller: passwordField, hint: 'Mot de passe', icon: Icons.lock_outline, obscure: true),
        const SizedBox(height: 10),
        MainButton(text: 'CONNEXION', onPressed: loginToFirebase),
        const SizedBox(height: 20),
        TextButton(
          onPressed: resetPassword,
          child: const Text('Mot de passe oublié ?', style: TextStyle(color: Colors.white)),
        ),
      ],
    );
  }
}

// ---------- Onglet Inscription ----------

class SignUpSection extends StatefulWidget {
  const SignUpSection({super.key});

  @override
  State<SignUpSection> createState() => _SignUpSectionState();
}

class _SignUpSectionState extends State<SignUpSection> {
  final emailField = TextEditingController();
  final passwordField = TextEditingController();
  final pseudoField = TextEditingController();
  final birthdateField = TextEditingController();

  Future<void> addUser(String userID, String pseudo, String birthdate) {
    return firestore
        .collection('Users')
        .doc(userID)
        .set({
          'pseudo': pseudo,
          'birthdate': birthdate,
        })
        .then((value) => print('Utilisateur ajouté'))
        .catchError((error) => print('Erreur: $error'));
  }

  Future<void> signUpToFirebase() async {
    print(emailField.text.trim());
    try {
      final value = await auth.createUserWithEmailAndPassword(
        email: emailField.text.trim(),
        password: passwordField.text.trim(),
      );
      print(value.user!.uid);
      await addUser(
        value.user!.uid,
        pseudoField.text.trim(),
        birthdateField.text.trim(),
      );
    } on FirebaseAuthException catch (e) {
      print(e.toString());
      if (mounted) showMessage(context, 'Inscription impossible : ${e.code}');
    }
  }

  // Sélecteur de date pour remplir le champ au format JJ/MM/AAAA
  Future<void> pickBirthdate() async {
    final date = await showDatePicker(
      context: context,
      initialDate: DateTime(2000),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );
    if (date != null) {
      birthdateField.text =
          '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';
    }
  }

  @override
  void dispose() {
    emailField.dispose();
    passwordField.dispose();
    pseudoField.dispose();
    birthdateField.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(30),
      children: [
        const Text(
          'Créez-vous un compte',
          textAlign: TextAlign.center,
          style: TextStyle(color: rouge, fontSize: 16, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 30),
        InputField(controller: pseudoField, hint: 'Pseudo', icon: Icons.people_outline),
        InputField(controller: emailField, hint: 'Adresse email', icon: Icons.mail_outline),
        InputField(controller: passwordField, hint: 'Mot de passe', icon: Icons.lock_outline, obscure: true),
        InputField(
          controller: birthdateField,
          hint: 'Date de naissance',
          icon: Icons.calendar_month,
          readOnly: true,
          onTap: pickBirthdate,
        ),
        const SizedBox(height: 10),
        MainButton(text: 'INSCRIPTION', onPressed: signUpToFirebase),
      ],
    );
  }
}

// ---------- Widgets communs ----------

class LogoSection extends StatelessWidget {
  const LogoSection({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 130,
          height: 130,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(30),
            boxShadow: [
              BoxShadow(color: Colors.white.withValues(alpha: 0.3), blurRadius: 0, spreadRadius: 15),
            ],
          ),
          child: const Icon(Icons.local_fire_department, size: 90, color: Colors.orange),
        ),
        const SizedBox(height: 35),
        const Text.rich(
          TextSpan(
            style: TextStyle(fontSize: 36, fontWeight: FontWeight.w900),
            children: [
              TextSpan(text: 'Firebase', style: TextStyle(color: Colors.white)),
              TextSpan(text: 'Login', style: TextStyle(color: rouge)),
            ],
          ),
        ),
        const Text(
          'Connectez-vous avec vos identifiants',
          style: TextStyle(color: rouge, fontSize: 14),
        ),
      ],
    );
  }
}

class InputField extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final IconData icon;
  final bool obscure;
  final bool readOnly;
  final VoidCallback? onTap;

  const InputField({
    super.key,
    required this.controller,
    required this.hint,
    required this.icon,
    this.obscure = false,
    this.readOnly = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: Colors.white.withValues(alpha: 0.3)),
      ),
      child: Row(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
            child: Icon(icon, color: rouge),
          ),
          Expanded(
            child: TextField(
              controller: controller,
              obscureText: obscure,
              readOnly: readOnly,
              onTap: onTap,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white, fontSize: 18),
              decoration: InputDecoration(
                border: InputBorder.none,
                hintText: hint,
                hintStyle: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600),
              ),
            ),
          ),
          const SizedBox(width: 50),
        ],
      ),
    );
  }
}

class MainButton extends StatelessWidget {
  final String text;
  final VoidCallback onPressed;
  final Color background;
  final Color foreground;

  const MainButton({
    super.key,
    required this.text,
    required this.onPressed,
    this.background = Colors.white,
    this.foreground = rouge,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 55,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: background,
          foregroundColor: foreground,
          elevation: 5,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
        ),
        onPressed: onPressed,
        child: Text(text, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      ),
    );
  }
}

void showMessage(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
}
