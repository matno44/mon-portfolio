--
-- PostgreSQL database dump
--

\restrict dP6a7r4du9UfLVgeqxPhytNXK6MESaYOHG5yBgvmgkec02o3pgMUDCzhjZQbGQz

-- Dumped from database version 18.6 (Homebrew)
-- Dumped by pg_dump version 18.6

-- Started on 2026-10-04 14:48:59 CEST

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 3879 (class 1262 OID 16863)
-- Name: mediatek; Type: DATABASE; Schema: -; Owner: devakwabanm
--

CREATE DATABASE mediatek WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE mediatek OWNER TO devakwabanm;

\unrestrict dP6a7r4du9UfLVgeqxPhytNXK6MESaYOHG5yBgvmgkec02o3pgMUDCzhjZQbGQz
\connect mediatek
\restrict dP6a7r4du9UfLVgeqxPhytNXK6MESaYOHG5yBgvmgkec02o3pgMUDCzhjZQbGQz

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 225 (class 1255 OID 16918)
-- Name: afficher_stats_clients(); Type: PROCEDURE; Schema: public; Owner: devakwabanm
--

CREATE PROCEDURE public.afficher_stats_clients()
    LANGUAGE plpgsql
    AS $$

declare

nb_facture integer;
CA numeric;
curs1 CURSOR FOR select num_client from client;
res integer;

begin
	
open curs1 ;

Fetch next From curs1 INTO res ;

while found loop
	
	SELECT get_nb_factures_client(res) INTO nb_facture;
	SELECT get_ca_client(res) INTO CA;

	RAISE NOTICE 'Client % : ',res;
	RAISE NOTICE '% factures / % CA',nb_facture , CA;
	RAISE NOTICE '----------------------------------------';

FETCH NEXT FROM curs1 INTO res;
end loop;

close curs1;

end;
$$;


ALTER PROCEDURE public.afficher_stats_clients() OWNER TO devakwabanm;

--
-- TOC entry 224 (class 1255 OID 16917)
-- Name: get_ca_client(integer); Type: FUNCTION; Schema: public; Owner: devakwabanm
--

CREATE FUNCTION public.get_ca_client(p_num_client integer) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
DECLARE
    ca numeric;
BEGIN
    SELECT COALESCE(SUM(p.prix * c.quantite), 0) INTO ca
    FROM facture f
    INNER JOIN concerne c ON c.num_facture = f.num_facture
    INNER JOIN produit p  ON p.num_produit = c.num_produit
    WHERE f.num_client = p_num_client;

    RETURN ca;
END;
$$;


ALTER FUNCTION public.get_ca_client(p_num_client integer) OWNER TO devakwabanm;

--
-- TOC entry 223 (class 1255 OID 16916)
-- Name: get_nb_factures_client(integer); Type: FUNCTION; Schema: public; Owner: devakwabanm
--

CREATE FUNCTION public.get_nb_factures_client(p_num_client integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    nb_facture integer;
BEGIN
    SELECT COUNT(*) INTO nb_facture
    FROM facture
    WHERE num_client = p_num_client;

    RETURN nb_facture;
END;
$$;


ALTER FUNCTION public.get_nb_factures_client(p_num_client integer) OWNER TO devakwabanm;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 219 (class 1259 OID 16871)
-- Name: client; Type: TABLE; Schema: public; Owner: devakwabanm
--

CREATE TABLE public.client (
    num_client integer NOT NULL,
    nom_client character varying(30),
    prenom_client character varying(30),
    adresse_client character varying(192),
    date_naissance date,
    tel character varying(14),
    sexe boolean
);


ALTER TABLE public.client OWNER TO devakwabanm;

--
-- TOC entry 222 (class 1259 OID 16895)
-- Name: concerne; Type: TABLE; Schema: public; Owner: devakwabanm
--

CREATE TABLE public.concerne (
    num_facture integer NOT NULL,
    num_produit integer NOT NULL,
    quantite integer NOT NULL
);


ALTER TABLE public.concerne OWNER TO devakwabanm;

--
-- TOC entry 221 (class 1259 OID 16883)
-- Name: facture; Type: TABLE; Schema: public; Owner: devakwabanm
--

CREATE TABLE public.facture (
    num_facture integer NOT NULL,
    date_facture date,
    num_client integer NOT NULL
);


ALTER TABLE public.facture OWNER TO devakwabanm;

--
-- TOC entry 220 (class 1259 OID 16877)
-- Name: produit; Type: TABLE; Schema: public; Owner: devakwabanm
--

CREATE TABLE public.produit (
    num_produit integer NOT NULL,
    designation character varying(30),
    prix numeric(10,2),
    stock integer
);


ALTER TABLE public.produit OWNER TO devakwabanm;

--
-- TOC entry 3870 (class 0 OID 16871)
-- Dependencies: 219
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: devakwabanm
--

COPY public.client (num_client, nom_client, prenom_client, adresse_client, date_naissance, tel, sexe) FROM stdin;
1	Martin	Alice	12 rue des Lilas, Gap	1990-04-12	0612345678	f
2	Durand	Paul	5 avenue de la Gare, Gap	1985-09-30	0698765432	t
3	Bernard	Léa	8 place Jean Marcellin, Gap	2000-01-05	0611223344	f
\.


--
-- TOC entry 3873 (class 0 OID 16895)
-- Dependencies: 222
-- Data for Name: concerne; Type: TABLE DATA; Schema: public; Owner: devakwabanm
--

COPY public.concerne (num_facture, num_produit, quantite) FROM stdin;
1	1	2
1	2	1
2	3	3
3	1	1
3	2	4
\.


--
-- TOC entry 3872 (class 0 OID 16883)
-- Dependencies: 221
-- Data for Name: facture; Type: TABLE DATA; Schema: public; Owner: devakwabanm
--

COPY public.facture (num_facture, date_facture, num_client) FROM stdin;
1	2026-09-01	1
2	2026-09-10	1
3	2026-09-15	2
\.


--
-- TOC entry 3871 (class 0 OID 16877)
-- Dependencies: 220
-- Data for Name: produit; Type: TABLE DATA; Schema: public; Owner: devakwabanm
--

COPY public.produit (num_produit, designation, prix, stock) FROM stdin;
1	Film DVD	12.50	100
2	Livre	8.90	50
3	CD musique	15.00	30
\.


--
-- TOC entry 3710 (class 2606 OID 16876)
-- Name: client client_pkey; Type: CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_pkey PRIMARY KEY (num_client);


--
-- TOC entry 3714 (class 2606 OID 16889)
-- Name: facture facture_pkey; Type: CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.facture
    ADD CONSTRAINT facture_pkey PRIMARY KEY (num_facture);


--
-- TOC entry 3719 (class 2606 OID 16902)
-- Name: concerne pk_concerne; Type: CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.concerne
    ADD CONSTRAINT pk_concerne PRIMARY KEY (num_facture, num_produit);


--
-- TOC entry 3712 (class 2606 OID 16882)
-- Name: produit produit_pkey; Type: CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.produit
    ADD CONSTRAINT produit_pkey PRIMARY KEY (num_produit);


--
-- TOC entry 3716 (class 1259 OID 16914)
-- Name: i_fk_concerne_facture; Type: INDEX; Schema: public; Owner: devakwabanm
--

CREATE INDEX i_fk_concerne_facture ON public.concerne USING btree (num_facture);


--
-- TOC entry 3717 (class 1259 OID 16915)
-- Name: i_fk_concerne_produit; Type: INDEX; Schema: public; Owner: devakwabanm
--

CREATE INDEX i_fk_concerne_produit ON public.concerne USING btree (num_produit);


--
-- TOC entry 3715 (class 1259 OID 16913)
-- Name: i_fk_facture_client; Type: INDEX; Schema: public; Owner: devakwabanm
--

CREATE INDEX i_fk_facture_client ON public.facture USING btree (num_client);


--
-- TOC entry 3721 (class 2606 OID 16903)
-- Name: concerne fk_concerne_facture; Type: FK CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.concerne
    ADD CONSTRAINT fk_concerne_facture FOREIGN KEY (num_facture) REFERENCES public.facture(num_facture);


--
-- TOC entry 3722 (class 2606 OID 16908)
-- Name: concerne fk_concerne_produit; Type: FK CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.concerne
    ADD CONSTRAINT fk_concerne_produit FOREIGN KEY (num_produit) REFERENCES public.produit(num_produit);


--
-- TOC entry 3720 (class 2606 OID 16890)
-- Name: facture fk_facture_client; Type: FK CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.facture
    ADD CONSTRAINT fk_facture_client FOREIGN KEY (num_client) REFERENCES public.client(num_client);


-- Completed on 2026-10-04 14:48:59 CEST

--
-- PostgreSQL database dump complete
--

\unrestrict dP6a7r4du9UfLVgeqxPhytNXK6MESaYOHG5yBgvmgkec02o3pgMUDCzhjZQbGQz

