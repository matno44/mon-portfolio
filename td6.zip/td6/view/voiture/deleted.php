<?php
$immatHTML = htmlspecialchars($immat);
echo "<p>La voiture d'immatriculation " . $immatHTML . ' a bien été supprimée.</p>';
require File::build_path(array('view', 'voiture', 'list.php'));
?>