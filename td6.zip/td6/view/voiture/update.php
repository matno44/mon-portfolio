<?php
// Vue commune aux actions create et update (ex-create.php fusionnée ici).
// Variables initialisées par le contrôleur :
//   $immat, $marque, $couleur : valeurs des champs (chaînes vides pour create)
//   $champ_immat : 'required' (create) ou 'readonly' (update)
//   $action_form : 'save' (create) ou 'updated' (update)
$vImmat      = htmlspecialchars($immat);
$vMarque     = htmlspecialchars($marque);
$vCouleur    = htmlspecialchars($couleur);
$champImmat  = htmlspecialchars($champ_immat);
$actionForm  = htmlspecialchars($action_form);
$controleur  = htmlspecialchars(static::$object);
$titreHTML   = htmlspecialchars($pagetitle);
?>
<form method="get" action="index.php">
    <fieldset>
        <legend><?php echo $titreHTML; ?> :</legend>
        <!-- Champs cachés : contrôleur et action transmis au routeur -->
        <input type="hidden" name="controller" value="<?php echo $controleur; ?>" />
        <input type="hidden" name="action" value="<?php echo $actionForm; ?>" />
        <p>
            <label for="immat_id">Immatriculation</label> :
            <input type="text" placeholder="Ex : 256AB34" name="immatriculation" id="immat_id"
                   value="<?php echo $vImmat; ?>" <?php echo $champImmat; ?> />
        </p>
        <p>
            <label for="marque_id">Marque</label> :
            <input type="text" placeholder="Ex : Renault" name="marque" id="marque_id"
                   value="<?php echo $vMarque; ?>" required />
        </p>
        <p>
            <label for="couleur_id">Couleur</label> :
            <input type="text" placeholder="Ex : rouge" name="couleur" id="couleur_id"
                   value="<?php echo $vCouleur; ?>" required />
        </p>
        <p>
            <input type="submit" value="Envoyer" />
        </p>
    </fieldset>
</form>
