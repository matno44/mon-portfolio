
       <?php
$vMarque   = htmlspecialchars($v->getMarque());
$vCouleur  = htmlspecialchars($v->getCouleur());
$vImmat    = htmlspecialchars($v->getImmatriculation());
$vImmatURL = rawurlencode($v->getImmatriculation());

echo '<p>Marque : ' . $vMarque . '</p>';
echo '<p>Couleur : ' . $vCouleur . '</p>';
echo '<p>Immatriculation : ' . $vImmat . '</p>';
echo '<p><a href="index.php?controller=voiture&action=delete&immat=' . $vImmatURL . '">Supprimer la voiture</a></p>';
echo '<p><a href="index.php?controller=voiture&action=update&immat=' . $vImmatURL . '">Mettre à jour la voiture</a></p>';
