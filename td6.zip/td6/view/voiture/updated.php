<?php
$immatHTML = htmlspecialchars($immat);
echo "<p>La voiture d'immatriculation " . $immatHTML . ' a bien été mise à jour.</p>';
require File::build_path(array('view', 'voiture', 'list.php'));
?>