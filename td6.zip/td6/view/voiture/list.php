
        <?php
        foreach ($tab_v as $v) {
            $vImmatHTML = htmlspecialchars($v->getImmatriculation());
            $vImmatURL  = rawurlencode($v->getImmatriculation());
            echo '<p> Voiture d\'immatriculation <a href="index.php?controller=voiture&action=read&immat='
                . $vImmatURL . '">' . $vImmatHTML . '</a>.</p>';
        }
        ?>
<p><a href="index.php?controller=voiture&action=create">Ajouter une voiture</a></p>

