<?php
$uLoginHTML = htmlspecialchars($u->getLogin());
$uLoginURL  = rawurlencode($u->getLogin());

echo '<h2>Trajets de ' . $uLoginHTML . ' en tant que passager</h2>';

if (empty($tab_t)) {
    echo '<p>Cet utilisateur n\'est passager d\'aucun trajet.</p>';
}
foreach ($tab_t as $t) {
    $tIdHTML      = htmlspecialchars($t->getId());
    $tIdURL       = rawurlencode($t->getId());
    $tDepartHTML  = htmlspecialchars($t->getDepart());
    $tArriveeHTML = htmlspecialchars($t->getArrivee());
    $tDateHTML    = htmlspecialchars($t->getDate());
    echo '<p>Trajet <a href="index.php?controller=trajet&action=read&id=' . $tIdURL . '">n°' . $tIdHTML . '</a> : '
        . $tDepartHTML . ' → ' . $tArriveeHTML . ' le ' . $tDateHTML . '</p>';
}
echo '<p><a href="index.php?controller=utilisateur&action=read&login=' . $uLoginURL . '">Retour à l\'utilisateur</a></p>';
