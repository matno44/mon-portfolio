<?php
$uLogin    = htmlspecialchars($u->getLogin());
$uNom      = htmlspecialchars($u->getNom());
$uPrenom   = htmlspecialchars($u->getPrenom());
$uLoginURL = rawurlencode($u->getLogin());

echo '<p>Login : ' . $uLogin . '</p>';
echo '<p>Nom : ' . $uNom . '</p>';
echo '<p>Prénom : ' . $uPrenom . '</p>';
echo '<p><a href="index.php?controller=utilisateur&action=readTrajets&login=' . $uLoginURL . '">Voir ses trajets en tant que passager</a></p>';
echo '<p><a href="index.php?controller=utilisateur&action=update&login=' . $uLoginURL . '">Mettre à jour l\'utilisateur</a></p>';
echo '<p><a href="index.php?controller=utilisateur&action=delete&login=' . $uLoginURL . '">Supprimer l\'utilisateur</a></p>';
