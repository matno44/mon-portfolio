<?php
// Vue commune aux actions create et update.
// Variables initialisées par le contrôleur :
//   $login, $nom, $prenom : valeurs des champs (chaînes vides pour create)
//   $champ_login : 'required' (create) ou 'readonly' (update)
//   $action_form : 'save' (create) ou 'updated' (update)
$uLogin      = htmlspecialchars($login);
$uNom        = htmlspecialchars($nom);
$uPrenom     = htmlspecialchars($prenom);
$champLogin  = htmlspecialchars($champ_login);
$actionForm  = htmlspecialchars($action_form);
$controleur  = htmlspecialchars(static::$object);
$titreHTML   = htmlspecialchars($pagetitle);
?>
<form method="get" action="index.php">
    <fieldset>
        <legend><?php echo $titreHTML; ?> :</legend>
        <!-- Champs cachés : contrôleur et action transmis au routeur -->
        <input type="hidden" name="controller" value="<?php echo $controleur; ?>" />
        <input type="hidden" name="action" value="<?php echo $actionForm; ?>" />
        <p>
            <label for="login_id">Login</label> :
            <input type="text" placeholder="Ex : jdupont" name="login" id="login_id"
                   value="<?php echo $uLogin; ?>" <?php echo $champLogin; ?> />
        </p>
        <p>
            <label for="nom_id">Nom</label> :
            <input type="text" placeholder="Ex : Dupont" name="nom" id="nom_id"
                   value="<?php echo $uNom; ?>" required />
        </p>
        <p>
            <label for="prenom_id">Prénom</label> :
            <input type="text" placeholder="Ex : Jean" name="prenom" id="prenom_id"
                   value="<?php echo $uPrenom; ?>" required />
        </p>
        <p>
            <input type="submit" value="Envoyer" />
        </p>
    </fieldset>
</form>
