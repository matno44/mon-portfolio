
        <?php
        foreach ($tab_u as $u) {
            $uLoginHTML = htmlspecialchars($u->getLogin());
            $uLoginURL  = rawurlencode($u->getLogin());
            echo '<p> Utilisateur de login <a href="index.php?controller=utilisateur&action=read&login='
                . $uLoginURL . '">' . $uLoginHTML . '</a>'
                . ' (<a href="index.php?controller=utilisateur&action=delete&login=' . $uLoginURL . '">supprimer</a>).</p>';
        }
        ?>
<p><a href="index.php?controller=utilisateur&action=create">Ajouter un utilisateur</a></p>
