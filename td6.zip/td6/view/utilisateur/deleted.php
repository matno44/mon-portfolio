<?php
$loginHTML = htmlspecialchars($login);
echo "<p>L'utilisateur de login " . $loginHTML . ' a bien été supprimé.</p>';
require File::build_path(array('view', 'utilisateur', 'list.php'));
?>
