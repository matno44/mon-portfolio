<?php
$tIdHTML      = htmlspecialchars($t->getId());
$tIdURL       = rawurlencode($t->getId());
$tDepartHTML  = htmlspecialchars($t->getDepart());
$tArriveeHTML = htmlspecialchars($t->getArrivee());

echo '<h2>Passagers du trajet n°' . $tIdHTML . ' (' . $tDepartHTML . ' → ' . $tArriveeHTML . ')</h2>';

if (empty($tab_u)) {
    echo '<p>Aucun passager pour ce trajet.</p>';
}
foreach ($tab_u as $u) {
    $uLoginHTML = htmlspecialchars($u->getLogin());
    $uLoginURL  = rawurlencode($u->getLogin());
    $uNomHTML   = htmlspecialchars($u->getPrenom() . ' ' . $u->getNom());
    echo '<p>Passager <a href="index.php?controller=utilisateur&action=read&login=' . $uLoginURL . '">'
        . $uLoginHTML . '</a> (' . $uNomHTML . ')</p>';
}
echo '<p><a href="index.php?controller=trajet&action=read&id=' . $tIdURL . '">Retour au trajet</a></p>';
