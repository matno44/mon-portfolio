<?php
$idHTML = htmlspecialchars($id);
echo '<p>Le trajet n°' . $idHTML . ' a bien été mis à jour.</p>';
require File::build_path(array('view', 'trajet', 'list.php'));
?>
