<?php
$tId         = htmlspecialchars($t->getId());
$tIdURL      = rawurlencode($t->getId());
$tDepart     = htmlspecialchars($t->getDepart());
$tArrivee    = htmlspecialchars($t->getArrivee());
$tDate       = htmlspecialchars($t->getDate());
$tNbplaces   = htmlspecialchars($t->getNbplaces());
$tPrix       = htmlspecialchars($t->getPrix());
$tCond       = htmlspecialchars($t->getConducteurLogin());
$tCondURL    = rawurlencode($t->getConducteurLogin());

echo '<p>Trajet n°' . $tId . '</p>';
echo '<p>Départ : ' . $tDepart . '</p>';
echo '<p>Arrivée : ' . $tArrivee . '</p>';
echo '<p>Date : ' . $tDate . '</p>';
echo '<p>Nombre de places : ' . $tNbplaces . '</p>';
echo '<p>Prix : ' . $tPrix . ' €</p>';
echo '<p>Conducteur : <a href="index.php?controller=utilisateur&action=read&login=' . $tCondURL . '">' . $tCond . '</a></p>';
echo '<p><a href="index.php?controller=trajet&action=readPassagers&id=' . $tIdURL . '">Voir les passagers</a></p>';
echo '<p><a href="index.php?controller=trajet&action=update&id=' . $tIdURL . '">Mettre à jour le trajet</a></p>';
echo '<p><a href="index.php?controller=trajet&action=delete&id=' . $tIdURL . '">Supprimer le trajet</a></p>';
