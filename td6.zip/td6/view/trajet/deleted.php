<?php
$idHTML = htmlspecialchars($id);
echo '<p>Le trajet n°' . $idHTML . ' a bien été supprimé.</p>';
require File::build_path(array('view', 'trajet', 'list.php'));
?>
