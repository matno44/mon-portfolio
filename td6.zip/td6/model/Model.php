<?php

require_once File::build_path(array('config', 'Conf.php'));

class Model
{
    // Attribut contenant l'instance de PDO
    public static $pdo;

    // Méthode statique pour initialiser la connexion à la base de données
    public static function init()
    {
        // On récupère les informations de connexion depuis la classe Conf
        $login    = Conf::getLogin();
        $hostname = Conf::getHostname();
        $database = Conf::getDatabase();
        $password = Conf::getPassword();

        // On crée une nouvelle instance de PDO pour se connecter à la base de données
        try {
            self::$pdo = new PDO(
                "mysql:host=$hostname;dbname=$database",
                $login,
                $password,
                [PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8']
            );
            self::$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            if (Conf::getDebug()) {
                echo $e->getMessage();  // affiche un message d'erreur
            } else {
                echo 'Une erreur est survenue <a href=""> retour a la page d\'accueil </a>';
            }
            die();
        }
    }

    // Méthode statique pour exécuter une requête SQL et retourner les résultats
    public static function query($sql, $params = [])
    {
        // On prépare la requête SQL
        $stmt = self::$pdo->prepare($sql);
        // On exécute la requête avec les paramètres fournis
        $stmt->execute($params);
        // On retourne les résultats sous forme de tableau associatif
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Méthode générique qui renvoie tous les objets de la table.
    // static::$object va chercher l'attribut de la classe fille :
    // ModelVoiture::selectAll() lit ModelVoiture::$object = 'voiture'.
    // Remarque : le nom de la table ne peut pas être un paramètre de requête
    // préparée ; il vient de la classe (jamais de l'internaute), donc pas de risque.
    public static function selectAll()
    {
        $table_name = static::$object;                 // Utilisation de l'objet statique pour obtenir le nom de la table
        $class_name = 'Model' . ucfirst($table_name);  // Construction du nom de la classe correspondante
        try {
            $query = 'SELECT * FROM ' . $table_name;
            $rep   = Model::$pdo->query($query);
            $rep->setFetchMode(PDO::FETCH_CLASS, $class_name);

            return $rep->fetchAll();
        } catch (PDOException $e) {
            if (Conf::getDebug()) {
                echo $e->getMessage();
            } else {
                echo 'Une erreur est survenue lors de la lecture des ' . $table_name . '.';
            }

            return array();
        }
    }

    // Méthode générique qui renvoie l'objet dont la clé primaire vaut
    // $primary_value, ou false s'il n'existe pas.
    public static function select($primary_value)
    {
        $table_name  = static::$object;
        $class_name  = 'Model' . ucfirst($table_name);
        $primary_key = static::$primary;               // nom de la clé primaire de la table
        try {
            $sql      = 'SELECT * FROM ' . $table_name . ' WHERE ' . $primary_key . '=:nom_tag';
            // Préparation de la requête
            $req_prep = Model::$pdo->prepare($sql);
            $values   = array(
                'nom_tag' => $primary_value,
            );
            // On donne les valeurs et on exécute la requête
            $req_prep->execute($values);
            // On récupère les résultats comme précédemment
            $req_prep->setFetchMode(PDO::FETCH_CLASS, $class_name);
            $tab_obj = $req_prep->fetchAll();
            // Attention, si il n'y a pas de résultats, on renvoie false
            if (empty($tab_obj))
                return false;
            return $tab_obj[0];
        } catch (PDOException $e) {
            if (Conf::getDebug()) {
                echo $e->getMessage();
            } else {
                echo 'Une erreur est survenue lors de la recherche dans la table ' . $table_name . '.';
            }

            return false;
        }
    }

    // Méthode générique qui supprime l'objet dont la clé primaire vaut $primary_value.
    public static function delete($primary_value)
    {
        $table_name  = static::$object;
        $primary_key = static::$primary;
        try {
            $sql      = 'DELETE FROM ' . $table_name . ' WHERE ' . $primary_key . '=:nom_tag';
            // Préparation de la requête
            $req_prep = Model::$pdo->prepare($sql);
            $values   = array(
                'nom_tag' => $primary_value,
            );
            // On donne les valeurs et on exécute la requête.
            // Attention : un DELETE ne renvoie pas de résultats, donc pas de fetch() ici.
            $req_prep->execute($values);

            return true;
        } catch (PDOException $e) {
            if (Conf::getDebug()) {
                echo $e->getMessage();
            } else {
                echo 'Une erreur est survenue lors de la suppression dans la table ' . $table_name . '.';
            }

            return false;
        }
    }

    // Méthode générique de mise à jour.
    // $data est un tableau associatif champ => valeur, qui doit contenir la clé primaire.
    // Ex : array('immatriculation' => '123AB45', 'marque' => 'Renault', 'couleur' => 'bleu')
    // donne : UPDATE voiture SET immatriculation=:immatriculation,marque=:marque,couleur=:couleur
    //         WHERE immatriculation=:immatriculation
    public static function update($data)
    {
        $table_name  = static::$object;
        $primary_key = static::$primary;

        // Construction de la partie SET à partir des clés du tableau $data
        $set = '';
        foreach ($data as $cle => $valeur) {
            $set = $set . $cle . '=:' . $cle . ',';
        }
        $set = rtrim($set, ',');  // on enlève la virgule de trop à la fin

        try {
            $sql      = 'UPDATE ' . $table_name . ' SET ' . $set
                . ' WHERE ' . $primary_key . '=:' . $primary_key;
            // Préparation de la requête
            $req_prep = Model::$pdo->prepare($sql);
            // Les valeurs ne sont jamais concaténées : elles sont passées à execute()
            // Attention : un UPDATE ne renvoie pas de résultats, donc pas de fetch() ici.
            $req_prep->execute($data);

            return true;
        } catch (PDOException $e) {
            if (Conf::getDebug()) {
                echo $e->getMessage();
            } else {
                echo 'Une erreur est survenue lors de la mise à jour dans la table ' . $table_name . '.';
            }

            return false;
        }
    }

    // Méthode générique d'enregistrement (INSERT).
    // $data est un tableau associatif champ => valeur.
    // Ex : array('immatriculation' => '123AB45', 'marque' => 'Renault', 'couleur' => 'bleu')
    // donne : INSERT INTO voiture (immatriculation,marque,couleur)
    //         VALUES (:immatriculation,:marque,:couleur)
    public static function save($data)
    {
        $table_name = static::$object;

        // Construction de la liste des champs et de la liste des tags
        $champs = '';
        $tags   = '';
        foreach ($data as $cle => $valeur) {
            $champs = $champs . $cle . ',';
            $tags   = $tags . ':' . $cle . ',';
        }
        $champs = rtrim($champs, ',');  // on enlève les virgules de trop à la fin
        $tags   = rtrim($tags, ',');

        try {
            $sql      = 'INSERT INTO ' . $table_name . ' (' . $champs . ') VALUES (' . $tags . ')';
            // Préparation de la requête
            $req_prep = Model::$pdo->prepare($sql);
            // Attention : un INSERT ne renvoie pas de résultats, donc pas de fetch() ici.
            $req_prep->execute($data);

            return true;
        } catch (PDOException $e) {
            if (Conf::getDebug()) {
                echo $e->getMessage();
            } else {
                echo "Une erreur est survenue lors de l'enregistrement dans la table " . $table_name . '.';
            }

            return false;
        }
    }
}

Model::init();  // Initialisation de la connexion à la base de données
