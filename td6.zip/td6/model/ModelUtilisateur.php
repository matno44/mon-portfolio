<?php

require_once File::build_path(array('model', 'Model.php'));

class ModelUtilisateur extends Model
{
    private $login;
    private $nom;
    private $prenom;
    protected static $object  = 'utilisateur';
    protected static $primary = 'login';

    // un constructeur
    // Avec PDO::FETCH_CLASS, PDO remplit les attributs AVANT d'appeler le
    // constructeur (sans paramètres) : il ne faut donc pas les écraser par null.
    public function __construct($l = NULL, $n = NULL, $p = NULL)
    {
        if (!is_null($l) && !is_null($n) && !is_null($p)) {
            $this->login  = $l;
            $this->nom    = $n;
            $this->prenom = $p;
        }
    }

    // un getter
    public function getLogin()
    {
        return $this->login;
    }

    public function setLogin($login2)
    {
        $this->login = $login2;
    }

    public function getNom()
    {
        return $this->nom;
    }

    public function setNom($nom2)
    {
        $this->nom = $nom2;
    }

    public function getPrenom()
    {
        return $this->prenom;
    }

    public function setPrenom($prenom2)
    {
        $this->prenom = $prenom2;
    }

    // La méthode statique pour récupérer tous les utilisateurs en BDD
    // est maintenant selectAll(), héritée de Model.

    // Méthode statique qui renvoie les trajets (objets ModelTrajet) dont
    // l'utilisateur de login $login est passager (table de jointure passager, TD3).
    public static function getTrajets($login)
    {
        try {
            $sql      = 'SELECT t.* FROM trajet t '
                . 'JOIN passager p ON p.trajet_id = t.id '
                . 'WHERE p.utilisateur_login = :login_tag';
            // Préparation de la requête
            $req_prep = Model::$pdo->prepare($sql);
            $values   = array(
                'login_tag' => $login,
            );
            $req_prep->execute($values);
            $req_prep->setFetchMode(PDO::FETCH_CLASS, 'ModelTrajet');

            return $req_prep->fetchAll();
        } catch (PDOException $e) {
            if (Conf::getDebug()) {
                echo $e->getMessage();
            } else {
                echo 'Une erreur est survenue lors de la lecture des trajets.';
            }

            return array();
        }
    }
}
