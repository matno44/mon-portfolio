<?php

require_once File::build_path(array('model', 'Model.php'));

class ModelTrajet extends Model
{
    private $id;
    private $depart;
    private $arrivee;
    private $date;
    private $nbplaces;
    private $prix;
    private $conducteur_login;
    protected static $object  = 'trajet';
    protected static $primary = 'id';

    // un constructeur
    // (l'id n'est pas demandé : il est donné par l'auto-incrément de la BDD)
    public function __construct($dep = NULL, $arr = NULL, $d = NULL, $nb = NULL, $p = NULL, $cond = NULL)
    {
        if (!is_null($dep) && !is_null($arr) && !is_null($d) && !is_null($nb) && !is_null($p) && !is_null($cond)) {
            $this->depart           = $dep;
            $this->arrivee          = $arr;
            $this->date             = $d;
            $this->nbplaces         = $nb;
            $this->prix             = $p;
            $this->conducteur_login = $cond;
        }
    }

    // les getters
    public function getId()
    {
        return $this->id;
    }

    public function getDepart()
    {
        return $this->depart;
    }

    public function getArrivee()
    {
        return $this->arrivee;
    }

    public function getDate()
    {
        return $this->date;
    }

    public function getNbplaces()
    {
        return $this->nbplaces;
    }

    public function getPrix()
    {
        return $this->prix;
    }

    public function getConducteurLogin()
    {
        return $this->conducteur_login;
    }

    // selectAll, select, delete, update et save sont héritées de Model.

    // Méthode statique qui renvoie les passagers (objets ModelUtilisateur)
    // du trajet d'identifiant $id, grâce à la table de jointure passager (TD3).
    public static function getPassagers($id)
    {
        try {
            $sql      = 'SELECT u.* FROM utilisateur u '
                . 'JOIN passager p ON p.utilisateur_login = u.login '
                . 'WHERE p.trajet_id = :id_tag';
            // Préparation de la requête
            $req_prep = Model::$pdo->prepare($sql);
            $values   = array(
                'id_tag' => $id,
            );
            $req_prep->execute($values);
            $req_prep->setFetchMode(PDO::FETCH_CLASS, 'ModelUtilisateur');

            return $req_prep->fetchAll();
        } catch (PDOException $e) {
            if (Conf::getDebug()) {
                echo $e->getMessage();
            } else {
                echo 'Une erreur est survenue lors de la lecture des passagers.';
            }

            return array();
        }
    }
}
