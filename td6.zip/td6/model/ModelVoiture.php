<?php

require_once File::build_path(array('model', 'Model.php'));

class ModelVoiture extends Model
{
    private $marque;
    private $couleur;
    private $immatriculation;
    protected static $object  = 'voiture';
    protected static $primary = 'immatriculation';

    // un constructeur
    public function __construct($m = NULL, $c = NULL, $i = NULL)
    {
        if (!is_null($m) && !is_null($c) && !is_null($i)) {
            $this->marque          = $m;
            $this->couleur         = $c;
            $this->immatriculation = $i;
        }
    }

    // un getter
    public function getMarque()
    {
        return $this->marque;
    }

    public function setMarque($marque2)
    {
        $this->marque = $marque2;
    }

    public function getCouleur()
    {
        return $this->couleur;
    }

    public function setCouleur($couleur2)
    {
        $this->couleur = $couleur2;
    }

    public function getImmatriculation()
    {
        return $this->immatriculation;
    }

    public function setImmatriculation($immatriculation2)
    {
        $this->immatriculation = $immatriculation2;
    }

    // L'affichage n'est plus le rôle du modèle mais de la vue (architecture MVC).
    // La méthode est donc désactivée.
    // public function afficher()
    // {
    //     echo 'Marque: ' . $this->marque . '<br>';
    //     echo 'Couleur: ' . $this->couleur . '<br>';
    //     echo 'Immatriculation: ' . $this->immatriculation . '<br>';
    // }

    // La méthode statique pour récupérer toutes les voitures en BDD
    // est maintenant selectAll(), héritée de Model.
    // De même, getVoitureByImmat($immat) est remplacée par select($primary_value).

    // deleteByImmat($immat) est remplacée par delete($primary_value),
    // update($data) et save() sont remplacées par update($data) et save($data) :
    // toutes ces méthodes génériques sont héritées de Model.
}
