<?php

require_once File::build_path(array('model', 'ModelUtilisateur.php'));
require_once File::build_path(array('model', 'ModelTrajet.php'));  // trajets d'un passager

class ControllerUtilisateur
{
    // Nom de l'objet géré : sert à la vue générique pour trouver le dossier view/utilisateur/
    protected static $object = 'utilisateur';

    // Une action correspond généralement à une page Web.

    // Action readAll : affiche tous les utilisateurs.
    public static function readAll()
    {
        $tab_u      = ModelUtilisateur::selectAll();           // appel au modèle pour gérer la BD
        $view       = 'list';
        $pagetitle  = 'Liste des utilisateurs';
        require File::build_path(array('view', 'view.php'));   // vue générique
    }

    // Action read : affiche le détail de l'utilisateur dont le login
    // est passé dans l'URL.
    public static function read()
    {
        $login = isset($_GET['login']) ? $_GET['login'] : null;
        $u     = ModelUtilisateur::select($login);

        if ($u === false) {
            $message    = "Aucun utilisateur ne correspond au login " . $login . '.';
            $view       = 'error';
            $pagetitle  = 'Erreur';
        } else {
            $view       = 'detail';
            $pagetitle  = "Détail de l'utilisateur";
        }
        require File::build_path(array('view', 'view.php'));
    }

    // Action create : affiche le formulaire (vide) de création d'un utilisateur.
    public static function create()
    {
        // Les champs du formulaire sont vides
        $login  = '';
        $nom    = '';
        $prenom = '';

        $champ_login = 'required';  // on doit saisir le login
        $action_form = 'save';      // action appelée à l'envoi du formulaire

        $view       = 'update';
        $pagetitle  = "Création d'un utilisateur";
        require File::build_path(array('view', 'view.php'));
    }

    // Action save : enregistre l'utilisateur reçu puis réaffiche la liste.
    public static function save()
    {
        // On vérifie que les données du formulaire sont bien présentes
        if (!isset($_GET['login']) || !isset($_GET['nom']) || !isset($_GET['prenom'])) {
            self::error();
            return;
        }

        // tableau associatif : les clés sont les noms des champs de la table
        $data = array(
            'login'  => $_GET['login'],
            'nom'    => $_GET['nom'],
            'prenom' => $_GET['prenom'],
        );

        if (ModelUtilisateur::save($data)) {
            $tab_u      = ModelUtilisateur::selectAll();
            $view       = 'created';
            $pagetitle  = 'Utilisateur créé';
        } else {
            $message    = "L'utilisateur n'a pas pu être créé (login déjà utilisé ?).";
            $view       = 'error';
            $pagetitle  = 'Erreur';
        }
        require File::build_path(array('view', 'view.php'));
    }

    // Action update : affiche le formulaire de mise à jour pré-rempli.
    public static function update()
    {
        $login = isset($_GET['login']) ? $_GET['login'] : null;
        $u     = ModelUtilisateur::select($login);

        if ($u === false) {
            $message    = "Aucun utilisateur ne correspond au login " . $login . '.';
            $view       = 'error';
            $pagetitle  = 'Erreur';
        } else {
            // Les champs du formulaire sont pré-remplis avec l'utilisateur
            $login  = $u->getLogin();
            $nom    = $u->getNom();
            $prenom = $u->getPrenom();

            $champ_login = 'readonly';  // on ne modifie pas la clé primaire
            $action_form = 'updated';   // action appelée à l'envoi du formulaire

            $view       = 'update';
            $pagetitle  = "Mise à jour d'un utilisateur";
        }
        require File::build_path(array('view', 'view.php'));
    }

    // Action updated : met à jour l'utilisateur puis affiche la liste.
    public static function updated()
    {
        // On vérifie que les données du formulaire sont bien présentes
        if (!isset($_GET['login']) || !isset($_GET['nom']) || !isset($_GET['prenom'])) {
            self::error();
            return;
        }

        $login = $_GET['login'];
        $data  = array(
            'login'  => $login,
            'nom'    => $_GET['nom'],
            'prenom' => $_GET['prenom'],
        );
        ModelUtilisateur::update($data);

        $tab_u      = ModelUtilisateur::selectAll();
        $view       = 'updated';
        $pagetitle  = 'Utilisateur mis à jour';
        require File::build_path(array('view', 'view.php'));
    }

    // Action delete : supprime l'utilisateur puis affiche la liste.
    // Attention : grâce aux clés étrangères ON DELETE CASCADE (TD3), ses trajets
    // de conducteur et ses inscriptions comme passager sont aussi supprimés.
    public static function delete()
    {
        if (!isset($_GET['login'])) {
            self::error();
            return;
        }
        $login = $_GET['login'];
        ModelUtilisateur::delete($login);
        $tab_u      = ModelUtilisateur::selectAll();
        $view       = 'deleted';
        $pagetitle  = "Suppression d'un utilisateur";
        require File::build_path(array('view', 'view.php'));
    }

    // Action readTrajets : affiche les trajets dont l'utilisateur est passager.
    public static function readTrajets()
    {
        $login = isset($_GET['login']) ? $_GET['login'] : null;
        $u     = ModelUtilisateur::select($login);

        if ($u === false) {
            $message    = "Aucun utilisateur ne correspond au login " . $login . '.';
            $view       = 'error';
            $pagetitle  = 'Erreur';
        } else {
            $tab_t      = ModelUtilisateur::getTrajets($login);
            $view       = 'trajets';
            $pagetitle  = "Trajets de l'utilisateur";
        }
        require File::build_path(array('view', 'view.php'));
    }

    // Action error : affiche la vue d'erreur.
    public static function error()
    {
        $message    = "Cette action n'existe pas.";
        $view       = 'error';
        $pagetitle  = 'Erreur';
        require File::build_path(array('view', 'view.php'));
    }
}
