<?php

require_once File::build_path(array('model', 'ModelTrajet.php'));
require_once File::build_path(array('model', 'ModelUtilisateur.php'));  // liste des conducteurs et passagers

class ControllerTrajet
{
    // Nom de l'objet géré : sert à la vue générique pour trouver le dossier view/trajet/
    protected static $object = 'trajet';

    // Champs du formulaire (= champs de la table trajet, sauf l'id auto-incrémenté)
    private static $champs = array('depart', 'arrivee', 'date', 'nbplaces', 'prix', 'conducteur_login');

    // Une action correspond généralement à une page Web.

    // Action readAll : affiche tous les trajets.
    public static function readAll()
    {
        $tab_t      = ModelTrajet::selectAll();               // appel au modèle pour gérer la BD
        $view       = 'list';
        $pagetitle  = 'Liste des trajets';
        require File::build_path(array('view', 'view.php'));  // vue générique
    }

    // Action read : affiche le détail du trajet dont l'id est passé dans l'URL.
    public static function read()
    {
        $id = isset($_GET['id']) ? $_GET['id'] : null;
        $t  = ModelTrajet::select($id);

        if ($t === false) {
            $message    = 'Aucun trajet ne correspond à l\'identifiant ' . $id . '.';
            $view       = 'error';
            $pagetitle  = 'Erreur';
        } else {
            $view       = 'detail';
            $pagetitle  = 'Détail du trajet';
        }
        require File::build_path(array('view', 'view.php'));
    }

    // Action delete : supprime le trajet puis affiche la liste.
    public static function delete()
    {
        if (!isset($_GET['id'])) {
            self::error();
            return;
        }
        $id = $_GET['id'];
        ModelTrajet::delete($id);
        $tab_t      = ModelTrajet::selectAll();
        $view       = 'deleted';
        $pagetitle  = "Suppression d'un trajet";
        require File::build_path(array('view', 'view.php'));
    }

    // Action create : affiche le formulaire (vide) de création d'un trajet.
    public static function create()
    {
        // Les champs du formulaire sont vides ($id vide : pas de champ id affiché)
        $id               = '';
        $depart           = '';
        $arrivee          = '';
        $date             = '';
        $nbplaces         = '';
        $prix             = '';
        $conducteur_login = '';

        $tab_u       = ModelUtilisateur::selectAll();  // pour la liste déroulante des conducteurs
        $action_form = 'save';                         // action appelée à l'envoi du formulaire

        $view       = 'update';
        $pagetitle  = "Création d'un trajet";
        require File::build_path(array('view', 'view.php'));
    }

    // Action update : affiche le formulaire de mise à jour pré-rempli.
    public static function update()
    {
        $id = isset($_GET['id']) ? $_GET['id'] : null;
        $t  = ModelTrajet::select($id);

        if ($t === false) {
            $message    = 'Aucun trajet ne correspond à l\'identifiant ' . $id . '.';
            $view       = 'error';
            $pagetitle  = 'Erreur';
        } else {
            // Les champs du formulaire sont pré-remplis avec le trajet
            $id               = $t->getId();
            $depart           = $t->getDepart();
            $arrivee          = $t->getArrivee();
            $date             = $t->getDate();
            $nbplaces         = $t->getNbplaces();
            $prix             = $t->getPrix();
            $conducteur_login = $t->getConducteurLogin();

            $tab_u       = ModelUtilisateur::selectAll();
            $action_form = 'updated';

            $view       = 'update';
            $pagetitle  = "Mise à jour d'un trajet";
        }
        require File::build_path(array('view', 'view.php'));
    }

    // Action save : enregistre le trajet reçu puis réaffiche la liste.
    public static function save()
    {
        // On vérifie que chaque champ est présent et on remplit $data
        $data = array();
        foreach (self::$champs as $champ) {
            if (!isset($_GET[$champ])) {
                self::error();
                return;
            }
            $data[$champ] = $_GET[$champ];
        }

        if (ModelTrajet::save($data)) {
            $tab_t      = ModelTrajet::selectAll();
            $view       = 'created';
            $pagetitle  = 'Trajet créé';
        } else {
            $message    = "Le trajet n'a pas pu être créé.";
            $view       = 'error';
            $pagetitle  = 'Erreur';
        }
        require File::build_path(array('view', 'view.php'));
    }

    // Action updated : met à jour le trajet puis affiche la liste.
    public static function updated()
    {
        if (!isset($_GET['id'])) {
            self::error();
            return;
        }
        $id   = $_GET['id'];
        $data = array('id' => $id);  // la clé primaire est nécessaire pour le WHERE
        foreach (self::$champs as $champ) {
            if (!isset($_GET[$champ])) {
                self::error();
                return;
            }
            $data[$champ] = $_GET[$champ];
        }

        ModelTrajet::update($data);

        $tab_t      = ModelTrajet::selectAll();
        $view       = 'updated';
        $pagetitle  = 'Trajet mis à jour';
        require File::build_path(array('view', 'view.php'));
    }

    // Action readPassagers : affiche la liste des passagers d'un trajet.
    public static function readPassagers()
    {
        $id = isset($_GET['id']) ? $_GET['id'] : null;
        $t  = ModelTrajet::select($id);

        if ($t === false) {
            $message    = 'Aucun trajet ne correspond à l\'identifiant ' . $id . '.';
            $view       = 'error';
            $pagetitle  = 'Erreur';
        } else {
            $tab_u      = ModelTrajet::getPassagers($id);
            $view       = 'passagers';
            $pagetitle  = 'Passagers du trajet';
        }
        require File::build_path(array('view', 'view.php'));
    }

    // Action error : affiche la vue d'erreur.
    public static function error()
    {
        $message    = "Cette action n'existe pas.";
        $view       = 'error';
        $pagetitle  = 'Erreur';
        require File::build_path(array('view', 'view.php'));
    }
}
