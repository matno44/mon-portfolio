<?php

require_once File::build_path(array('model', 'ModelVoiture.php'));

class ControllerVoiture
{
    // Nom de l'objet géré : sert à la vue générique pour trouver le dossier view/voiture/
    protected static $object = 'voiture';

    // Une action correspond généralement à une page Web.

    // Action readAll : affiche toutes les voitures.
    public static function readAll()
    {
        $tab_v      = ModelVoiture::selectAll();              // appel au modèle pour gérer la BD
        $view       = 'list';
        $pagetitle  = 'Liste des voitures';
        require File::build_path(array('view', 'view.php'));  // vue générique
    }

    // Action read : affiche le détail de la voiture dont l'immatriculation
    // est passée dans l'URL.
    public static function read()
    {
        $immat = isset($_GET['immat']) ? $_GET['immat'] : null;
        $v     = ModelVoiture::select($immat);

        if ($v === false) {
            $message    = "Aucune voiture ne correspond à l'immatriculation " . $immat . '.';
            $view       = 'error';
            $pagetitle  = 'Erreur';
        } else {
            $view       = 'detail';
            $pagetitle  = 'Détail de la voiture';
        }
        require File::build_path(array('view', 'view.php'));
    }

    // Action create : affiche le formulaire (vide) de création d'une voiture.
    // On utilise la même vue update.php que pour la mise à jour.
    public static function create()
    {
        // Les champs du formulaire sont vides
        $immat   = '';
        $marque  = '';
        $couleur = '';

        $champ_immat = 'required';  // on doit saisir l'immatriculation
        $action_form = 'save';      // action appelée à l'envoi du formulaire

        $view       = 'update';
        $pagetitle  = "Création d'une voiture";
        require File::build_path(array('view', 'view.php'));
    }

    // Action save : enregistre la voiture reçue puis réaffiche la liste.
    // (remplace l'ancienne action created)
    public static function save()
    {
        // On vérifie que les données du formulaire sont bien présentes
        if (!isset($_GET['immatriculation']) || !isset($_GET['marque']) || !isset($_GET['couleur'])) {
            self::error();
            return;
        }

        // i. tableau associatif : les clés sont les noms des champs de la table
        $data = array(
            'immatriculation' => $_GET['immatriculation'],
            'marque'          => $_GET['marque'],
            'couleur'         => $_GET['couleur'],
        );

        // ii. enregistrement dans la BDD avec la méthode générique save($data)
        if (ModelVoiture::save($data)) {
            // iii. affichage : message de confirmation puis liste des voitures
            $tab_v      = ModelVoiture::selectAll();  // à initialiser pour list.php
            $view       = 'created';
            $pagetitle  = 'Voiture créée';
        } else {
            $message    = "La voiture n'a pas pu être créée (immatriculation déjà utilisée ?).";
            $view       = 'error';
            $pagetitle  = 'Erreur';
        }
        require File::build_path(array('view', 'view.php'));
    }

    // Action delete : supprime la voiture puis affiche la liste.
    public static function delete()
    {
        if (!isset($_GET['immat'])) {
            self::error();
            return;
        }
        $immat = $_GET['immat'];
        ModelVoiture::delete($immat);
        $tab_v      = ModelVoiture::selectAll();
        $view       = 'deleted';
        $pagetitle  = 'suppression d une voiture';
        require File::build_path(array('view', 'view.php'));
    }

    // Action update : affiche le formulaire de mise à jour pré-rempli.
    public static function update()
    {
        $immat = isset($_GET['immat']) ? $_GET['immat'] : null;
        $v     = ModelVoiture::select($immat);

        if ($v === false) {
            $message    = "Aucune voiture ne correspond à l'immatriculation " . $immat . '.';
            $view       = 'error';
            $pagetitle  = 'Erreur';
        } else {
            // Les champs du formulaire sont pré-remplis avec la voiture
            $immat   = $v->getImmatriculation();
            $marque  = $v->getMarque();
            $couleur = $v->getCouleur();

            $champ_immat = 'readonly';  // on ne modifie pas la clé primaire
            $action_form = 'updated';   // action appelée à l'envoi du formulaire

            $view       = 'update';
            $pagetitle  = "Mise à jour d'une voiture";
        }
        require File::build_path(array('view', 'view.php'));
    }

    // Action updated : met à jour la voiture puis affiche la liste.
    public static function updated()
    {
        // On vérifie que les données du formulaire sont bien présentes
        if (!isset($_GET['immatriculation']) || !isset($_GET['marque']) || !isset($_GET['couleur'])) {
            self::error();
            return;
        }

        // i. récupération de l'immatriculation (pour le message de la vue)
        $immat = $_GET['immatriculation'];

        // ii. tableau associatif : les clés sont les noms des champs de la table
        $data = array(
            'immatriculation' => $immat,
            'marque'          => $_GET['marque'],
            'couleur'         => $_GET['couleur'],
        );

        // iii. mise à jour dans la BDD avec la méthode générique update($data)
        ModelVoiture::update($data);

        // iv. affichage : message de confirmation puis liste des voitures
        $tab_v      = ModelVoiture::selectAll();
        $view       = 'updated';
        $pagetitle  = 'Voiture mise à jour';
        require File::build_path(array('view', 'view.php'));
    }

    // Action error : affiche la vue d'erreur (action inconnue, par exemple).
    public static function error()
    {
        $message    = "Cette action n'existe pas.";
        $view       = 'error';
        $pagetitle  = 'Erreur';
        require File::build_path(array('view', 'view.php'));
    }
}
