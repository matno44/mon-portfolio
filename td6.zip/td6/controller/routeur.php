<?php

require_once File::build_path(array('controller', 'ControllerVoiture.php'));
require_once File::build_path(array('controller', 'ControllerUtilisateur.php'));
require_once File::build_path(array('controller', 'ControllerTrajet.php'));

// On récupère l'action passée dans l'URL (query string).
// Sans paramètre, on affiche la liste par défaut.
$action = isset($_GET['action']) ? $_GET['action'] : 'readAll';

// On récupère le contrôleur passé dans l'URL, voiture par défaut.
$controller = isset($_GET['controller']) ? $_GET['controller'] : 'voiture';

// Nom de la classe du contrôleur : 'voiture' => 'ControllerVoiture'
$controller_class = 'Controller' . ucfirst($controller);

// On vérifie que la classe du contrôleur existe
// puis que $action est bien une méthode de ce contrôleur.
if (class_exists($controller_class) && in_array($action, get_class_methods($controller_class))) {
    $controller_class::$action();
} else {
    ControllerVoiture::error();
}
