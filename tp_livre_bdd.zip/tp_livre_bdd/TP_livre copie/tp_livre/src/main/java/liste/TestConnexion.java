package liste;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Locale;

public class TestConnexion {
    public static void main(String[] args) {
        
        // --- LE FIX MAGIQUE ---
        // On force le driver à utiliser l'anglais pour éviter le bug "fr_FR"
        Locale.setDefault(Locale.US);
        // ----------------------

        // Paramètres (XAMPP n'a pas de mot de passe par défaut, MAMP a "root")
        String url = "jdbc:mysql://localhost:3306/bdd_skiplus";
        String utilisateur = "root";
        String motDePasse = ""; // <-- Laisse vide si tu es sur XAMPP. Mets "root" si tu es sur MAMP.

        System.out.println("Tentative de connexion...");

        try {
            // Chargement explicite du driver (pour être sûr)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connexion
            Connection connexion = DriverManager.getConnection(url, utilisateur, motDePasse);
            System.out.println("✅ Succès ! La connexion est établie.");
            connexion.close();

        } catch (ClassNotFoundException e) {
            System.out.println("❌ Erreur : Le driver MySQL est introuvable (Vérifie Referenced Libraries).");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("❌ Erreur SQL : " + e.getMessage());
            e.printStackTrace();
        }
    }
}