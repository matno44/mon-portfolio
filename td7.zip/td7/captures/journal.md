# Journal des captures – TD7 Cookies & sessions

Environnement : serveur intégré PHP lancé avec le PHP de XAMPP (`/Applications/XAMPP/xamppfiles/bin/php -S localhost:8000 -t td7`, PHP 8.0.28), base MySQL `garage` de XAMPP.

Remarque : un premier essai avec le `php` du PATH (PHP 8.5 Homebrew) affichait un avertissement « Deprecated: Constant PDO::MYSQL_ATTR_INIT_COMMAND is deprecated since 8.5 » sur les pages du site (Model.php). Toutes les captures ont donc été refaites avec le PHP 8.0 de XAMPP, la version utilisée par le site sous Apache ; aucune erreur PHP sur les captures finales.
Captures navigateur : Playwright + Chromium, fenêtre 1280x800, PNG.
Captures de code : page HTML générée avec highlight.js 11.9.0 (thème GitHub clair) capturée avec Playwright.
Captures DevTools : Google Chrome lancé en mode visible, DevTools ouverts sur Application > Cookies (pilotés via le protocole DevTools), capture avec la commande macOS `screencapture`.

Le site de covoiturage du TD6 a été copié dans `td7/covoiturage/` pour garder le rendu du TD6 intact.

## Exercice 1 – Cookies (`td7/exercice1_cookies.php`)

| Capture | Étape | Ce qu'elle montre | Résultat |
|---|---|---|---|
| ex1_code_cookies.png | code | Partie PHP du fichier (lignes 1 à 47) : un `if/elseif` sur `$_GET['action']`, tous les `setcookie()` placés avant le HTML. | – |
| ex1_1_ecrire_cookie.png | 1. Déposer | `?action=ecrire` : `setcookie('TestCookie', 'OK', time() + 3600)`. | Message « cookie déposé ». `$_COOKIE` est encore **vide** (`array(0)`) : le cookie ne sera envoyé par le navigateur qu'à la requête suivante. |
| ex1_2_cookie_devtools.png | 2. Vérifier | Vrai Chrome + DevTools (en français) > Application > Cookies > http://localhost:8000, ligne TestCookie sélectionnée. | Cookie `TestCookie` = `OK`, domaine localhost, chemin `/`, date d'expiration 1 h plus tard, aperçu « Cookie Value : OK ». |
| ex1_3_lire_cookie.png | 3. Lire | `?action=lire` : lecture avec `$_COOKIE['TestCookie']`. | « Valeur du cookie TestCookie : OK », `var_dump($_COOKIE)` contient TestCookie. |
| ex1_4_supprimer_cookie.png | 4. Supprimer | `?action=supprimer` : `setcookie('TestCookie', '', time() - 1)`. | Message de suppression ; `$_COOKIE` contient encore TestCookie car le navigateur l'a envoyé avec cette requête. |
| ex1_4_lire_apres_suppression.png | 4. Vérification | `?action=lire` juste après. | « Le cookie TestCookie n'existe pas. », `$_COOKIE` vide : le navigateur a bien supprimé le cookie périmé. |
| ex1_5_stocker_tableau.png | 5. Tableau | `?action=tableau` : `setcookie('TabCookie', serialize($tab), ...)`. | Affiche la chaîne sérialisée `a:3:{s:3:"nom";s:6:"Dupont";...}`. |
| ex1_5_relire_tableau.png | 5. Relire | `?action=lireTableau` : `unserialize($_COOKIE['TabCookie'])`. | `var_dump` du tableau reconstruit (nom, prenom, ville) et « Prénom lu dans le tableau : Marie » ; `$_COOKIE` contient la chaîne texte de 78 caractères. |

## Exercice 2 – Sessions (`td7/exercice2_sessions.php`)

| Capture | Étape | Ce qu'elle montre | Résultat |
|---|---|---|---|
| ex2_code_1_classe_session_start.png | code | Lignes 1 à 34 : classe de test `Personne` déclarée avant `session_start()` (pour que l'objet soit reconstruit), puis `session_start()` avant tout HTML. | – |
| ex2_code_2_actions.png | code | Lignes 36 à 65 : écriture (chaîne, entier, tableau, objet), lecture avec `isset`, `unset`, destruction complète (`session_unset`, `session_destroy`, `setcookie(session_name(), '', time() - 1)`). | – |
| ex2_1_demarrer_session.png | 1. Démarrer | `?action=demarrer`. | Identifiant de session PHPSESSID affiché, `$_SESSION` vide (`array(0)`). |
| ex2_2_ecrire_variables.png | 2. Écrire | `?action=ecrire`. | `var_dump($_SESSION)` : login string "marie", age int(20), panier array(2), personne object(Personne) avec ses attributs privés. Pas besoin de `serialize()`, contrairement aux cookies. |
| ex2_3_lire_variable.png | 3. Lire | `?action=lire` (nouvelle requête). | « Valeur de $_SESSION['login'] : marie / nom de l'objet Personne : Dupont » : les données ont été conservées côté serveur entre deux requêtes. |
| ex2_4_supprimer_variable.png | 4. Supprimer | `?action=supprimer` : `unset($_SESSION['login'])`. | `$_SESSION` ne contient plus que 3 éléments (age, panier, personne). |
| ex2_5_detruire_session.png | 5. Détruire | `?action=detruire`. | `$_SESSION` vide (`array(0)`). Vérifié avec `context.cookies()` de Playwright : avant = `TabCookie`, `PHPSESSID=8d8ilijq...` ; après = `TabCookie` seul → le cookie PHPSESSID a bien été supprimé. |
| ex2_5_lire_apres_destruction.png | 5. Vérification | `?action=lire` après destruction. | « La variable de session login n'existe pas. », `$_SESSION` vide : une nouvelle session vierge a été créée. |

## Exercice 3 – Page d'accueil personnalisée par cookie (`td7/covoiturage/`)

Les trois contrôleurs (voiture, trajet, utilisateur) existent depuis le TD6 : on personnalise donc bien le **contrôleur** par défaut (pas besoin de la variante « vue par défaut » du sujet).

| Capture | Étape | Ce qu'elle montre | Résultat |
|---|---|---|---|
| ex3_1_code_preference_html.png | 1. code | `preference.html` : formulaire GET vers `personalisation.php`, trois boutons radio `name="preference"` (voiture cochée par défaut, trajet, utilisateur). | – |
| ex3_1_formulaire_preference.png | 1. résultat | Le formulaire affiché dans le navigateur. | Trois choix + bouton « Enregistrer ma préférence ». |
| ex3_2_code_personalisation.png | 2. code | `personalisation.php` : vérification de la valeur avec `in_array` (liste blanche), `setcookie('preference', ..., time() + 30*24*3600)` puis `header('Location: index.php')`. | – |
| ex3_3_cookie_preference_devtools.png | 3. Vérifier | Vrai Chrome + DevTools > Application > Cookies après envoi de « trajet ». | Cookie `preference` = `trajet`, domaine localhost, chemin `/covoiturage` (chemin du script qui l'a déposé), expiration dans 30 jours. La page affichée est `localhost:8000/covoiturage/index.php` **sans paramètre** et montre la liste des trajets. |
| ex3_4_code_menu_view.png | 4. code | `view/view.php` (en-tête commune) : ajout du lien `<a href="preference.html">Préférence d'accueil</a>` dans le `<nav>`. | – |
| ex3_4_menu_lien_preference.png | 4. résultat | Page d'accueil avec le menu ; le nouveau lien est encadré en rouge (encadré ajouté uniquement pour la capture). | Le lien apparaît sur toutes les pages du site ; un clic mène bien à `preference.html` (vérifié par le script). |
| ex3_5_code_routeur.png | 5. code | `routeur.php` : i. `$controller_default = 'voiture'` ; iii. remplacé par `$_COOKIE['preference']` si le cookie existe et contient une valeur autorisée ; ii. `$controller` vaut `$_GET['controller']` sinon `$controller_default`. | – |
| ex3_6_accueil_sans_cookie_voiture.png | 6. Test | `index.php` sans cookie (cookies effacés). | Liste des voitures : comportement par défaut conservé. |
| ex3_6_formulaire_rempli_trajet.png | 6. Test | Formulaire avec « Liste des trajets » coché. | – |
| ex3_6_accueil_trajet.png | 6. Test | Page obtenue après envoi : redirection vers `covoiturage/index.php` (URL sans paramètre). | Liste des trajets (4 trajets) au lieu des voitures. Une nouvelle visite de `index.php` affiche toujours « Liste des trajets ». |
| ex3_6_formulaire_rempli_utilisateur.png | 6. Test | Formulaire avec « Liste des utilisateurs » coché. | – |
| ex3_6_accueil_utilisateur.png | 6. Test | Page obtenue après envoi (`covoiturage/index.php`). | Liste des utilisateurs (alid, bmar, johd, matk, rubb). |

Test de sécurité (sans capture) : appel manuel de `personalisation.php?preference=admin` → le cookie n'est pas modifié (reste `utilisateur`) et l'accueil reste la liste des utilisateurs. De même, un cookie `preference=pirate` forgé à la main est ignoré par le routeur (accueil = voitures).

## Exercice 4 – Panier en session avec prix et expiration (`td7/covoiturage/`)

Le site du TD6 n'avait pas de panier : un panier minimal a été créé dans le MVC (nouveau contrôleur `ControllerPanier` avec les actions `readAll`, `ajouter`, `vider`, `error` ; vues `view/panier/list.php` et `error.php` ; lien « ajouter au panier » et prix dans `view/trajet/list.php` ; lien « Mon panier (total €) » dans le menu de `view/view.php` ; `require_once` du contrôleur dans `routeur.php`). Le panier contient des trajets (départ, arrivée, prix lu en base, nombre de places).

| Capture | Étape | Ce qu'elle montre | Résultat |
|---|---|---|---|
| ex4_1_code_index_session_10s.png | 1, 2, 3, 4 code | `index.php` : `session_start()` tout en haut (avant le HTML, avant le routeur) ; constante `DUREE_PANIER` = 10 ; test `time() - $_SESSION['LAST_ACTIVITY'] > DUREE_PANIER` → `session_unset()`, `session_destroy()`, `session_start()` ; mise à jour de `LAST_ACTIVITY` ; initialisation de `$_SESSION['panier']` ; calcul du prix total à chaque appel et stockage dans `$_SESSION['prix_total']`. | – |
| ex4_2_code_controller_panier.png | 2. code | `ControllerPanier` : `ajouter` lit le trajet avec `ModelTrajet::select($id)` (le prix vient de la BDD, pas de l'URL), ajoute une ligne ou incrémente la quantité dans `$_SESSION['panier']`, puis redirige vers le panier pour que `index.php` recalcule le total ; `vider` remet un tableau vide. | – |
| ex4_2_code_vue_panier.png | 2. code | `view/panier/list.php` : tableau des trajets, prix total lu dans la session, `var_dump($_SESSION)` de vérification. | – |
| ex4_2_liste_trajets_ajouter_panier.png | 2. résultat | Liste des trajets avec leur prix et le lien « ajouter au panier » ; menu « Mon panier (0 €) ». | – |
| ex4_3_panier_rempli_prix_total.png | 3. résultat | Capture pleine page (fenêtre 1280x800). Panier après 3 clics (trajet 1, trajet 3, trajet 1) à 15:42:14. | 2 × Lille → Paris (40 €) + 1 × Lyon → Marseille (25 €) ; **Prix total : 65 €**, aussi dans le menu ; `$_SESSION` contient `LAST_ACTIVITY` (1793544134), `panier` et `prix_total` = int(65). |
| ex4_4_panier_vide_apres_11s.png | 4. test 10 s | Capture pleine page. Même page rechargée après 11 s sans aucune requête (15:42:25). | « Votre panier est vide. », prix total 0 €, menu « Mon panier (0 €) » ; `$_SESSION` ne contient plus qu'une nouvelle `LAST_ACTIVITY` (1793544145, soit 11 s plus tard), un panier vide et `prix_total` = 0 → la session a bien expiré. |
| ex4_4_code_index_session_600s.png | 4. code final | `index.php` avec `define('DUREE_PANIER', 600); // 10 minutes = 10 * 60 secondes`. | – |
| ex4_4_panier_conserve_600s.png | 4. vérification | Capture pleine page. Avec 600 s : ajout des trajets 2 et 4 à 15:42:26, attente de 11 s, rechargement à 15:42:37 (LAST_ACTIVITY = 1793544157). | Panier conservé : Paris → Lyon 35 € + Bordeaux → Toulouse 15 € = **50 €** ; message « vidé automatiquement après 600 secondes d'inactivité ». |

Non-régression (sans capture) : toutes les pages du site (listes, détails, formulaires de création/mise à jour, passagers, trajets d'un utilisateur, erreurs) répondent sans erreur PHP après les modifications. Un `id` de trajet inexistant (`ajouter&id=99`) affiche « Aucun trajet ne correspond à l'identifiant 99. ».

Remarque : les trois captures du panier ont été refaites en pleine page (`fullPage`), car le `var_dump($_SESSION)` dépassait les 800 px de la fenêtre et la dernière ligne (`int(65)` / `int(50)`) était coupée. Pour cela la constante a été repassée temporairement à 10 s puis remise à 600 s (valeur finale du fichier).
