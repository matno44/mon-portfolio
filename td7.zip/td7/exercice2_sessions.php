<?php
// TD7 - Exercice 2 : manipulation des sessions
// Chaque étape correspond à un paramètre GET "action" :
//   ?action=demarrer   -> démarre la session (cookie PHPSESSID)
//   ?action=ecrire     -> écrit des variables de types différents
//   ?action=lire       -> lit une variable de session
//   ?action=supprimer  -> supprime une variable avec unset()
//   ?action=detruire   -> supprime complètement la session

// Petite classe de test pour montrer qu'on peut stocker un objet en session
// (la classe doit être déclarée AVANT session_start() pour que l'objet
// soit bien reconstruit à la lecture de la session)
class Personne
{
    private $nom;
    private $age;

    public function __construct($nom, $age)
    {
        $this->nom = $nom;
        $this->age = $age;
    }

    public function getNom()
    {
        return $this->nom;
    }
}

// 1. Démarrer la session : TOUJOURS avant toute sortie HTML
session_start();

$action  = isset($_GET['action']) ? $_GET['action'] : '';
$message = '';

if ($action == 'demarrer') {
    $message = 'Session démarrée. Identifiant de session (' . session_name() . ') : ' . session_id();
} elseif ($action == 'ecrire') {
    // 2. Écrire des variables de session de types différents
    $_SESSION['login']    = 'marie';                                // chaîne de caractères
    $_SESSION['age']      = 20;                                     // entier
    $_SESSION['panier']   = array('Lille-Paris', 'Lyon-Marseille'); // tableau
    $_SESSION['personne'] = new Personne('Dupont', 20);             // objet
    $message = 'Quatre variables de session ont été écrites (chaîne, entier, tableau, objet).';
} elseif ($action == 'lire') {
    // 3. Lire une variable de session (on vérifie d'abord qu'elle existe)
    if (isset($_SESSION['login'])) {
        $message = 'Valeur de $_SESSION[\'login\'] : ' . htmlspecialchars($_SESSION['login']);
        if (isset($_SESSION['personne'])) {
            $message .= ' / nom de l\'objet Personne : ' . htmlspecialchars($_SESSION['personne']->getNom());
        }
    } else {
        $message = "La variable de session login n'existe pas.";
    }
} elseif ($action == 'supprimer') {
    // 4. Supprimer une seule variable de session
    unset($_SESSION['login']);
    $message = 'La variable $_SESSION[\'login\'] a été supprimée avec unset().';
} elseif ($action == 'detruire') {
    // 5. Suppression complète de la session
    session_unset();                            // vide le tableau $_SESSION
    session_destroy();                          // supprime le fichier de session sur le serveur
    setcookie(session_name(), '', time() - 1);  // demande au navigateur de supprimer le cookie PHPSESSID
    $message = 'La session a été complètement détruite (session_unset, session_destroy, cookie supprimé).';
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>TD7 - Exercice 2 : les sessions</title>
</head>
<body>
    <h1>Exercice 2 : les sessions</h1>
    <nav>
        <a href="exercice2_sessions.php?action=demarrer">1. Démarrer</a> |
        <a href="exercice2_sessions.php?action=ecrire">2. Écrire</a> |
        <a href="exercice2_sessions.php?action=lire">3. Lire</a> |
        <a href="exercice2_sessions.php?action=supprimer">4. Supprimer une variable</a> |
        <a href="exercice2_sessions.php?action=detruire">5. Détruire la session</a>
    </nav>

    <h2>Action : <?php echo htmlspecialchars($action); ?></h2>
    <p><strong><?php echo $message; ?></strong></p>

    <h3>État de $_SESSION :</h3>
    <pre><?php var_dump($_SESSION); ?></pre>
</body>
</html>
