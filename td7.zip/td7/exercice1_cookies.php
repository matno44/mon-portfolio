<?php
// TD7 - Exercice 1 : manipulation des cookies
// Chaque étape correspond à un paramètre GET "action" :
//   ?action=ecrire     -> dépose le cookie TestCookie (expire dans 1 h)
//   ?action=lire       -> lit le cookie avec $_COOKIE
//   ?action=supprimer  -> supprime le cookie (date d'expiration dépassée)
//   ?action=tableau    -> stocke un tableau dans un cookie avec serialize()
//   ?action=lireTableau-> relit le tableau avec unserialize()
// Remarque : un cookie déposé n'est envoyé par le navigateur qu'à la requête
// suivante, c'est pour cela qu'on sépare l'écriture et la lecture.

$action  = isset($_GET['action']) ? $_GET['action'] : '';
$message = '';

// IMPORTANT : tous les setcookie() sont faits AVANT la moindre sortie HTML,
// car le cookie est envoyé dans l'en-tête HTTP (ligne Set-Cookie).
if ($action == 'ecrire') {
    // 1. Déposer un cookie nommé TestCookie, valeur "OK", qui expire dans 1 heure
    setcookie('TestCookie', 'OK', time() + 3600);
    $message = 'Le cookie TestCookie a été déposé (valeur "OK", expire dans 1 heure).';
} elseif ($action == 'lire') {
    // 3. Lire le cookie envoyé par le navigateur
    if (isset($_COOKIE['TestCookie'])) {
        $message = 'Valeur du cookie TestCookie : ' . htmlspecialchars($_COOKIE['TestCookie']);
    } else {
        $message = "Le cookie TestCookie n'existe pas.";
    }
} elseif ($action == 'supprimer') {
    // 4. Supprimer le cookie : on lui donne une date d'expiration déjà passée
    setcookie('TestCookie', '', time() - 1);
    $message = 'Le cookie TestCookie a été supprimé (expiration à time() - 1).';
} elseif ($action == 'tableau') {
    // 5. Un cookie ne contient que du texte : on transforme le tableau
    //    en chaîne avec serialize() avant de le stocker
    $tab = array('nom' => 'Dupont', 'prenom' => 'Marie', 'ville' => 'Lille');
    setcookie('TabCookie', serialize($tab), time() + 3600);
    $message = 'Le tableau a été stocké dans le cookie TabCookie : ' . htmlspecialchars(serialize($tab));
} elseif ($action == 'lireTableau') {
    // 5. (suite) On relit la chaîne et on reconstruit le tableau avec unserialize()
    if (isset($_COOKIE['TabCookie'])) {
        $tab     = unserialize($_COOKIE['TabCookie']);
        $message = 'Tableau récupéré depuis le cookie TabCookie :';
    } else {
        $message = "Le cookie TabCookie n'existe pas.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>TD7 - Exercice 1 : les cookies</title>
</head>
<body>
    <h1>Exercice 1 : les cookies</h1>
    <nav>
        <a href="exercice1_cookies.php?action=ecrire">1. Écrire le cookie</a> |
        <a href="exercice1_cookies.php?action=lire">3. Lire le cookie</a> |
        <a href="exercice1_cookies.php?action=supprimer">4. Supprimer le cookie</a> |
        <a href="exercice1_cookies.php?action=tableau">5. Stocker un tableau</a> |
        <a href="exercice1_cookies.php?action=lireTableau">5. Relire le tableau</a>
    </nav>

    <h2>Action : <?php echo htmlspecialchars($action); ?></h2>
    <p><strong><?php echo $message; ?></strong></p>

    <?php
    // Affichage du tableau relu depuis le cookie
    if ($action == 'lireTableau' && isset($tab)) {
        echo '<pre>';
        var_dump($tab);
        echo '</pre>';
        echo '<p>Prénom lu dans le tableau : ' . htmlspecialchars($tab['prenom']) . '</p>';
    }
    ?>

    <h3>Contenu de $_COOKIE reçu avec cette requête :</h3>
    <pre><?php var_dump($_COOKIE); ?></pre>
</body>
</html>
