<!DOCTYPE html>
<html>
 <head>
 <meta charset="UTF-8">
 <title><?php echo $pagetitle; ?></title>
 </head>
 <body>
    <nav>
        <a href="index.php?action=readAll&controller=voiture">Liste des voitures</a>
        <a href="index.php?action=readAll&controller=utilisateur">Liste des utilisateurs</a>
        <a href="index.php?action=readAll&controller=trajet">Liste des trajets</a>
        <a href="preference.html">Préférence d'accueil</a>
        <a href="index.php?controller=panier&action=readAll">Mon panier (<?php echo htmlspecialchars($_SESSION['prix_total']); ?> €)</a>

    </nav>
<?php
// Cette vue est incluse depuis une méthode du contrôleur : static::$object
// lit donc l'attribut $object du contrôleur qui l'appelle.
// Si static::$object='voiture' et $view='list',
// alors $filepath="/chemin_du_site/view/voiture/list.php"
$filepath = File::build_path(array('view', static::$object, "$view.php"));
require $filepath;
?>
<p style="border: 1px solid black;text-align:right;padding-right:1em;">
 Site de covoiturage de ...
</p>
 </body>
 
</html>