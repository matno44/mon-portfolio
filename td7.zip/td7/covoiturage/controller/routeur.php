<?php

require_once File::build_path(array('controller', 'ControllerVoiture.php'));
require_once File::build_path(array('controller', 'ControllerUtilisateur.php'));
require_once File::build_path(array('controller', 'ControllerTrajet.php'));
require_once File::build_path(array('controller', 'ControllerPanier.php'));

// On récupère l'action passée dans l'URL (query string).
// Sans paramètre, on affiche la liste par défaut.
$action = isset($_GET['action']) ? $_GET['action'] : 'readAll';

// TD7 - Exercice 3 : contrôleur par défaut personnalisable par cookie.
// i. voiture par défaut
$controller_default = 'voiture';
// iii. si le cookie preference existe et contient une valeur autorisée,
//      il remplace le contrôleur par défaut
if (isset($_COOKIE['preference']) && in_array($_COOKIE['preference'], array('voiture', 'trajet', 'utilisateur'))) {
    $controller_default = $_COOKIE['preference'];
}

// ii. On récupère le contrôleur passé dans l'URL, $controller_default sinon.
$controller = isset($_GET['controller']) ? $_GET['controller'] : $controller_default;

// Nom de la classe du contrôleur : 'voiture' => 'ControllerVoiture'
$controller_class = 'Controller' . ucfirst($controller);

// On vérifie que la classe du contrôleur existe
// puis que $action est bien une méthode de ce contrôleur.
if (class_exists($controller_class) && in_array($action, get_class_methods($controller_class))) {
    $controller_class::$action();
} else {
    ControllerVoiture::error();
}
