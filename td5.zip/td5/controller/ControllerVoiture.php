<?php

require_once File::build_path(array('model', 'ModelVoiture.php'));

class ControllerVoiture
{
    // Une action correspond généralement à une page Web.

    // Action readAll : affiche toutes les voitures.
    public static function readAll()
    {
        $tab_v      = ModelVoiture::getAllVoitures();         // appel au modèle pour gérer la BD
        $controller = 'voiture';
        $view       = 'list';
        $pagetitle  = 'Liste des voitures';
        require File::build_path(array('view', 'view.php'));  // vue générique
    }

    // Action read : affiche le détail de la voiture dont l'immatriculation
    // est passée dans l'URL.
    public static function read()
    {
        $immat = isset($_GET['immat']) ? $_GET['immat'] : null;
        $v     = ModelVoiture::getVoitureByImmat($immat);

        if ($v === false) {
            $message    = "Aucune voiture ne correspond à l'immatriculation " . $immat . '.';
            $controller = 'voiture';
            $view       = 'error';
            $pagetitle  = 'Erreur';
        } else {
            $controller = 'voiture';
            $view       = 'detail';
            $pagetitle  = 'Détail de la voiture';
        }
        require File::build_path(array('view', 'view.php'));
    }

    // Action create : affiche le formulaire de création d'une voiture.
    public static function create()
    {
        $controller = 'voiture';
        $view       = 'create';
        $pagetitle  = 'Création d une voiture';
        require File::build_path(array('view', 'view.php'));
    }

    // Action created : enregistre la voiture reçue puis réaffiche la liste.
    public static function created()
    {
        // i. récupération des données de la voiture dans la query string
        $immatriculation = $_GET['immatriculation'];
        $marque          = $_GET['marque'];
        $couleur         = $_GET['couleur'];

        // ii. création d'une instance de ModelVoiture
        $voiture = new ModelVoiture($marque, $couleur, $immatriculation);

        // iii. appel de la méthode save du modèle
        $voiture->save();

        // iv. affichage : message de confirmation puis liste des voitures
        $tab_v      = ModelVoiture::getAllVoitures();  // à initialiser pour list.php
        $controller = 'voiture';
        $view       = 'created';
        $pagetitle  = 'Voiture créée';
        require File::build_path(array('view', 'view.php'));
    }
}
