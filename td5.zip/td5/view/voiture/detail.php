
       <?php
$vMarque  = htmlspecialchars($v->getMarque());
$vCouleur = htmlspecialchars($v->getCouleur());
$vImmat   = htmlspecialchars($v->getImmatriculation());

echo '<p>Marque : ' . $vMarque . '</p>';
echo '<p>Couleur : ' . $vCouleur . '</p>';
echo '<p>Immatriculation : ' . $vImmat . '</p>';
