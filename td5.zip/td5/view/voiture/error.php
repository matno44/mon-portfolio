
        <h2>Erreur</h2>
        <?php
        $messageHTML = htmlspecialchars($message);
        echo '<p>' . $messageHTML . '</p>';
