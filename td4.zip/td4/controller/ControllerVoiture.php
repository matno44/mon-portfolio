<?php
require_once('../model/ModelVoiture.php'); // chargement du modèle

class ControllerVoiture
{
    // Une action correspond généralement à une page Web.

    // Action readAll : affiche toutes les voitures.
    public static function readAll()
    {
        $tab_v = ModelVoiture::getAllVoitures(); // appel au modèle pour gerer la BD
        require('../view/voiture/list.php');     // "redirige" vers la vue
    }

    // Action read : affiche le détail de la voiture dont l'immatriculation
    // est passée dans l'URL.
    public static function read()
    {
        $immat = isset($_GET['immat']) ? $_GET['immat'] : null;
        $v     = ModelVoiture::getVoitureByImmat($immat);

        if ($v === false) {
            // Immatriculation inconnue : on part sur la vue d'erreur.
            $message = 'Aucune voiture ne correspond à l\'immatriculation ' . $immat . '.';
            require('../view/voiture/error.php');
        } else {
            require('../view/voiture/detail.php');
        }
    }

    // Action create : affiche le formulaire de création d'une voiture.
    public static function create()
    {
        require('../view/voiture/create.php');
    }

    // Action created : enregistre la voiture reçue puis réaffiche la liste.
    public static function created()
    {
        // i. récupération des données de la voiture dans la query string
        $immatriculation = $_GET['immatriculation'];
        $marque          = $_GET['marque'];
        $couleur         = $_GET['couleur'];

        // ii. création d'une instance de ModelVoiture
        $v = new ModelVoiture($marque, $couleur, $immatriculation);

        // iii. appel de la méthode save du modèle
        $v->save();

        // iv. affichage du tableau de toutes les voitures
        ControllerVoiture::readAll();
    }
}
?>
