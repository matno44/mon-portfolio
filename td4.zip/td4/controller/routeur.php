<?php
require_once 'ControllerVoiture.php';
// On recupère l'action passée dans l'URL (query string).
// Sans paramètre, on affiche la liste par défaut.
$action = isset($_GET['action']) ? $_GET['action'] : 'readAll';
// Appel de la méthode statique $action de ControllerVoiture
ControllerVoiture::$action();
?>
