<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Erreur</title>
    </head>
    <body>
        <h2>Erreur</h2>
        <?php
        // $message est rempli par le contrôleur.
        echo '<p>' . $message . '</p>';
        ?>
        <p><a href="routeur.php?action=readAll">Retour à la liste des voitures</a></p>
    </body>
</html>
