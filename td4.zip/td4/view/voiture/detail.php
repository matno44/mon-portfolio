<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Détail de la voiture</title>
    </head>
    <body>
        <?php
        // La vue ne fait que lire la variable $v remplie par le contrôleur.
        // Elle affiche les mêmes informations que l'ancienne méthode afficher().
        echo '<p>Marque : ' . $v->getMarque() . '</p>';
        echo '<p>Couleur : ' . $v->getCouleur() . '</p>';
        echo '<p>Immatriculation : ' . $v->getImmatriculation() . '</p>';
        ?>
        <p><a href="routeur.php?action=readAll">Retour à la liste des voitures</a></p>
    </body>
</html>
