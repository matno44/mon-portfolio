<!doctype html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Création d'une voiture</title>
    </head>

    <body>
        <form method="get" action="routeur.php">
            <fieldset>
                <legend>Mon formulaire :</legend>
                <!-- Champ caché : il transmet l'action au routeur en même temps
                     que les données du formulaire (la méthode est GET, on ne peut
                     donc pas écrire routeur.php?action=created dans action). -->
                <input type="hidden" name="action" value="created" />
                <p>
                    <label for="immat_id">Immatriculation</label> :
                    <input
                        type="text"
                        placeholder="Ex : 256AB34"
                        name="immatriculation"
                        id="immat_id"
                        required />
                </p>
                <p>
                    <label for="marque_id">Marque</label> :
                    <input
                        type="text"
                        placeholder="Ex : Renault"
                        name="marque"
                        id="marque_id"
                        required />
                </p>
                <p>
                    <label for="couleur_id">Couleur</label> :
                    <input
                        type="text"
                        placeholder="Ex : rouge"
                        name="couleur"
                        id="couleur_id"
                        required />
                </p>
                <p>
                    <input type="submit" value="Envoyer" />
                </p>
            </fieldset>
        </form>
    </body>
</html>
