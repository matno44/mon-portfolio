<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Liste des voitures</title>
    </head>
    <body>
        <?php
        // La vue ne fait que lire la variable $tab_v remplie par le contrôleur.
        // Chaque immatriculation est un lien vers l'action read du routeur.
        foreach ($tab_v as $v)
            echo '<p> Voiture d\'immatriculation <a href="routeur.php?action=read&immat='
                . urlencode($v->getImmatriculation()) . '">'
                . $v->getImmatriculation() . '</a>.</p>';
        ?>
        <p><a href="routeur.php?action=create">Ajouter une voiture</a></p>
    </body>
</html>
