
<?php
require_once 'Model.php';

class ModelVoiture
{
    private $marque;
    private $couleur;
    private $immatriculation;

    // un constructeur
    public function __construct($m = NULL, $c = NULL, $i = NULL)
    {
        if (!is_null($m) && !is_null($c) && !is_null($i)) {
            $this->marque          = $m;
            $this->couleur         = $c;
            $this->immatriculation = $i;
        }
    }

    // un getter
    public function getMarque()
    {
        return $this->marque;
    }

    public function setMarque($marque2)
    {
        $this->marque = $marque2;
    }

    public function getCouleur()
    {
        return $this->couleur;
    }

    public function setCouleur($couleur2)
    {
        $this->couleur = $couleur2;
    }

    public function getImmatriculation()
    {
        return $this->immatriculation;
    }

    public function setImmatriculation($immatriculation2)
    {
        $this->immatriculation = $immatriculation2;
    }

    // L'affichage n'est plus le rôle du modèle mais de la vue (architecture MVC).
    // La méthode est donc désactivée.
    // public function afficher()
    // {
    //     echo 'Marque: ' . $this->marque . '<br>';
    //     echo 'Couleur: ' . $this->couleur . '<br>';
    //     echo 'Immatriculation: ' . $this->immatriculation . '<br>';
    // }

    // Méthode statique pour récupérer toutes les voitures en BDD
    public static function getAllVoitures()
    {
        try {
            $query = 'SELECT * FROM voiture';
            $rep   = Model::$pdo->query($query);
            $rep->setFetchMode(PDO::FETCH_CLASS, 'ModelVoiture');

            return $rep->fetchAll();
        } catch (PDOException $e) {
            if (Conf::getDebug()) {
                echo $e->getMessage();
            } else {
                echo 'Une erreur est survenue lors de la lecture des voitures.';
            }

            return array();
        }
    }

    public static function getVoitureByImmat($immat)
    {
        try {
            $sql      = 'SELECT * from voiture WHERE immatriculation=:nom_tag';
            // Préparation de la requête
            $req_prep = Model::$pdo->prepare($sql);
            $values   = array(
                'nom_tag' => $immat,
                // nomdutag => valeur, ...
            );
            // On donne les valeurs et on exécute la requête
            $req_prep->execute($values);
            // On récupère les résultats comme précédemment
            $req_prep->setFetchMode(PDO::FETCH_CLASS, 'ModelVoiture');
            $tab_voit = $req_prep->fetchAll();
            // Attention, si il n'y a pas de résultats, on renvoie false
            if (empty($tab_voit))
                return false;
            return $tab_voit[0];
        } catch (PDOException $e) {
            if (Conf::getDebug()) {
                echo $e->getMessage();
            } else {
                echo 'Une erreur est survenue lors de la recherche de la voiture.';
            }

            return false;
        }
    }

    // Méthode d'instance qui insère la voiture courante ($this) dans la BDD
    public function save()
    {
        try {
            $sql      = 'INSERT INTO voiture (immatriculation, marque, couleur) '
                . 'VALUES (:immat_tag, :marque_tag, :couleur_tag)';
            // Préparation de la requête
            $req_prep = Model::$pdo->prepare($sql);
            $values   = array(
                'immat_tag'   => $this->immatriculation,
                'marque_tag'  => $this->marque,
                'couleur_tag' => $this->couleur,
            );
            // On donne les valeurs et on exécute la requête.
            // Attention : un INSERT ne renvoie pas de résultats, donc pas de fetch() ici.
            $req_prep->execute($values);

            return true;
        } catch (PDOException $e) {
            if (Conf::getDebug()) {
                echo $e->getMessage();
            } else {
                echo 'Une erreur est survenue lors de l\'enregistrement de la voiture.';
            }

            return false;
        }
    }
}
