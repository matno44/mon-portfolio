<?php
// Chargement des classes nécessaires
require_once 'Model.php';
require_once 'Utilisateur.php';
require_once 'Trajet.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Passagers d'un trajet</title>
    </head>
    <body>
        <h2>Passagers d'un trajet</h2>
        <?php
        // L'identifiant vient du formulaire (GET) ; sinon on prend un id existant
        // pour que la page reste testable en appel direct.
        $id = isset($_GET['trajet_id']) ? $_GET['trajet_id'] : 1;

        echo '<p>Trajet numéro ' . htmlspecialchars($id) . '</p>';

        $tab_util = Trajet::findPassagers($id);

        if (empty($tab_util)) {
            echo 'Aucun passager inscrit sur ce trajet.<br>';
        } else {
            foreach ($tab_util as $util) {
                $util->afficher();
                echo '<hr>';
            }
        }
        ?>
        <p><a href="formFindUtil.php">Retour au formulaire</a></p>
    </body>
</html>
