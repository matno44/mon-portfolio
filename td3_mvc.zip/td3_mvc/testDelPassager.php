<?php
// Chargement des classes nécessaires
require_once 'Model.php';
require_once 'Utilisateur.php';
require_once 'Trajet.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Désinscription d'un passager</title>
    </head>
    <body>
        <h2>Désinscription d'un passager</h2>
        <?php
        if (isset($_GET['trajet_id']) && isset($_GET['utilisateur_login'])) {
            // On construit le tableau associatif attendu par deletePassager
            $data = array(
                'trajet_id'         => $_GET['trajet_id'],
                'utilisateur_login' => $_GET['utilisateur_login'],
            );

            $nb = Trajet::deletePassager($data);

            if ($nb > 0) {
                echo '<p>L\'utilisateur ' . htmlspecialchars($data['utilisateur_login'])
                    . ' a bien été désinscrit du trajet ' . htmlspecialchars($data['trajet_id']) . '.</p>';
            } else {
                echo '<p>Aucune inscription trouvée pour l\'utilisateur '
                    . htmlspecialchars($data['utilisateur_login'])
                    . ' sur le trajet ' . htmlspecialchars($data['trajet_id']) . '.</p>';
            }

            // On réaffiche les passagers restants du trajet
            echo '<h3>Passagers restants du trajet ' . htmlspecialchars($data['trajet_id']) . '</h3>';
            $tab_util = Trajet::findPassagers($data['trajet_id']);
            if (empty($tab_util)) {
                echo 'Plus aucun passager sur ce trajet.<br>';
            } else {
                foreach ($tab_util as $util) {
                    $util->afficher();
                    echo '<hr>';
                }
            }
        } else {
            echo '<p>Aucune donnée reçue : merci de passer par le formulaire.</p>';
        }
        ?>
        <p><a href="formDelPassager.php">Retour au formulaire</a></p>
    </body>
</html>
