<?php
// Chargement des classes nécessaires
require_once 'Model.php';
require_once 'Utilisateur.php';
require_once 'Trajet.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Trajets d'un utilisateur</title>
    </head>
    <body>
        <h2>Trajets d'un utilisateur</h2>
        <?php
        // Le login vient du formulaire (GET) ; sinon on prend un login existant
        // pour que la page reste testable en appel direct.
        $login = isset($_GET['login']) ? $_GET['login'] : 'matk';

        echo '<p>Utilisateur ' . htmlspecialchars($login) . '</p>';

        $tab_traj = Utilisateur::findTrajets($login);

        if (empty($tab_traj)) {
            echo 'Cet utilisateur n\'est inscrit à aucun trajet.<br>';
        } else {
            foreach ($tab_traj as $traj) {
                $traj->afficher();
                echo '<hr>';
            }
        }
        ?>
        <p><a href="formFindTraj.php">Retour au formulaire</a></p>
    </body>
</html>
