<?php
class Trajet
{
    private $id;
    private $depart;
    private $arrivee;
    private $date;
    private $nbplaces;
    private $prix;
    private $conducteur_login;

    public function __construct($data = [])
    {
        foreach ($data as $cle => $valeur) {
            $this->$cle = $valeur;
        }
    }

    public function get($nom_attribut)
    {
        return $this->$nom_attribut;
    }

    public function set($nom_attribut, $valeur)
    {
        $this->$nom_attribut = $valeur;
    }

    public function afficher()
    {
        echo 'Départ: ' . $this->depart . '<br>';
        echo 'Arrivée: ' . $this->arrivee . '<br>';
        echo 'Date: ' . $this->date . '<br>';
        echo 'Nombre de places: ' . $this->nbplaces . '<br>';
        echo 'Prix: ' . $this->prix . '<br>';
        echo 'Login du conducteur: ' . $this->conducteur_login . '<br>';
    }

    public static function getAlltrajets()
    {
        $query = 'SELECT * FROM trajet';
        $rep   = Model::$pdo->query($query);
        $rep->setFetchMode(PDO::FETCH_CLASS, 'Trajet');

        return $rep->fetchAll();
    }

    // Retourne le tableau des objets Utilisateur inscrits comme passagers
    // du trajet d'identifiant $id (jointure entre passager et utilisateur).
    public static function findPassagers($id)
    {
        try {
            $sql      = 'SELECT u.login, u.nom, u.prenom '
                . 'FROM utilisateur u '
                . 'INNER JOIN passager p ON u.login = p.utilisateur_login '
                . 'WHERE p.trajet_id = :id_tag';
            // Requête préparée : l'identifiant vient d'un formulaire
            $req_prep = Model::$pdo->prepare($sql);
            $values   = array(
                'id_tag' => $id,
            );
            $req_prep->execute($values);
            // Les lignes renvoyées sont transformées en objets Utilisateur
            $req_prep->setFetchMode(PDO::FETCH_CLASS, 'Utilisateur');

            return $req_prep->fetchAll();
        } catch (PDOException $e) {
            if (Conf::getDebug()) {
                echo $e->getMessage();
            } else {
                echo 'Une erreur est survenue lors de la recherche des passagers.';
            }

            return array();
        }
    }

    // Désinscrit un passager d'un trajet.
    // $data est un tableau associatif avec $data['trajet_id'] et $data['utilisateur_login'].
    // Retourne le nombre de lignes supprimées (0 si le passager n'était pas inscrit).
    public static function deletePassager($data)
    {
        try {
            $sql      = 'DELETE FROM passager '
                . 'WHERE trajet_id = :trajet_tag AND utilisateur_login = :login_tag';
            // Requête préparée : les deux valeurs viennent d'un formulaire
            $req_prep = Model::$pdo->prepare($sql);
            $values   = array(
                'trajet_tag' => $data['trajet_id'],
                'login_tag'  => $data['utilisateur_login'],
            );
            // Un DELETE ne renvoie pas de résultats : pas de fetch() ici non plus.
            $req_prep->execute($values);

            return $req_prep->rowCount();
        } catch (PDOException $e) {
            if (Conf::getDebug()) {
                echo $e->getMessage();
            } else {
                echo 'Une erreur est survenue lors de la désinscription du passager.';
            }

            return 0;
        }
    }
}
