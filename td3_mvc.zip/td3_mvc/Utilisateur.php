<?php
class Utilisateur
{
    private $login;
    private $nom;
    private $prenom;

    // Constructeur à paramètres optionnels : PDO::FETCH_CLASS remplit d'abord les
    // attributs puis appelle le constructeur. Sans ce test, un appel sans argument
    // écraserait avec NULL les valeurs venant de la BDD.
    public function __construct($login = null, $nom = null, $prenom = null)
    {
        if (!is_null($login) && !is_null($nom) && !is_null($prenom)) {
            $this->login  = $login;
            $this->nom    = $nom;
            $this->prenom = $prenom;
        }
    }

    public function get($nom_attribut)
    {
        return $this->$nom_attribut;
    }

    public function set($nom_attribut, $valeur)
    {
        $this->$nom_attribut = $valeur;
    }

    public function afficher()
    {
        echo 'Login: ' . $this->login . '<br>';
        echo 'Nom: ' . $this->nom . '<br>';
        echo 'Prénom: ' . $this->prenom . '<br>';
    }

    public static function getAllUtilisateurs()
    {
        $query = 'SELECT * FROM utilisateur';
        $rep   = Model::$pdo->query($query);
        $rep->setFetchMode(PDO::FETCH_CLASS, 'Utilisateur');

        return $rep->fetchAll();
    }

    // Jointure inverse de findPassagers : retourne le tableau des objets Trajet
    // auxquels l'utilisateur $login est inscrit comme passager.
    public static function findTrajets($login)
    {
        try {
            $sql      = 'SELECT t.* '
                . 'FROM trajet t '
                . 'INNER JOIN passager p ON t.id = p.trajet_id '
                . 'WHERE p.utilisateur_login = :login_tag';
            // Requête préparée : le login vient d'un formulaire
            $req_prep = Model::$pdo->prepare($sql);
            $values   = array(
                'login_tag' => $login,
            );
            $req_prep->execute($values);
            // Les lignes renvoyées sont transformées en objets Trajet
            $req_prep->setFetchMode(PDO::FETCH_CLASS, 'Trajet');

            return $req_prep->fetchAll();
        } catch (PDOException $e) {
            if (Conf::getDebug()) {
                echo $e->getMessage();
            } else {
                echo 'Une erreur est survenue lors de la recherche des trajets.';
            }

            return array();
        }
    }
}
