<?php
require_once 'Conf.php';

class Model
{
    // Attribut contenant l'instance de PDO
    public static $pdo;

    // Méthode statique pour initialiser la connexion à la base de données
    public static function init()
    {
        // On récupère les informations de connexion depuis la classe Conf
        $login    = Conf::getLogin();
        $hostname = Conf::getHostname();
        $database = Conf::getDatabase();
        $password = Conf::getPassword();

        // On crée une nouvelle instance de PDO pour se connecter à la base de données
        try {
            self::$pdo = new PDO(
                "mysql:host=$hostname;dbname=$database",
                $login,
                $password,
                [PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8']
            );
            self::$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            if (Conf::getDebug()) {
                echo $e->getMessage();  // affiche un message d'erreur
            } else {
                echo 'Une erreur est survenue <a href=""> retour a la page d\'accueil </a>';
            }
            die();
        }
    }

    // Méthode statique pour exécuter une requête SQL et retourner les résultats
    public static function query($sql, $params = [])
    {
        // On prépare la requête SQL
        $stmt = self::$pdo->prepare($sql);
        // On exécute la requête avec les paramètres fournis
        $stmt->execute($params);
        // On retourne les résultats sous forme de tableau associatif
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

Model::init();  // Initialisation de la connexion à la base de données
