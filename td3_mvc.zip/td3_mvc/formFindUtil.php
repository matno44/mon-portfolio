<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Rechercher les passagers d'un trajet</title>
    </head>
    <body>
        <form method="get" action="testFindUtil.php">
            <fieldset>
                <legend>Passagers d'un trajet :</legend>
                <p>
                    <label for="trajet_id">Identifiant du trajet</label> :
                    <input
                        type="number"
                        placeholder="Ex : 1"
                        name="trajet_id"
                        id="trajet_id"
                        required />
                </p>
                <p>
                    <input type="submit" value="Rechercher" />
                </p>
            </fieldset>
        </form>
    </body>
</html>
