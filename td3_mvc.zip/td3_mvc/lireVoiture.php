<?php
require_once 'Model.php';
require_once 'voiture.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Lecture des voitures</title>
    </head>
    <body>
        <h2>Toutes les voitures (getAllVoitures)</h2>
        <?php
        // Récupération des résultats sous forme de tableau d'objets
        $tab_voit = Voiture::getAllVoitures();

        // Utilisation d'une boucle foreach pour itérer sur le tableau
        foreach ($tab_voit as $voit) {
            $voit->afficher();
            echo '<hr>';
        }
        ?>

        <h2>Exercice 1 : recherche par immatriculation (requête préparée)</h2>
        <?php
        // Cas 1 : une immatriculation qui existe en base
        $immat = 'AB123CD';
        echo '<h3>Recherche de ' . $immat . '</h3>';
        $uneVoiture = Voiture::getVoitureByImmat($immat);
        if ($uneVoiture === false) {
            echo 'Aucune voiture trouvée pour l\'immatriculation ' . $immat . '<br>';
        } else {
            $uneVoiture->afficher();
        }

        // Cas 2 : une immatriculation qui n'existe pas -> la fonction renvoie false
        $immatInconnue = 'ZZ999ZZ';
        echo '<h3>Recherche de ' . $immatInconnue . '</h3>';
        $voitureInconnue = Voiture::getVoitureByImmat($immatInconnue);
        if ($voitureInconnue === false) {
            echo 'Aucune voiture trouvée pour l\'immatriculation ' . $immatInconnue . '<br>';
        } else {
            $voitureInconnue->afficher();
        }
        ?>

        <h2>Exercice 2 : enregistrement d'une voiture (save)</h2>
        <?php
        // Création d'un objet Voiture puis enregistrement dans la BDD
        $nouvelleVoiture = new Voiture('Renault', 'bleu', 'CL789VE');

        // On n'insère que si l'immatriculation n'est pas déjà prise (clé primaire)
        if (Voiture::getVoitureByImmat($nouvelleVoiture->getImmatriculation()) === false) {
            if ($nouvelleVoiture->save()) {
                echo 'Voiture enregistrée en base :<br>';
                $nouvelleVoiture->afficher();
            }
        } else {
            echo 'La voiture est déjà en base :<br>';
            $nouvelleVoiture->afficher();
        }

        echo '<h3>Contenu de la table après enregistrement</h3>';
        foreach (Voiture::getAllVoitures() as $voit) {
            $voit->afficher();
            echo '<hr>';
        }
        ?>
    </body>
</html>
