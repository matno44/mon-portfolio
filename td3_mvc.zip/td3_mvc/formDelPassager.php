<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Désinscrire un passager</title>
    </head>
    <body>
        <form method="get" action="testDelPassager.php">
            <fieldset>
                <legend>Désinscrire un passager d'un trajet :</legend>
                <p>
                    <label for="trajet_id">Identifiant du trajet</label> :
                    <input
                        type="number"
                        placeholder="Ex : 1"
                        name="trajet_id"
                        id="trajet_id"
                        required />
                </p>
                <p>
                    <label for="utilisateur_login">Login du passager</label> :
                    <input
                        type="text"
                        placeholder="Ex : johd"
                        name="utilisateur_login"
                        id="utilisateur_login"
                        required />
                </p>
                <p>
                    <input type="submit" value="Désinscrire" />
                </p>
            </fieldset>
        </form>
    </body>
</html>
