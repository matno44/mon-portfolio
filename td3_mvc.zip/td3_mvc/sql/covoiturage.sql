-- TD3 - Base de données du site de covoiturage (base `garage`)
-- Toutes les tables : moteur InnoDB + interclassement utf8mb4_general_ci.
-- Remarque : sous MySQL 9, l'ancien nom utf8_general_ci n'existe plus
-- (il est devenu utf8mb3_general_ci) ; on utilise utf8mb4_general_ci, qui est
-- aussi l'interclassement des tables créées au TD2. C'est indispensable car
-- une clé étrangère impose des interclassements identiques entre les colonnes.

-- ---------------------------------------------------------------
-- EXERCICE 4 : tables utilisateur et trajet
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS utilisateur (
    login  VARCHAR(32) NOT NULL,
    nom    VARCHAR(32) DEFAULT NULL,
    prenom VARCHAR(32) DEFAULT NULL,
    PRIMARY KEY (login)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS trajet (
    id               INT         NOT NULL AUTO_INCREMENT,
    depart           VARCHAR(32) DEFAULT NULL,
    arrivee          VARCHAR(32) DEFAULT NULL,
    date             DATE        DEFAULT NULL,
    nbplaces         INT         DEFAULT NULL,
    prix             INT         DEFAULT NULL,
    conducteur_login VARCHAR(32) DEFAULT NULL,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT IGNORE INTO utilisateur (login, nom, prenom) VALUES
    ('matk', 'kra',      'matisse'),
    ('johd', 'johne',    'doe'),
    ('rubb', 'batochio', 'ruben'),
    ('alid', 'dupont',   'alice'),
    ('bmar', 'martin',   'bob');

-- On ne remplit pas id : l'auto-incrément s'en charge.
INSERT INTO trajet (depart, arrivee, date, nbplaces, prix, conducteur_login) VALUES
    ('Lille',    'Paris',     '2026-10-05', 3, 20, 'matk'),
    ('Paris',    'Lyon',      '2026-10-12', 2, 35, 'johd'),
    ('Lyon',     'Marseille', '2026-10-18', 4, 25, 'rubb'),
    ('Bordeaux', 'Toulouse',  '2026-10-22', 2, 15, 'alid');

-- ---------------------------------------------------------------
-- EXERCICE 5 : index + clé étrangère trajet.conducteur_login -> utilisateur.login
-- ---------------------------------------------------------------
-- Une clé étrangère est nécessairement un index : MySQL en a besoin pour
-- vérifier rapidement la contrainte.
CREATE INDEX idx_conducteur_login ON trajet (conducteur_login);

ALTER TABLE trajet
    ADD CONSTRAINT fk_trajet_conducteur
    FOREIGN KEY (conducteur_login) REFERENCES utilisateur (login)
    ON DELETE CASCADE ON UPDATE CASCADE;

-- ---------------------------------------------------------------
-- EXERCICE 6 : table pivot passager (association many-to-many)
-- ---------------------------------------------------------------
-- La relation passager n'est pas bornée : un utilisateur peut être passager de
-- plusieurs trajets et un trajet a plusieurs passagers. On passe donc par une
-- table d'association dont la clé primaire est le COUPLE (trajet_id, utilisateur_login).
CREATE TABLE passager (
    trajet_id         INT         NOT NULL,
    utilisateur_login VARCHAR(32) NOT NULL,
    PRIMARY KEY (trajet_id, utilisateur_login)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE passager
    ADD CONSTRAINT fk_passager_trajet FOREIGN KEY (trajet_id)
        REFERENCES trajet (id) ON DELETE CASCADE ON UPDATE CASCADE,
    ADD CONSTRAINT fk_passager_utilisateur FOREIGN KEY (utilisateur_login)
        REFERENCES utilisateur (login) ON DELETE CASCADE ON UPDATE CASCADE;

INSERT INTO passager (trajet_id, utilisateur_login) VALUES
    (1, 'johd'), (1, 'rubb'), (1, 'alid'),
    (2, 'matk'), (2, 'bmar'),
    (3, 'matk'), (3, 'johd'),
    (4, 'rubb');

-- Test du ON DELETE CASCADE :
--   1. on crée un conducteur de test et son trajet,
--   2. on inscrit des passagers sur ce trajet,
--   3. on supprime le conducteur : son trajet est supprimé en cascade, et les
--      lignes passager de ce trajet le sont à leur tour (cascade en chaîne).
-- INSERT INTO utilisateur (login, nom, prenom) VALUES ('testc', 'conducteur', 'test');
-- INSERT INTO trajet (depart, arrivee, date, nbplaces, prix, conducteur_login)
--     VALUES ('Nantes', 'Rennes', '2026-11-02', 3, 12, 'testc');
-- SET @t = LAST_INSERT_ID();
-- INSERT INTO passager (trajet_id, utilisateur_login) VALUES (@t,'matk'), (@t,'johd'), (@t,'alid');
-- DELETE FROM utilisateur WHERE login = 'testc';
-- SELECT * FROM passager WHERE trajet_id = @t;  -- renvoie 0 ligne
