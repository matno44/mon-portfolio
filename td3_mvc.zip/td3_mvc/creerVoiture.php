<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Création de voiture</title>
    </head>
    <body>
        <?php
        // On inclut la connexion à la BDD et la définition de la classe Voiture
        require_once 'Model.php';
        require_once 'voiture.php';

        // On vérifie que le tableau $_POST n'est pas vide
        if (!empty($_POST)) {
            // Récupération des paramètres du corps de la requête HTTP
            $immatriculation = $_POST['immatriculation'];
            $marque          = $_POST['marque'];
            $couleur         = $_POST['couleur'];

            $maVoiture = new Voiture($marque, $couleur, $immatriculation);

            // Enregistrement de l'objet dans la BDD grâce à save()
            if ($maVoiture->save()) {
                echo '<h2>Voiture créée et enregistrée en base :</h2>';
                $maVoiture->afficher();
            } else {
                echo '<h2>L\'enregistrement de la voiture a échoué</h2>';
            }
        } else {
            echo '<h2>Aucune donnée reçue (POST vide)</h2>';
        }
        ?>
        <p><a href="formulaireVoiture.html">Retour au formulaire</a></p>
    </body>
</html>
