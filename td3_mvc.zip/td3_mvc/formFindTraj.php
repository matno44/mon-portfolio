<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Rechercher les trajets d'un utilisateur</title>
    </head>
    <body>
        <form method="get" action="testFindTraj.php">
            <fieldset>
                <legend>Trajets d'un utilisateur :</legend>
                <p>
                    <label for="login">Login de l'utilisateur</label> :
                    <input
                        type="text"
                        placeholder="Ex : matk"
                        name="login"
                        id="login"
                        required />
                </p>
                <p>
                    <input type="submit" value="Rechercher" />
                </p>
            </fieldset>
        </form>
    </body>
</html>
