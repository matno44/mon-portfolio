import 'dart:io';

bool estPremier(int n) {
  if (n < 2) return false;

  for (int i = 2; i <= n ~/ 2; i++) {
    if (n % i == 0) {
      return false;
    }
  }
  return true;
}

void main() {
  stdout.write('Entrez un nombre : ');
  String? saisie = stdin.readLineSync();
  int? nombre = int.tryParse(saisie ?? '');

  if (nombre == null) {
    stdout.writeln('Veuillez entrer un nombre valide.');
    return;
  }

  if (estPremier(nombre)) {
    stdout.writeln('$nombre est un nombre premier.');
  } else {
    stdout.writeln('$nombre n\'est pas un nombre premier.');
  }
}
