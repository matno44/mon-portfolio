import 'dart:io';
import 'dart:math';

void main() {
  List<String> choix = ['pierre', 'papier', 'ciseaux'];

  stdout.write('Entrez votre choix (pierre, papier, ciseaux) : ');
  String? utilisateur = stdin.readLineSync()?.toLowerCase();

  if (utilisateur == null || !choix.contains(utilisateur)) {
    stdout.writeln(
      'Choix invalide. Veuillez entrer pierre, papier ou ciseaux.',
    );
    return;
  }

  String ordinateur = choix[Random().nextInt(3)];

  stdout.writeln('Vous avez choisi : $utilisateur');
  stdout.writeln('L\'ordinateur a choisi : $ordinateur');

  if (utilisateur == ordinateur) {
    stdout.writeln('Égalité !');
  } else if ((utilisateur == 'pierre' && ordinateur == 'ciseaux') ||
      (utilisateur == 'papier' && ordinateur == 'pierre') ||
      (utilisateur == 'ciseaux' && ordinateur == 'papier')) {
    stdout.writeln('Vous gagnez !');
  } else {
    stdout.writeln('Vous perdez !');
  }
}
