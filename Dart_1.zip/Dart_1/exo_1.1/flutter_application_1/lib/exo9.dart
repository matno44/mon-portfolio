import 'dart:io';
import 'dart:math';

void main() {
  int nombreAleatoire = Random().nextInt(100) + 1;
  int? nombreUtilisateur;

  stdout.write('Entrez un nombre entre 1 et 100 : ');
  String? saisie = stdin.readLineSync();

  if (saisie != null) {
    nombreUtilisateur = int.tryParse(saisie);
  }

  if (nombreUtilisateur == null ||
      nombreUtilisateur < 1 ||
      nombreUtilisateur > 100) {
    stdout.writeln(
      'Entrée invalide. Veuillez entrer un nombre entre 1 et 100.',
    );
    return;
  }

  if (nombreUtilisateur == nombreAleatoire) {
    stdout.writeln('Félicitations ! Vous avez deviné le bon nombre.');
  } else if (nombreUtilisateur < nombreAleatoire) {
    stdout.writeln('Le nombre est trop petit.');
    stdout.writeln('Le nombre aléatoire était : $nombreAleatoire');
  } else {
    stdout.writeln('Le nombre est trop grand.');
    stdout.writeln('Le nombre aléatoire était : $nombreAleatoire');
  }
}
