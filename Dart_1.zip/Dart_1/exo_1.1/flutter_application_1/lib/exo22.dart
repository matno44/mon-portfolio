import 'dart:io';

// Renvoie la plus grande des trois valeurs sans utiliser max()
int plusGrand(int a, int b, int c) {
  int resultat = a;
  if (b > resultat) {
    resultat = b;
  }
  if (c > resultat) {
    resultat = c;
  }
  return resultat;
}

void tester(int a, int b, int c) {
  stdout.writeln('plusGrand($a, $b, $c) = ${plusGrand(a, b, c)}');
}

void main() {
  tester(42, 7, 13); // le plus grand en 1ere position
  tester(7, 42, 13); // le plus grand en 2eme position
  tester(7, 13, 42); // le plus grand en 3eme position
  tester(42, 42, 13); // cas d'egalite
}
