import 'dart:io';

const List<String> symboles = [' ', 'X', 'O'];

List<List<int>> creerPlateau(int n) {
  return List.generate(n, (_) => List.filled(n, 0));
}

void afficherPlateau(List<List<int>> plateau) {
  int n = plateau.length;
  for (int i = 0; i < n; i++) {
    stdout.writeln(plateau[i].map((c) => ' ${symboles[c]} ').join('|'));
    if (i < n - 1) {
      stdout.writeln('-' * (n * 3 + (n - 1)));
    }
  }
}

// Demande une coordonnee valide (1..n) et la renvoie sous forme d'index (0..n-1)
int demanderCoordonnee(String libelle, int n) {
  while (true) {
    stdout.write('$libelle (1 a $n) : ');
    int? valeur = int.tryParse(stdin.readLineSync() ?? '');
    if (valeur != null && valeur >= 1 && valeur <= n) {
      return valeur - 1;
    }
    stdout.writeln('Coordonnee invalide.');
  }
}

void main() {
  List<List<int>> plateau = creerPlateau(3);

  stdout.writeln('Plateau de depart :');
  afficherPlateau(plateau);

  while (true) {
    int ligne = demanderCoordonnee('Ligne', 3);
    int colonne = demanderCoordonnee('Colonne', 3);

    if (plateau[ligne][colonne] != 0) {
      stdout.writeln('Case deja occupee, choisissez-en une autre.');
      continue;
    }

    plateau[ligne][colonne] = 1;
    break;
  }

  stdout.writeln('Plateau apres le coup :');
  afficherPlateau(plateau);
}
