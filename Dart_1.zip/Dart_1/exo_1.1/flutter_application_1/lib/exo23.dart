import 'dart:io';
import 'dart:math';

final Random alea = Random();

// Liste de secours utilisee tant que le vrai fichier sowpods.txt
// (un mot par ligne) n'a pas ete ajoute a cote du programme.
const List<String> motsDeSecours = [
  'EVAPORATE',
  'PENDULUM',
  'QUIZZICAL',
  'JAVELIN',
  'MOSAIC',
  'TRIUMPH',
  'WHISPER',
  'BLIZZARD',
  'ORCHARD',
  'KEYBOARD',
];

List<String> chargerMots() {
  File fichier = File('sowpods.txt');

  if (fichier.existsSync()) {
    List<String> mots = fichier
        .readAsLinesSync()
        .map((ligne) => ligne.trim().toUpperCase())
        .where((mot) => mot.isNotEmpty)
        .toList();
    stdout.writeln('Dictionnaire SOWPODS charge : ${mots.length} mots.');
    return mots;
  }

  stdout.writeln('Fichier sowpods.txt introuvable : utilisation de la '
      'liste de secours (${motsDeSecours.length} mots).');
  return motsDeSecours;
}

String motAuHasard(List<String> mots) {
  return mots[alea.nextInt(mots.length)];
}

void main() {
  List<String> mots = chargerMots();

  for (int i = 0; i < 5; i++) {
    stdout.writeln('Mot tire au hasard : ${motAuHasard(mots)}');
  }
}
