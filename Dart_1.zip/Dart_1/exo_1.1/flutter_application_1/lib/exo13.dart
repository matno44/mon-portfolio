import 'dart:io';

List<int> sansDoublons(List<int> liste) {
  return liste.toSet().toList();
}

void main() {
  List<int> a = [5, 10, 5, 20, 10, 25, 5];

  stdout.writeln('Liste de départ : $a');
  stdout.writeln('Sans doublons   : ${sansDoublons(a)}');
}
