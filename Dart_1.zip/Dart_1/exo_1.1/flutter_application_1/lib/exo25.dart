import 'dart:io';
import 'dart:math';

final Random alea = Random();
const int essaisMax = 6;

// Reprise de l'exercice 23 : liste de secours tant que sowpods.txt est absent
const List<String> motsDeSecours = [
  'EVAPORATE',
  'PENDULUM',
  'QUIZZICAL',
  'JAVELIN',
  'MOSAIC',
  'TRIUMPH',
  'WHISPER',
  'BLIZZARD',
  'ORCHARD',
  'KEYBOARD',
];

// Dessin du pendu, une etape par erreur commise
const List<String> pendu = [
  '  +---+\n      |\n      |\n      |\n     ===',
  '  +---+\n  O   |\n      |\n      |\n     ===',
  '  +---+\n  O   |\n  |   |\n      |\n     ===',
  '  +---+\n  O   |\n /|   |\n      |\n     ===',
  '  +---+\n  O   |\n /|\\  |\n      |\n     ===',
  '  +---+\n  O   |\n /|\\  |\n /    |\n     ===',
  '  +---+\n  O   |\n /|\\  |\n / \\  |\n     ===',
];

List<String> chargerMots() {
  File fichier = File('sowpods.txt');
  if (fichier.existsSync()) {
    return fichier
        .readAsLinesSync()
        .map((ligne) => ligne.trim().toUpperCase())
        .where((mot) => mot.isNotEmpty)
        .toList();
  }
  stdout.writeln('(sowpods.txt absent : liste de secours utilisee)');
  return motsDeSecours;
}

String masquer(String mot, Set<String> trouvees) {
  return mot.split('').map((l) => trouvees.contains(l) ? l : '_').join(' ');
}

bool motDevine(String mot, Set<String> trouvees) {
  return mot.split('').every((l) => trouvees.contains(l));
}

// Joue une partie complete et renvoie true si le joueur a gagne
bool jouerPartie(String mot) {
  Set<String> proposees = {};
  Set<String> trouvees = {};
  int erreurs = 0;

  stdout.writeln('Le mot contient ${mot.length} lettres.');
  stdout.writeln(masquer(mot, trouvees));

  while (erreurs < essaisMax) {
    stdout.write('Proposez une lettre : ');
    String saisie = (stdin.readLineSync() ?? '').toUpperCase().trim();

    if (saisie.length != 1 || !RegExp(r'^[A-Z]$').hasMatch(saisie)) {
      stdout.writeln('Entrez une seule lettre de A a Z.');
      continue;
    }

    // Une lettre deja proposee ne coute pas d'essai
    if (proposees.contains(saisie)) {
      stdout.writeln('Vous avez deja propose $saisie.');
      stdout.writeln('Lettres proposees : ${proposees.join(', ')}');
      continue;
    }

    proposees.add(saisie);

    if (mot.contains(saisie)) {
      trouvees.add(saisie);
      stdout.writeln('Bien joue, $saisie est dans le mot.');
    } else {
      erreurs++;
      stdout.writeln('Rate, $saisie n\'est pas dans le mot.');
      stdout.writeln(pendu[erreurs]);
      stdout.writeln('Essais restants : ${essaisMax - erreurs}');
    }

    stdout.writeln(masquer(mot, trouvees));
    stdout.writeln('Lettres proposees : ${proposees.join(', ')}');

    if (motDevine(mot, trouvees)) {
      stdout.writeln('Bravo, vous avez trouve le mot : $mot');
      return true;
    }
  }

  stdout.writeln('Perdu ! Le mot etait : $mot');
  return false;
}

void main() {
  List<String> mots = chargerMots();

  while (true) {
    stdout.writeln('=== Jeu du pendu ===');
    jouerPartie(mots[alea.nextInt(mots.length)]);

    stdout.write('Voulez-vous rejouer ? (o/n) : ');
    String reponse = (stdin.readLineSync() ?? '').toLowerCase().trim();
    if (reponse != 'o') {
      stdout.writeln('Merci d\'avoir joue.');
      return;
    }
  }
}
