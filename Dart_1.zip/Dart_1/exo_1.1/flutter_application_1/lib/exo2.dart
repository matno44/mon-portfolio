import 'dart:io';

void main() {
  stdout.write('entrez un numero : ');
  String? numero = stdin.readLineSync();
  int? num = int.tryParse(numero!);
  stdout.writeln('Vous avez entré le nombre : $num');
  if (num == null || num == 0) {
    stdout.writeln('Veuillez entrer un nombre valide.');
    do {
      stdout.write('entrez un numero : ');
      numero = stdin.readLineSync();
      num = int.tryParse(numero!);
    } while (num == null || num == 0);
    return;
  } else if (num % 2 == 0) {
    stdout.writeln('Vous avez entré un nombre pair.');
  } else {
    stdout.writeln('Vous avez entré un nombre impair.');
  }
}
