import 'dart:io';
import 'dart:math';

final Random alea = Random();

const String minuscules = 'abcdefghijklmnopqrstuvwxyz';
const String majuscules = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
const String chiffres = '0123456789';
const String symboles = '!@#\$%^&*()_+-=[]{}|;:,.<>?';

String genererDepuis(String jeu, int longueur) {
  return List.generate(longueur, (_) => jeu[alea.nextInt(jeu.length)]).join();
}

String genererFort(int longueur) =>
    genererDepuis(minuscules + majuscules + chiffres + symboles, longueur);

String genererModere(int longueur) =>
    genererDepuis(minuscules + majuscules + chiffres, longueur);

String genererFaible() {
  const List<String> mots = [
    'soleil',
    'montagne',
    'chat',
    'guitare',
    'orange',
    'nuage',
    'riviere',
    'pomme',
    'foret',
    'etoile',
  ];
  String mot1 = mots[alea.nextInt(mots.length)];
  String mot2 = mots[alea.nextInt(mots.length)];
  return '$mot1$mot2${alea.nextInt(100)}';
}

void main() {
  stdout.write(
    'Quel mot de passe voulez-vous générer ? (fort, modere, faible) : ',
  );
  String saisie = (stdin.readLineSync() ?? '').toLowerCase().trim();

  switch (saisie) {
    case 'fort':
      stdout.writeln(genererFort(20));
      break;
    case 'modere':
      stdout.writeln(genererModere(12));
      break;
    case 'faible':
      stdout.writeln(genererFaible());
      break;
    default:
      stdout.writeln('Choix invalide. Veuillez entrer fort, modere ou faible.');
  }
}
