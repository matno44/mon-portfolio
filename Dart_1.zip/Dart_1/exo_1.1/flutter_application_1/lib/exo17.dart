import 'dart:io';

// Construit la ligne d'une case vide : "   |   |   "
String ligneVide(int n) {
  return List.generate(n, (_) => '   ').join('|');
}

// Construit la ligne de séparation : "-----------"
String ligneSeparation(int n) {
  return '-' * (n * 3 + (n - 1));
}

void dessinerPlateau(int n) {
  for (int i = 0; i < n; i++) {
    stdout.writeln(ligneVide(n));
    if (i < n - 1) {
      stdout.writeln(ligneSeparation(n));
    }
  }
}

void main() {
  int? taille;

  do {
    stdout.write('Entrez la taille N du plateau : ');
    String? saisie = stdin.readLineSync();
    taille = int.tryParse(saisie ?? '');
    if (taille == null || taille < 2) {
      stdout.writeln('Veuillez entrer un entier supérieur ou égal à 2.');
    }
  } while (taille == null || taille < 2);

  stdout.writeln('Plateau ${taille}x$taille :');
  dessinerPlateau(taille);
}
