import 'dart:io';
import 'dart:math';

final Random alea = Random();

String genererCombinaison(int longueur) {
  return List.generate(longueur, (_) => alea.nextInt(10)).join();
}

// Chiffre correct ET bien placé
int compterVaches(String secret, String essai) {
  int vaches = 0;
  for (int i = 0; i < secret.length; i++) {
    if (secret[i] == essai[i]) vaches++;
  }
  return vaches;
}

// Chiffre correct mais mal placé
int compterTaureaux(String secret, String essai) {
  List<String> restantSecret = [];
  List<String> restantEssai = [];

  // On met de côté les positions qui ne sont pas des vaches
  for (int i = 0; i < secret.length; i++) {
    if (secret[i] != essai[i]) {
      restantSecret.add(secret[i]);
      restantEssai.add(essai[i]);
    }
  }

  int taureaux = 0;
  for (String c in restantEssai) {
    if (restantSecret.contains(c)) {
      taureaux++;
      restantSecret.remove(c); // consommé, pour ne pas le compter deux fois
    }
  }
  return taureaux;
}

void main() {
  String secret = genererCombinaison(4);
  int essais = 0;

  stdout.writeln('Devinez le nombre à 4 chiffres !');

  while (true) {
    stdout.write('Votre proposition : ');
    String saisie = (stdin.readLineSync() ?? '').trim();

    if (saisie.length != 4 || int.tryParse(saisie) == null) {
      stdout.writeln('Entrée invalide : il faut exactement 4 chiffres.');
      continue;
    }

    essais++;

    if (saisie == secret) {
      stdout.writeln('Bravo ! Vous avez trouvé $secret en $essais essai(s).');
      break;
    }

    int vaches = compterVaches(secret, saisie);
    int taureaux = compterTaureaux(secret, saisie);
    stdout.writeln('$vaches vache(s), $taureaux taureau(x).');
  }
}
