import 'dart:io';

const List<String> symboles = [' ', 'X', 'O'];
const int taille = 3;

List<List<int>> creerPlateau() {
  return List.generate(taille, (_) => List.filled(taille, 0));
}

void afficherPlateau(List<List<int>> plateau) {
  for (int i = 0; i < taille; i++) {
    stdout.writeln(plateau[i].map((c) => ' ${symboles[c]} ').join('|'));
    if (i < taille - 1) {
      stdout.writeln('-' * (taille * 3 + (taille - 1)));
    }
  }
}

int? chercherGagnant(List<List<int>> plateau) {
  for (int i = 0; i < taille; i++) {
    // Ligne i
    if (plateau[i][0] != 0 &&
        plateau[i].every((c) => c == plateau[i][0])) {
      return plateau[i][0];
    }
    // Colonne i
    if (plateau[0][i] != 0 &&
        plateau[1][i] == plateau[0][i] &&
        plateau[2][i] == plateau[0][i]) {
      return plateau[0][i];
    }
  }

  if (plateau[1][1] != 0) {
    if (plateau[0][0] == plateau[1][1] && plateau[2][2] == plateau[1][1]) {
      return plateau[1][1];
    }
    if (plateau[0][2] == plateau[1][1] && plateau[2][0] == plateau[1][1]) {
      return plateau[1][1];
    }
  }

  return null;
}

bool plateauPlein(List<List<int>> plateau) {
  return plateau.every((ligne) => ligne.every((c) => c != 0));
}

int demanderCoordonnee(String libelle) {
  while (true) {
    stdout.write('$libelle (1 a $taille) : ');
    int? valeur = int.tryParse(stdin.readLineSync() ?? '');
    if (valeur != null && valeur >= 1 && valeur <= taille) {
      return valeur - 1;
    }
    stdout.writeln('Coordonnee invalide.');
  }
}

// Fait jouer un tour complet au joueur donne
void jouerTour(List<List<int>> plateau, int joueur) {
  stdout.writeln('Au tour du joueur $joueur (${symboles[joueur]}).');
  while (true) {
    int ligne = demanderCoordonnee('Ligne');
    int colonne = demanderCoordonnee('Colonne');

    if (plateau[ligne][colonne] != 0) {
      stdout.writeln('Case deja occupee, choisissez-en une autre.');
      continue;
    }

    plateau[ligne][colonne] = joueur;
    return;
  }
}

void main() {
  List<List<int>> plateau = creerPlateau();
  int joueur = 1;

  stdout.writeln('=== Morpion ===');
  afficherPlateau(plateau);

  // On ne redemande un coup que si la partie n'est ni gagnee ni bloquee
  while (true) {
    jouerTour(plateau, joueur);
    afficherPlateau(plateau);

    int? gagnant = chercherGagnant(plateau);
    if (gagnant != null) {
      stdout.writeln('Felicitations au joueur $gagnant, vous avez gagne !');
      return;
    }

    if (plateauPlein(plateau)) {
      stdout.writeln('Plateau plein : match nul.');
      return;
    }

    joueur = joueur == 1 ? 2 : 1;
  }
}
