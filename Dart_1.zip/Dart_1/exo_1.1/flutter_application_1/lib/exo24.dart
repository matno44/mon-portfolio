import 'dart:io';

const String mot = 'EVAPORATE';

// Affiche les lettres deja trouvees a leur place et un tiret pour les autres
String masquer(String mot, Set<String> trouvees) {
  return mot.split('').map((l) => trouvees.contains(l) ? l : '_').join(' ');
}

void main() {
  Set<String> trouvees = {};

  stdout.writeln('Jeu du pendu : devinez le mot lettre par lettre.');
  stdout.writeln(masquer(mot, trouvees));

  while (true) {
    stdout.write('Proposez une lettre : ');
    String saisie = (stdin.readLineSync() ?? '').toUpperCase().trim();

    if (saisie.length != 1) {
      stdout.writeln('Entrez une seule lettre.');
      continue;
    }

    if (mot.contains(saisie)) {
      trouvees.add(saisie);
      stdout.writeln('Bien joue, la lettre $saisie est dans le mot.');
    } else {
      stdout.writeln('La lettre $saisie n\'est pas dans le mot.');
    }

    stdout.writeln(masquer(mot, trouvees));

    // Le mot est devine quand toutes ses lettres sont dans l'ensemble
    if (mot.split('').every((l) => trouvees.contains(l))) {
      stdout.writeln('Bravo, vous avez trouve le mot : $mot');
      return;
    }
  }
}
