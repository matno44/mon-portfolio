import 'dart:io';

const Map<String, String> anniversaires = {
  'Albert Einstein': '14 mars 1879',
  'Benjamin Franklin': '17 janvier 1706',
  'Ada Lovelace': '10 decembre 1815',
};

void main() {
  stdout.writeln('Bienvenue dans le dictionnaire des anniversaires.');
  stdout.writeln('Voici les personnes que je connais :');
  for (String nom in anniversaires.keys) {
    stdout.writeln('- $nom');
  }

  stdout.write('De qui voulez-vous connaitre la date d\'anniversaire ? ');
  String saisie = (stdin.readLineSync() ?? '').trim();

  String? date = anniversaires[saisie];
  if (date == null) {
    stdout.writeln('Desole, $saisie ne fait pas partie du dictionnaire.');
  } else {
    stdout.writeln('La date d\'anniversaire de $saisie est le $date');
  }
}
