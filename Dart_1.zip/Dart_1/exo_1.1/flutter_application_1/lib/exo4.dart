import 'dart:io';

void main() {
  List<int> diviseurs = [];
  int? nombre;

  do {
    stdout.write('Entrez un nombre : ');
    String? saisie = stdin.readLineSync();
    nombre = int.tryParse(saisie ?? '');
    if (nombre == null || nombre <= 0) {
      stdout.writeln('Veuillez entrer un entier strictement positif.');
    }
  } while (nombre == null || nombre <= 0);

  for (int i = 1; i <= nombre; i++) {
    if (nombre % i == 0) {
      diviseurs.add(i);
    }
  }

  stdout.writeln('Les diviseurs de $nombre sont : $diviseurs');
}
