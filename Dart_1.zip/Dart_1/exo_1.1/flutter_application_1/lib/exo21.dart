import 'dart:io';

void main() {
  int minimum = 0;
  int maximum = 100;
  int tentatives = 0;

  stdout.writeln('Pensez a un nombre entre 0 et 100, je vais le deviner.');
  stdout.writeln('Repondez : h = trop haut, b = trop bas, t = trouve.');

  while (true) {
    if (minimum > maximum) {
      stdout.writeln('Vos reponses sont contradictoires, je ne peux pas '
          'trouver votre nombre.');
      return;
    }

    // Recherche dichotomique : on propose toujours le milieu de l'intervalle
    int proposition = (minimum + maximum) ~/ 2;
    tentatives++;

    stdout.write('Est-ce que votre nombre est $proposition ? (h/b/t) : ');
    String reponse = (stdin.readLineSync() ?? '').toLowerCase().trim();

    if (reponse == 't') {
      stdout.writeln('Trouve ! Votre nombre est $proposition.');
      stdout.writeln('J\'ai utilise $tentatives tentative(s).');
      return;
    } else if (reponse == 'h') {
      maximum = proposition - 1;
    } else if (reponse == 'b') {
      minimum = proposition + 1;
    } else {
      stdout.writeln('Reponse invalide : tapez h, b ou t.');
      tentatives--;
    }
  }
}
