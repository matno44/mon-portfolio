import 'dart:io';

void main() {
  stdout.write('Entrez votre nom : ');
  String? nom = stdin.readLineSync();

  stdout.write('Entrez votre âge : ');
  String? ageStr = stdin.readLineSync();

  // Il faudra convertir ageStr en entier (int) pour ton calcul de 100 ans
  int age = int.parse(ageStr!);
  age = 100 - age;
  stdout.writeln('Bonjour, $nom !');
  stdout.writeln('Vous aurez 100 ans dans $age ans.');
}
