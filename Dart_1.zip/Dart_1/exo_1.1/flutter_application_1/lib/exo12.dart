import 'dart:io';

int fibonacciIterative(int n) {
  if (n <= 0) return 0;
  if (n == 1) return 1;
  int prev1 = 0;
  int prev2 = 1;
  int current = 0;
  for (int i = 2; i <= n; i++) {
    current = prev1 + prev2;
    prev1 = prev2;
    prev2 = current;
  }
  return current;
}

void main() {
  stdout.writeln(
    'combien de nombre de la suite de Fibonacci voulez-vous afficher ?',
  );
  int n = int.parse(stdin.readLineSync()!);
  stdout.writeln('Les $n premiers nombres de la suite de Fibonacci sont :');
  for (int i = 0; i < n; i++) {
    stdout.write('${fibonacciIterative(i)} ');
  }
}
