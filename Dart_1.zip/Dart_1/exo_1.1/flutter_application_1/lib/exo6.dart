import 'dart:io';

void main() {
  stdout.write('Entrez une chaîne : ');
  String saisie = stdin.readLineSync() ?? '';
  String normalisee = saisie.toLowerCase().replaceAll(' ', '');
  String inverse = normalisee.split('').reversed.join();

  if (normalisee == inverse) {
    stdout.writeln('"$normalisee" est un palindrome.');
  } else {
    stdout.writeln('"$normalisee " n\'est pas un palindrome.');
  }
}
