import 'dart:io';

// Retourne 1 ou 2 si un joueur a aligné 3 jetons, sinon null.
int? chercherGagnant(List<List<int>> plateau) {
  // Lignes
  for (int i = 0; i < 3; i++) {
    if (plateau[i][0] != 0 &&
        plateau[i][0] == plateau[i][1] &&
        plateau[i][1] == plateau[i][2]) {
      return plateau[i][0];
    }
  }

  // Colonnes
  for (int j = 0; j < 3; j++) {
    if (plateau[0][j] != 0 &&
        plateau[0][j] == plateau[1][j] &&
        plateau[1][j] == plateau[2][j]) {
      return plateau[0][j];
    }
  }

  // Diagonale principale
  if (plateau[0][0] != 0 &&
      plateau[0][0] == plateau[1][1] &&
      plateau[1][1] == plateau[2][2]) {
    return plateau[0][0];
  }

  // Diagonale inverse
  if (plateau[0][2] != 0 &&
      plateau[0][2] == plateau[1][1] &&
      plateau[1][1] == plateau[2][0]) {
    return plateau[0][2];
  }

  return null;
}

void tester(String titre, List<List<int>> plateau) {
  stdout.writeln('--- $titre ---');
  for (List<int> ligne in plateau) {
    stdout.writeln(ligne.join(' '));
  }

  int? gagnant = chercherGagnant(plateau);
  if (gagnant == null) {
    stdout.writeln('Resultat : pas de gagnant.');
  } else {
    stdout.writeln('Resultat : le joueur $gagnant a gagne.');
  }
  stdout.writeln('');
}

void main() {
  tester('Joueur 1 gagnant (ligne du haut)', [
    [1, 1, 1],
    [0, 2, 0],
    [2, 0, 2],
  ]);

  tester('Joueur 2 gagnant (diagonale)', [
    [2, 1, 1],
    [0, 2, 1],
    [1, 0, 2],
  ]);

  tester('Aucun gagnant', [
    [1, 2, 1],
    [1, 2, 2],
    [2, 1, 1],
  ]);
}
