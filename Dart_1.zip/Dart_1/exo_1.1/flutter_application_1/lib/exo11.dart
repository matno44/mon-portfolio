import 'dart:io';

List<int> premierEtDernier(List<int> liste) {
  if (liste.isEmpty) return [];
  if (liste.length == 1) return [liste.first];
  return [liste.first, liste.last];
}

void main() {
  List<int> a = [5, 10, 15, 20, 25];

  stdout.writeln('Liste de départ : $a');
  stdout.writeln('Premier et dernier : ${premierEtDernier(a)}');
}
