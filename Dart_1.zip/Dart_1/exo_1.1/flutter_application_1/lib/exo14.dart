import 'dart:io';

String inverserMots(String phrase) {
  return phrase.trim().split(RegExp(r'\s+')).reversed.join(' ');
}

void main() {
  stdout.write('Entrez une phrase : ');
  String saisie = stdin.readLineSync() ?? '';

  stdout.writeln(inverserMots(saisie));
}
