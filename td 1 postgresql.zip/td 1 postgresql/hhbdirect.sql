--
-- PostgreSQL database dump
--

\restrict Dwg9wM4Y1jhpacvilflqS75US3Js4uPrgR2dkalTMOK73h0Ik4o8Sz8e824lWf9

-- Dumped from database version 18.6 (Homebrew)
-- Dumped by pg_dump version 18.6

-- Started on 2026-09-11 22:13:21 CEST

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 3935 (class 1262 OID 16401)
-- Name: hhbdirect; Type: DATABASE; Schema: -; Owner: devakwabanm
--

CREATE DATABASE hhbdirect WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE hhbdirect OWNER TO devakwabanm;

\unrestrict Dwg9wM4Y1jhpacvilflqS75US3Js4uPrgR2dkalTMOK73h0Ik4o8Sz8e824lWf9
\connect hhbdirect
\restrict Dwg9wM4Y1jhpacvilflqS75US3Js4uPrgR2dkalTMOK73h0Ik4o8Sz8e824lWf9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 228 (class 1255 OID 16698)
-- Name: get_nb_clients_debiteurs(); Type: FUNCTION; Schema: public; Owner: devakwabanm
--

CREATE FUNCTION public.get_nb_clients_debiteurs() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    
    nb_debiteurs INTEGER;
BEGIN
    
    SELECT COUNT(DISTINCT client.num_client) INTO nb_debiteurs
    FROM client
    
    INNER JOIN posseder ON client.num_client = posseder.num_client
  
    INNER JOIN compte ON posseder.id_type = compte.id_type AND posseder.num_compte = compte.num_compte
    
    WHERE compte.solde < 0 
    AND date_part('year', compte.date_ouvrir) = 2012;

    RETURN nb_debiteurs;
END;
$$;


ALTER FUNCTION public.get_nb_clients_debiteurs() OWNER TO devakwabanm;

--
-- TOC entry 229 (class 1255 OID 16699)
-- Name: inserer_client(character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: devakwabanm
--

CREATE FUNCTION public.inserer_client(p_nom character varying, p_prenom character varying, p_adresse character varying, p_identifiant character varying, p_mdp character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
DECLARE
    nouveau_num_client INTEGER;
BEGIN
    -- 1. On cherche le plus grand numéro actuel et on ajoute 1
    -- (La fonction COALESCE permet de renvoyer 0 si la table est complètement vide)
    SELECT COALESCE(MAX(num_client), 0) + 1 INTO nouveau_num_client 
    FROM client;

    -- 2. On insère le nouveau client avec le numéro calculé
    INSERT INTO client (num_client, nom_client, prenom_client, adresse_client, identifiant_internet, mdp_internet)
    VALUES (nouveau_num_client, p_nom, p_prenom, p_adresse, p_identifiant, p_mdp);

    -- 3. Si on arrive ici, c'est que l'insertion a fonctionné
    RETURN 'Succès : Client ' || p_nom || ' enregistré avec le numéro ' || nouveau_num_client;

-- 4. En cas de problème lors de l'insertion, on capture l'erreur
EXCEPTION WHEN OTHERS THEN
    RETURN 'Échec : Impossible d''enregistrer le client.';
END;
$$;


ALTER FUNCTION public.inserer_client(p_nom character varying, p_prenom character varying, p_adresse character varying, p_identifiant character varying, p_mdp character varying) OWNER TO devakwabanm;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 219 (class 1259 OID 16550)
-- Name: affecter; Type: TABLE; Schema: public; Owner: devakwabanm
--

CREATE TABLE public.affecter (
    num_client integer NOT NULL,
    date date NOT NULL,
    num_agence integer
);


ALTER TABLE public.affecter OWNER TO devakwabanm;

--
-- TOC entry 220 (class 1259 OID 16555)
-- Name: agence; Type: TABLE; Schema: public; Owner: devakwabanm
--

CREATE TABLE public.agence (
    num_agence integer NOT NULL,
    nom_agence character varying(50),
    adresse_agence character varying(192),
    tel_agence character(10)
);


ALTER TABLE public.agence OWNER TO devakwabanm;

--
-- TOC entry 221 (class 1259 OID 16559)
-- Name: client; Type: TABLE; Schema: public; Owner: devakwabanm
--

CREATE TABLE public.client (
    num_client integer NOT NULL,
    nom_client character varying(30),
    prenom_client character varying(30),
    adresse_client character varying(192),
    identifiant_internet character varying(30),
    mdp_internet character varying(30)
);


ALTER TABLE public.client OWNER TO devakwabanm;

--
-- TOC entry 222 (class 1259 OID 16563)
-- Name: compte; Type: TABLE; Schema: public; Owner: devakwabanm
--

CREATE TABLE public.compte (
    id_type smallint NOT NULL,
    num_compte integer NOT NULL,
    date_fermer date,
    date_ouvrir date NOT NULL,
    solde integer
);


ALTER TABLE public.compte OWNER TO devakwabanm;

--
-- TOC entry 223 (class 1259 OID 16569)
-- Name: date; Type: TABLE; Schema: public; Owner: devakwabanm
--

CREATE TABLE public.date (
    date date NOT NULL
);


ALTER TABLE public.date OWNER TO devakwabanm;

--
-- TOC entry 224 (class 1259 OID 16573)
-- Name: operation; Type: TABLE; Schema: public; Owner: devakwabanm
--

CREATE TABLE public.operation (
    id_operation bigint NOT NULL,
    num_compte integer NOT NULL,
    date date NOT NULL,
    id_type smallint NOT NULL,
    id_type_vers smallint,
    num_compte_vers integer,
    designation character varying(50),
    type_operation character varying(20),
    montant integer
);


ALTER TABLE public.operation OWNER TO devakwabanm;

--
-- TOC entry 225 (class 1259 OID 16580)
-- Name: posseder; Type: TABLE; Schema: public; Owner: devakwabanm
--

CREATE TABLE public.posseder (
    num_client integer NOT NULL,
    id_type smallint NOT NULL,
    num_compte integer NOT NULL
);


ALTER TABLE public.posseder OWNER TO devakwabanm;

--
-- TOC entry 226 (class 1259 OID 16586)
-- Name: remunerer; Type: TABLE; Schema: public; Owner: devakwabanm
--

CREATE TABLE public.remunerer (
    date date NOT NULL,
    date_de date NOT NULL,
    id_type smallint NOT NULL,
    taux_interet integer
);


ALTER TABLE public.remunerer OWNER TO devakwabanm;

--
-- TOC entry 227 (class 1259 OID 16592)
-- Name: type_compte; Type: TABLE; Schema: public; Owner: devakwabanm
--

CREATE TABLE public.type_compte (
    id_type smallint NOT NULL,
    designation character varying(50)
);


ALTER TABLE public.type_compte OWNER TO devakwabanm;

--
-- TOC entry 3921 (class 0 OID 16550)
-- Dependencies: 219
-- Data for Name: affecter; Type: TABLE DATA; Schema: public; Owner: devakwabanm
--

COPY public.affecter (num_client, date, num_agence) FROM stdin;
1	2012-10-27	3
3	2012-11-01	1
3	2012-11-03	\N
2	2012-11-02	3
4	2012-11-01	2
5	2012-11-02	\N
\.


--
-- TOC entry 3922 (class 0 OID 16555)
-- Dependencies: 220
-- Data for Name: agence; Type: TABLE DATA; Schema: public; Owner: devakwabanm
--

COPY public.agence (num_agence, nom_agence, adresse_agence, tel_agence) FROM stdin;
1	CAEN Centre	13 Rue St Pierre, 14000 CAEN	0233456789
3	Lannion	2 bis Rue de Brelevenez, 22300 LANNION	0232564345
2	Nogent sur Marne	12 Bd de Strasbourg, 94230 Nogent sur Marne	0145232356
\.


--
-- TOC entry 3923 (class 0 OID 16559)
-- Dependencies: 221
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: devakwabanm
--

COPY public.client (num_client, nom_client, prenom_client, adresse_client, identifiant_internet, mdp_internet) FROM stdin;
1	DUPONT	Pierre	5 Rue du Port, 22300 LANNION	Pdupont	Pdupont
2	DUPONT	Annie	5 Rue du Port, 22300 LANNION	Adupont	Adupont
3	DELAVAL	Jean	12 Bd de l'Orne, 14234 OUISTREHAM	Jdelaval	Jdelaval
4	HANOT	Eric	13 Avenue de Neuilly, 94230 NOGENT SUR MARNE	Ehanot	Ehanot
5	LEVY	Sarah	1 Rue Neuve, 14110 CONDE SUR NOIREAU	Slevy	Slevy
6	MARTIN	Jacques	10 Rue de la Paix, Paris	jmartin	azerty123
\.


--
-- TOC entry 3924 (class 0 OID 16563)
-- Dependencies: 222
-- Data for Name: compte; Type: TABLE DATA; Schema: public; Owner: devakwabanm
--

COPY public.compte (id_type, num_compte, date_fermer, date_ouvrir, solde) FROM stdin;
1	1	\N	2012-10-27	1000
2	1	\N	2012-11-01	2000
1	3	\N	2012-11-02	3400
1	4	\N	2012-11-01	4000
1	5	\N	2012-10-27	-1200
2	5	\N	2012-10-27	500
\.


--
-- TOC entry 3925 (class 0 OID 16569)
-- Dependencies: 223
-- Data for Name: date; Type: TABLE DATA; Schema: public; Owner: devakwabanm
--

COPY public.date (date) FROM stdin;
2012-10-27
2012-11-01
2012-11-02
2012-11-03
2012-01-01
2012-12-31
\.


--
-- TOC entry 3926 (class 0 OID 16573)
-- Dependencies: 224
-- Data for Name: operation; Type: TABLE DATA; Schema: public; Owner: devakwabanm
--

COPY public.operation (id_operation, num_compte, date, id_type, id_type_vers, num_compte_vers, designation, type_operation, montant) FROM stdin;
1	1	2012-10-27	1	\N	\N	Ouverture compte	CREDIT	100
2	1	2012-11-01	1	\N	\N	Versement	CREDIT	900
3	1	2012-11-01	2	\N	\N	Versement Ouverture	CREDIT	2000
4	3	2012-11-02	1	\N	\N	Paye Novembre	CREDIT	5000
5	3	2012-11-03	1	\N	\N	Loyer Novembre	DEBIT	1200
6	3	2012-11-03	1	\N	\N	EDF	DEBIT	400
7	4	2012-11-01	1	\N	\N	Paye Novembre 2012	CREDIT	3500
8	4	2012-11-01	1	\N	\N	Pension	CREDIT	1000
9	4	2012-11-02	1	\N	\N	Rbt CREDIT immobilier	DEBIT	500
10	5	2012-10-27	1	\N	\N	Paye	CREDIT	2500
11	5	2012-10-27	1	2	5	Virement	VIREMENT	500
12	5	2012-11-01	1	\N	\N	Remboursement	DEBIT	3200
\.


--
-- TOC entry 3927 (class 0 OID 16580)
-- Dependencies: 225
-- Data for Name: posseder; Type: TABLE DATA; Schema: public; Owner: devakwabanm
--

COPY public.posseder (num_client, id_type, num_compte) FROM stdin;
1	1	1
1	2	1
2	1	1
3	1	3
4	1	4
5	1	5
5	2	5
\.


--
-- TOC entry 3928 (class 0 OID 16586)
-- Dependencies: 226
-- Data for Name: remunerer; Type: TABLE DATA; Schema: public; Owner: devakwabanm
--

COPY public.remunerer (date, date_de, id_type, taux_interet) FROM stdin;
2012-11-01	2012-01-01	2	2
2012-12-31	2012-11-02	2	4
\.


--
-- TOC entry 3929 (class 0 OID 16592)
-- Dependencies: 227
-- Data for Name: type_compte; Type: TABLE DATA; Schema: public; Owner: devakwabanm
--

COPY public.type_compte (id_type, designation) FROM stdin;
1	Compte Courant
2	Livret A
\.


--
-- TOC entry 3732 (class 2606 OID 16597)
-- Name: affecter pk_affecter; Type: CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.affecter
    ADD CONSTRAINT pk_affecter PRIMARY KEY (num_client, date);


--
-- TOC entry 3734 (class 2606 OID 16599)
-- Name: agence pk_agence; Type: CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.agence
    ADD CONSTRAINT pk_agence PRIMARY KEY (num_agence);


--
-- TOC entry 3736 (class 2606 OID 16601)
-- Name: client pk_client; Type: CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT pk_client PRIMARY KEY (num_client);


--
-- TOC entry 3741 (class 2606 OID 16603)
-- Name: compte pk_compte; Type: CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.compte
    ADD CONSTRAINT pk_compte PRIMARY KEY (id_type, num_compte);


--
-- TOC entry 3743 (class 2606 OID 16605)
-- Name: date pk_date; Type: CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.date
    ADD CONSTRAINT pk_date PRIMARY KEY (date);


--
-- TOC entry 3748 (class 2606 OID 16607)
-- Name: operation pk_operation; Type: CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.operation
    ADD CONSTRAINT pk_operation PRIMARY KEY (id_operation);


--
-- TOC entry 3752 (class 2606 OID 16609)
-- Name: posseder pk_posseder; Type: CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.posseder
    ADD CONSTRAINT pk_posseder PRIMARY KEY (num_client, id_type, num_compte);


--
-- TOC entry 3757 (class 2606 OID 16611)
-- Name: remunerer pk_remunerer; Type: CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.remunerer
    ADD CONSTRAINT pk_remunerer PRIMARY KEY (date, date_de, id_type);


--
-- TOC entry 3759 (class 2606 OID 16613)
-- Name: type_compte pk_type_compte; Type: CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.type_compte
    ADD CONSTRAINT pk_type_compte PRIMARY KEY (id_type);


--
-- TOC entry 3728 (class 1259 OID 16614)
-- Name: i_fk_affecter_agence; Type: INDEX; Schema: public; Owner: devakwabanm
--

CREATE INDEX i_fk_affecter_agence ON public.affecter USING btree (num_agence);


--
-- TOC entry 3729 (class 1259 OID 16615)
-- Name: i_fk_affecter_client; Type: INDEX; Schema: public; Owner: devakwabanm
--

CREATE INDEX i_fk_affecter_client ON public.affecter USING btree (num_client);


--
-- TOC entry 3730 (class 1259 OID 16616)
-- Name: i_fk_affecter_date; Type: INDEX; Schema: public; Owner: devakwabanm
--

CREATE INDEX i_fk_affecter_date ON public.affecter USING btree (date);


--
-- TOC entry 3737 (class 1259 OID 16617)
-- Name: i_fk_compte_date; Type: INDEX; Schema: public; Owner: devakwabanm
--

CREATE INDEX i_fk_compte_date ON public.compte USING btree (date_fermer);


--
-- TOC entry 3738 (class 1259 OID 16618)
-- Name: i_fk_compte_date2; Type: INDEX; Schema: public; Owner: devakwabanm
--

CREATE INDEX i_fk_compte_date2 ON public.compte USING btree (date_ouvrir);


--
-- TOC entry 3739 (class 1259 OID 16619)
-- Name: i_fk_compte_type_compte; Type: INDEX; Schema: public; Owner: devakwabanm
--

CREATE INDEX i_fk_compte_type_compte ON public.compte USING btree (id_type);


--
-- TOC entry 3744 (class 1259 OID 16620)
-- Name: i_fk_operation_compte; Type: INDEX; Schema: public; Owner: devakwabanm
--

CREATE INDEX i_fk_operation_compte ON public.operation USING btree (id_type, num_compte);


--
-- TOC entry 3745 (class 1259 OID 16621)
-- Name: i_fk_operation_compte1; Type: INDEX; Schema: public; Owner: devakwabanm
--

CREATE INDEX i_fk_operation_compte1 ON public.operation USING btree (id_type_vers, num_compte_vers);


--
-- TOC entry 3746 (class 1259 OID 16622)
-- Name: i_fk_operation_date; Type: INDEX; Schema: public; Owner: devakwabanm
--

CREATE INDEX i_fk_operation_date ON public.operation USING btree (date);


--
-- TOC entry 3749 (class 1259 OID 16623)
-- Name: i_fk_posseder_client; Type: INDEX; Schema: public; Owner: devakwabanm
--

CREATE INDEX i_fk_posseder_client ON public.posseder USING btree (num_client);


--
-- TOC entry 3750 (class 1259 OID 16624)
-- Name: i_fk_posseder_compte; Type: INDEX; Schema: public; Owner: devakwabanm
--

CREATE INDEX i_fk_posseder_compte ON public.posseder USING btree (id_type, num_compte);


--
-- TOC entry 3753 (class 1259 OID 16625)
-- Name: i_fk_remunerer_date; Type: INDEX; Schema: public; Owner: devakwabanm
--

CREATE INDEX i_fk_remunerer_date ON public.remunerer USING btree (date);


--
-- TOC entry 3754 (class 1259 OID 16626)
-- Name: i_fk_remunerer_date1; Type: INDEX; Schema: public; Owner: devakwabanm
--

CREATE INDEX i_fk_remunerer_date1 ON public.remunerer USING btree (date_de);


--
-- TOC entry 3755 (class 1259 OID 16627)
-- Name: i_fk_remunerer_type_compte; Type: INDEX; Schema: public; Owner: devakwabanm
--

CREATE INDEX i_fk_remunerer_type_compte ON public.remunerer USING btree (id_type);


--
-- TOC entry 3760 (class 2606 OID 16628)
-- Name: affecter fk_affecter_agence; Type: FK CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.affecter
    ADD CONSTRAINT fk_affecter_agence FOREIGN KEY (num_agence) REFERENCES public.agence(num_agence);


--
-- TOC entry 3761 (class 2606 OID 16633)
-- Name: affecter fk_affecter_client; Type: FK CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.affecter
    ADD CONSTRAINT fk_affecter_client FOREIGN KEY (num_client) REFERENCES public.client(num_client);


--
-- TOC entry 3762 (class 2606 OID 16638)
-- Name: affecter fk_affecter_date; Type: FK CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.affecter
    ADD CONSTRAINT fk_affecter_date FOREIGN KEY (date) REFERENCES public.date(date);


--
-- TOC entry 3763 (class 2606 OID 16643)
-- Name: compte fk_compte_date; Type: FK CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.compte
    ADD CONSTRAINT fk_compte_date FOREIGN KEY (date_fermer) REFERENCES public.date(date);


--
-- TOC entry 3764 (class 2606 OID 16648)
-- Name: compte fk_compte_date2; Type: FK CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.compte
    ADD CONSTRAINT fk_compte_date2 FOREIGN KEY (date_ouvrir) REFERENCES public.date(date);


--
-- TOC entry 3765 (class 2606 OID 16653)
-- Name: compte fk_compte_type_compte; Type: FK CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.compte
    ADD CONSTRAINT fk_compte_type_compte FOREIGN KEY (id_type) REFERENCES public.type_compte(id_type);


--
-- TOC entry 3766 (class 2606 OID 16658)
-- Name: operation fk_operation_compte; Type: FK CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.operation
    ADD CONSTRAINT fk_operation_compte FOREIGN KEY (id_type, num_compte) REFERENCES public.compte(id_type, num_compte);


--
-- TOC entry 3767 (class 2606 OID 16663)
-- Name: operation fk_operation_compte1; Type: FK CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.operation
    ADD CONSTRAINT fk_operation_compte1 FOREIGN KEY (id_type_vers, num_compte_vers) REFERENCES public.compte(id_type, num_compte);


--
-- TOC entry 3768 (class 2606 OID 16668)
-- Name: operation fk_operation_date; Type: FK CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.operation
    ADD CONSTRAINT fk_operation_date FOREIGN KEY (date) REFERENCES public.date(date);


--
-- TOC entry 3769 (class 2606 OID 16673)
-- Name: posseder fk_posseder_client; Type: FK CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.posseder
    ADD CONSTRAINT fk_posseder_client FOREIGN KEY (num_client) REFERENCES public.client(num_client);


--
-- TOC entry 3770 (class 2606 OID 16678)
-- Name: posseder fk_posseder_compte; Type: FK CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.posseder
    ADD CONSTRAINT fk_posseder_compte FOREIGN KEY (id_type, num_compte) REFERENCES public.compte(id_type, num_compte);


--
-- TOC entry 3771 (class 2606 OID 16683)
-- Name: remunerer fk_remunerer_date; Type: FK CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.remunerer
    ADD CONSTRAINT fk_remunerer_date FOREIGN KEY (date) REFERENCES public.date(date);


--
-- TOC entry 3772 (class 2606 OID 16688)
-- Name: remunerer fk_remunerer_date1; Type: FK CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.remunerer
    ADD CONSTRAINT fk_remunerer_date1 FOREIGN KEY (date_de) REFERENCES public.date(date);


--
-- TOC entry 3773 (class 2606 OID 16693)
-- Name: remunerer fk_remunerer_type_compte; Type: FK CONSTRAINT; Schema: public; Owner: devakwabanm
--

ALTER TABLE ONLY public.remunerer
    ADD CONSTRAINT fk_remunerer_type_compte FOREIGN KEY (id_type) REFERENCES public.type_compte(id_type);


--
-- TOC entry 3936 (class 0 OID 0)
-- Dependencies: 5
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO devakwabanm;
GRANT ALL ON SCHEMA public TO PUBLIC;


-- Completed on 2026-09-11 22:13:21 CEST

--
-- PostgreSQL database dump complete
--

\unrestrict Dwg9wM4Y1jhpacvilflqS75US3Js4uPrgR2dkalTMOK73h0Ik4o8Sz8e824lWf9

