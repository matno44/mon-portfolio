CREATE OR REPLACE FUNCTION getNomJour(date_fournie DATE)
RETURNS VARCHAR AS $$
DECLARE
    numero_jour INTEGER;
    nom_jour VARCHAR;
BEGIN
    -- On récupère le numéro du jour de la semaine (1 = Lundi ... 7 = Dimanche)
    numero_jour := EXTRACT(ISODOW FROM date_fournie);

    -- On traduit le chiffre en texte
    CASE numero_jour
        WHEN 1 THEN nom_jour := 'Lundi';
        WHEN 2 THEN nom_jour := 'Mardi';
        WHEN 3 THEN nom_jour := 'Mercredi';
        WHEN 4 THEN nom_jour := 'Jeudi';
        WHEN 5 THEN nom_jour := 'Vendredi';
        WHEN 6 THEN nom_jour := 'Samedi';
        WHEN 7 THEN nom_jour := 'Dimanche';
    END CASE;

    RETURN nom_jour;
END;
$$ LANGUAGE plpgsql;

SELECT getNomJour('2026-02-15');	
