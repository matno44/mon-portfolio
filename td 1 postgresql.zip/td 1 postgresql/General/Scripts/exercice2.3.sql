CREATE OR REPLACE FUNCTION nb_occurrences(lettre VARCHAR,chaine VARCHAR,intervalleDebut INTEGER,intervalleFin INTEGER )
RETURNS INTEGER AS $$
declare

nb_occurence INTEGER = 0;
i INTEGER;
begin

if intervalleDebut > intervalleFin then
RETURN 0;
end if;

i = intervalleDebut;

WHILE i < intervalleFin LOOP 
         
		
        IF SUBSTR(chaine, i, 1) = lettre THEN
            nb_occurence := nb_occurence + 1;
        END IF;
        
        
        i = i + 1;

END LOOP;
RETURN nb_occurence;

END;

$$ LANGUAGE plpgsql;

SELECT nb_occurrences('a', 'Rapaces de Gap', 1, 6);