CREATE OR REPLACE FUNCTION dateSqlToDatefr(date_fournie DATE)
RETURNS VARCHAR AS $$

BEGIN
   
 RETURN TO_CHAR(date_fournie, 'DD/MM/YY');

END;
$$ LANGUAGE plpgsql;

SELECT dateSqlToDatefr('2026-02-15');
