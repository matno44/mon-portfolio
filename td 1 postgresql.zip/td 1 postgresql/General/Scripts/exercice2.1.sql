CREATE OR REPLACE FUNCTION nb_occurrences(lettre VARCHAR,chaine VARCHAR,intervalleDebut INTEGER,intervalleFin INTEGER )
RETURNS INTEGER AS $$
declare

nb_occurence INTEGER = 0;
begin

if intervalleDebut > intervalleFin then
RETURN 0;
end if;
	
FOR i IN intervalleDebut..intervalleFin LOOP
		
	IF SUBSTR(chaine, i, 1) = lettre then
		nb_occurence := nb_occurence + 1;
	end if;

END LOOP;
RETURN nb_occurence;

END;

$$ LANGUAGE plpgsql;

SELECT nb_occurrences('a', 'Rapaces de Gap', 1, 6);