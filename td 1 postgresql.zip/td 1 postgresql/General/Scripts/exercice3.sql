CREATE OR REPLACE FUNCTION getNbJoursParMois(date_fournie DATE)
RETURNS INTEGER AS $$
DECLARE
    nb_jour INTEGER;
BEGIN
    
    nb_jour := EXTRACT(DAY FROM (date_trunc('month', date_fournie) + interval '1 month' - interval '1 day'));

    RETURN nb_jour;
END;
$$ LANGUAGE plpgsql;

SELECT getNbJoursParMois('2026-02-15');