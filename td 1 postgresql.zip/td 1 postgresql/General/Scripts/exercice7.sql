CREATE OR REPLACE FUNCTION inserer_client(
    p_nom VARCHAR, 
    p_prenom VARCHAR, 
    p_adresse VARCHAR, 
    p_identifiant VARCHAR, 
    p_mdp VARCHAR
)
-- La fonction renvoie du texte pour informer du statut de l'enregistrement
RETURNS VARCHAR AS $$
DECLARE
    nouveau_num_client INTEGER;
BEGIN
    -- 1. On cherche le plus grand numéro actuel et on ajoute 1
    -- (La fonction COALESCE permet de renvoyer 0 si la table est complètement vide)
    SELECT COALESCE(MAX(num_client), 0) + 1 INTO nouveau_num_client 
    FROM client;

    -- 2. On insère le nouveau client avec le numéro calculé
    INSERT INTO client (num_client, nom_client, prenom_client, adresse_client, identifiant_internet, mdp_internet)
    VALUES (nouveau_num_client, p_nom, p_prenom, p_adresse, p_identifiant, p_mdp);

    -- 3. Si on arrive ici, c'est que l'insertion a fonctionné
    RETURN 'Succès : Client ' || p_nom || ' enregistré avec le numéro ' || nouveau_num_client;

-- 4. En cas de problème lors de l'insertion, on capture l'erreur
EXCEPTION WHEN OTHERS THEN
    RETURN 'Échec : Impossible d''enregistrer le client.';
END;
$$ LANGUAGE plpgsql;