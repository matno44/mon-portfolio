CREATE OR REPLACE FUNCTION calculer_longueur_max(chaine1 VARCHAR, chaine2 VARCHAR)
RETURNS INTEGER AS $$
DECLARE
    
    longueur1 INTEGER;
    longueur2 INTEGER;
	maxlongueur integer;
BEGIN
    longueur1 = length(chaine1);
    
    longueur2 = length(chaine2);
    
IF longueur1 > longueur2 then
maxlongueur = longueur1;
Else
maxlongueur = longueur2;
end if;
    return maxlongueur ;
END;

$$ LANGUAGE plpgsql;

SELECT calculer_longueur_max('HTML', 'PostgreSQL');