CREATE OR REPLACE FUNCTION get_nb_clients_debiteurs()
RETURNS INTEGER AS $$
DECLARE
    
    nb_debiteurs INTEGER;
BEGIN
    
    SELECT COUNT(DISTINCT client.num_client) INTO nb_debiteurs
    FROM client
    
    INNER JOIN posseder ON client.num_client = posseder.num_client
  
    INNER JOIN compte ON posseder.id_type = compte.id_type AND posseder.num_compte = compte.num_compte
    
    WHERE compte.solde < 0 
    AND date_part('year', compte.date_ouvrir) = 2012;

    RETURN nb_debiteurs;
END;
$$ LANGUAGE plpgsql;

SELECT get_nb_clients_debiteurs();