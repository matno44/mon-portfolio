<?php
require_once 'Model.php';
require_once 'Utilisateur.php';
$query = 'SELECT * FROM utilisateur';

// 3. Appel de la fonction query de l'objet PDO
$rep = Model::$pdo->query($query);
$rep->setFetchMode(PDO::FETCH_CLASS, 'Utilisateur');

// 4 & 5. Récupération des résultats sous forme de tableau d'objets
$tab_utilisateurs = Utilisateur::getAllUtilisateurs();

// 5. Utilisation d'une boucle foreach pour itérer sur le tableau

foreach ($tab_utilisateurs as $utilisateur) {
    $utilisateur->afficher();
    echo '<hr>';
}
