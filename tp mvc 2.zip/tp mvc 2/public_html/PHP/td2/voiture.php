
<?php
class Voiture
{
    private $marque;
    private $couleur;
    private $immatriculation;

    // un constructeur
    public function __construct($m = NULL, $c = NULL, $i = NULL)
    {
        if (!is_null($m) && !is_null($c) && !is_null($i)) {
            $this->marque          = $m;
            $this->couleur         = $c;
            $this->immatriculation = $i;
        }
    }

    // un getter
    public function getMarque()
    {
        return $this->marque;
    }

    public function setMarque($marque2)
    {
        $this->marque = $marque2;
    }

    public function getCouleur()
    {
        return $this->couleur;
    }

    public function setCouleur($couleur2)
    {
        $this->couleur = $couleur2;
    }

    public function getImmatriculation()
    {
        return $this->immatriculation;
    }

    public function setImmatriculation($immatriculation2)
    {
        $this->immatriculation = $immatriculation2;
    }

    // une methode d'affichage.
    public function afficher()
    {
        // À compléter dans le prochain exercice
        echo 'Marque: ' . $this->marque . '<br>';
        echo 'Couleur: ' . $this->couleur . '<br>';
        echo 'Immatriculation: ' . $this->immatriculation . '<br>';
    }

    // Méthode statique pour récupérer toutes les voitures en BDD
    public static function getAllVoitures()
    {
        $query = 'SELECT * FROM voiture';
        $rep   = Model::$pdo->query($query);
        $rep->setFetchMode(PDO::FETCH_CLASS, 'Voiture');

        return $rep->fetchAll();
    }
}
