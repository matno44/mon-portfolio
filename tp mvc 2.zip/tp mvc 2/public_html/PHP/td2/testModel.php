<?php
require_once 'Model.php';
echo 'connexion à la base de données réussie !<br>';
