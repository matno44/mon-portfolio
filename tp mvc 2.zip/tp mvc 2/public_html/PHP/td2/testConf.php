<?php
// On inclut le fichier de classe PHP avec require_once
// pour éviter qu'il soit inclus plusieurs fois
require_once 'Conf.php';

// On affiche le login de la base de données
echo Conf::getLogin() . '<br>';

// On affiche le hostname de la base de données
echo Conf::getHostname() . '<br>';

// On affiche le nom de la base de données (attention à la majuscule "Database")
echo Conf::getDatabase() . '<br>';

// On affiche le mot de passe de la base de données
echo Conf::getPassword() . '<br>';
?>
