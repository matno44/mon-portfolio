<?php
class Trajet
{
    private $id;
    private $depart;
    private $arrivee;
    private $date;
    private $nbplaces;
    private $prix;
    private $conducteur_login;

    public function __construct($data = [])
    {
        foreach ($data as $cle => $valeur) {
            $this->$cle = $valeur;
        }
    }

    public function get($nom_attribut)
    {
        return $this->$nom_attribut;
    }

    public function set($nom_attribut, $valeur)
    {
        $this->$nom_attribut = $valeur;
    }

    public function afficher()
    {
        echo 'Départ: ' . $this->depart . '<br>';
        echo 'Arrivée: ' . $this->arrivee . '<br>';
        echo 'Date: ' . $this->date . '<br>';
        echo 'Nombre de places: ' . $this->nbplaces . '<br>';
        echo 'Prix: ' . $this->prix . '<br>';
        echo 'Login du conducteur: ' . $this->conducteur_login . '<br>';
    }

    public static function getAlltrajets()
    {
        $query = 'SELECT * FROM trajet';
        $rep   = Model::$pdo->query($query);
        $rep->setFetchMode(PDO::FETCH_CLASS, 'Trajet');

        return $rep->fetchAll();
    }
}
?>
