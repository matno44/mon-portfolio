<?php
require_once 'Model.php';
require_once 'voiture.php';
$query = 'SELECT * FROM voiture';

// 3. Appel de la fonction query de l'objet PDO
$rep = Model::$pdo->query($query);
$rep->setFetchMode(PDO::FETCH_CLASS, 'Voiture');

// 4 & 5. Récupération des résultats sous forme de tableau d'objets
$tab_voit = Voiture::getAllVoitures();

// 5. Utilisation d'une boucle foreach pour itérer sur le tableau

foreach ($tab_voit as $voit) {
    $voit->afficher();
    echo '<hr>';
}
