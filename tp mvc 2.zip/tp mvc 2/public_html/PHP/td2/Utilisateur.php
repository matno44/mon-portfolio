<?php
class Utilisateur
{
    private $login;
    private $nom;
    private $prenom;

    public function __construct($login = null, $nom = null, $prenom = null)
    {
        $this->login  = $login;
        $this->nom    = $nom;
        $this->prenom = $prenom;
    }

    public function afficher()
    {
        echo 'Login: ' . $this->login . '<br>';
        echo 'Nom: ' . $this->nom . '<br>';
        echo 'Prénom: ' . $this->prenom . '<br>';
    }

    public static function getAllUtilisateurs()
    {
        $query = 'SELECT * FROM utilisateur';
        $rep   = Model::$pdo->query($query);
        $rep->setFetchMode(PDO::FETCH_CLASS, 'Utilisateur');

        return $rep->fetchAll();
    }
}
