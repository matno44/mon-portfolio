<?php
require_once 'Model.php';
require_once 'Trajet.php';
$query = 'SELECT * FROM trajet';

// 3. Appel de la fonction query de l'objet PDO
$rep = Model::$pdo->query($query);
$rep->setFetchMode(PDO::FETCH_CLASS, 'Trajet');

// 4 & 5. Récupération des résultats sous forme de tableau d'objets
$tab_trajets = Trajet::getAlltrajets();

// 5. Utilisation d'une boucle foreach pour itérer sur le tableau

foreach ($tab_trajets as $trajet) {
    $trajet->afficher();
    echo '<hr>';
}
