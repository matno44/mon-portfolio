-- =====================================================================
-- TD 8 : Les TRIGGERS - HHB-Direct (SLAM 3.3, BTS SIO 2)
-- Base : hhbdirect (PostgreSQL)
--
-- Script rejouable : on peut l'exécuter plusieurs fois sans erreur
--   - CREATE OR REPLACE FUNCTION remplace la fonction si elle existe
--   - DROP TRIGGER IF EXISTS supprime le trigger avant de le recréer
--
-- Rappel du schéma réel (différent du MCD sur certains noms) :
--   compte    (id_type, num_compte, date_fermer, date_ouvrir, solde)
--             clé primaire = (id_type, num_compte)
--   operation (id_operation, num_compte, date, id_type, id_type_vers,
--              num_compte_vers, designation, type_operation, montant)
--             id_operation n'a pas de compteur automatique
--             date doit exister dans la table date (clé étrangère)
--   client    (num_client, nom_client, prenom_client, adresse_client,
--              identifiant_internet, mdp_internet)
--   remunerer (date, date_de, id_type, taux_interet)
--             date_de = début de la période ("DE" dans le MCD)
--             date    = fin de la période   ("A"  dans le MCD)
-- =====================================================================


-- =====================================================================
-- EXERCICE 1 : virement() + trigger de mise à jour des soldes
-- =====================================================================

-- ---------------------------------------------------------------------
-- Fonction virement()
-- Un virement est enregistré sur UNE seule ligne de la table operation,
-- de type 'VIREMENT' (comme l'opération n°11 déjà présente) :
--   - num_compte / id_type           = compte à débiter
--   - num_compte_vers / id_type_vers = compte à créditer
-- Cette ligne représente à la fois le débit et le crédit.
-- La fonction ne touche PAS aux soldes : c'est le trigger qui le fait
-- (sinon les soldes seraient mis à jour deux fois).
-- Retour : 1 si le virement est fait, 0 sinon.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION virement(
    p_num_compte_de   INTEGER,
    p_num_compte_vers INTEGER,
    p_id_type_de      INTEGER,
    p_id_type_vers    INTEGER,
    p_montant         INTEGER,
    p_designation     VARCHAR(50))
RETURNS INTEGER
LANGUAGE plpgsql
AS
$function$
DECLARE
    v_nb_comptes   INTEGER;
    v_solde_de     INTEGER;
    v_id_operation BIGINT;
BEGIN
    -- 1. Le compte à débiter doit exister
    SELECT COUNT(*) INTO v_nb_comptes FROM compte
    WHERE num_compte = p_num_compte_de AND id_type = p_id_type_de;
    IF v_nb_comptes = 0 THEN
        RAISE NOTICE 'Virement refusé : le compte à débiter n''existe pas';
        RETURN 0;
    END IF;

    -- 2. Le compte à créditer doit exister
    SELECT COUNT(*) INTO v_nb_comptes FROM compte
    WHERE num_compte = p_num_compte_vers AND id_type = p_id_type_vers;
    IF v_nb_comptes = 0 THEN
        RAISE NOTICE 'Virement refusé : le compte à créditer n''existe pas';
        RETURN 0;
    END IF;

    -- 3. Le montant doit être positif et les 2 comptes différents
    IF p_montant <= 0 THEN
        RAISE NOTICE 'Virement refusé : le montant doit être positif';
        RETURN 0;
    END IF;
    IF p_num_compte_de = p_num_compte_vers AND p_id_type_de = p_id_type_vers THEN
        RAISE NOTICE 'Virement refusé : les 2 comptes sont identiques';
        RETURN 0;
    END IF;

    -- 4. Le compte débité doit rester créditeur (solde >= 0) après le virement
    SELECT solde INTO v_solde_de FROM compte
    WHERE num_compte = p_num_compte_de AND id_type = p_id_type_de;
    IF v_solde_de - p_montant < 0 THEN
        RAISE NOTICE 'Virement refusé : solde insuffisant (solde = %, montant = %)', v_solde_de, p_montant;
        RETURN 0;
    END IF;

    -- 5. La date du jour doit exister dans la table date (clé étrangère)
    IF NOT EXISTS (SELECT * FROM date WHERE date = CURRENT_DATE) THEN
        INSERT INTO date (date) VALUES (CURRENT_DATE);
    END IF;

    -- 6. Numéro de la nouvelle opération (pas de compteur automatique)
    SELECT COALESCE(MAX(id_operation), 0) + 1 INTO v_id_operation FROM operation;

    -- 7. Enregistrement du virement : le trigger Trig_insert_operation_virement
    --    se déclenche ici et met à jour les 2 soldes
    INSERT INTO operation (id_operation, num_compte, date, id_type, id_type_vers,
                           num_compte_vers, designation, type_operation, montant)
    VALUES (v_id_operation, p_num_compte_de, CURRENT_DATE, p_id_type_de, p_id_type_vers,
            p_num_compte_vers, p_designation, 'VIREMENT', p_montant);

    RETURN 1;

-- Si une erreur arrive pendant les étapes 5 à 7 (ou dans le trigger),
-- PostgreSQL annule tout ce que la fonction a fait : l'opération ET les
-- mises à jour des soldes. Le débit et le crédit sont donc faits tous
-- les 2 ou aucun des 2.
EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'Virement annulé : %', SQLERRM;
    RETURN 0;
END;
$function$;


-- ---------------------------------------------------------------------
-- Fonction trigger insert_operation_virement()
-- Appelée après l'insertion d'une opération de type 'VIREMENT'.
-- NEW = la ligne qui vient d'être insérée dans operation.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION insert_operation_virement()
RETURNS TRIGGER
LANGUAGE plpgsql
AS
$function$
BEGIN
    -- Débit du compte source
    UPDATE compte SET solde = solde - NEW.montant
    WHERE num_compte = NEW.num_compte AND id_type = NEW.id_type;

    -- Crédit du compte destination
    UPDATE compte SET solde = solde + NEW.montant
    WHERE num_compte = NEW.num_compte_vers AND id_type = NEW.id_type_vers;

    -- Pour un trigger AFTER, la valeur retournée est ignorée
    RETURN NULL;
END;
$function$;

-- AFTER INSERT  : on met à jour les soldes une fois l'opération bien enregistrée
-- FOR EACH ROW  : une fois par opération insérée (on a besoin de NEW)
-- WHEN (...)    : le trigger ne se déclenche QUE pour les virements,
--                 pas pour les opérations CREDIT ou DEBIT
DROP TRIGGER IF EXISTS Trig_insert_operation_virement ON operation;
CREATE TRIGGER Trig_insert_operation_virement
AFTER INSERT ON operation
FOR EACH ROW
WHEN (NEW.type_operation = 'VIREMENT')
EXECUTE FUNCTION insert_operation_virement();


-- =====================================================================
-- EXERCICE 2 : création automatique de l'identifiant internet
--              et du compte de connexion PostgreSQL d'un nouveau client
-- =====================================================================

-- ---------------------------------------------------------------------
-- Fonction creer_id_internet() du TP précédent (inchangée)
-- Identifiant = 1re lettre du prénom en majuscule + nom en minuscules
-- (+ un numéro si un client a déjà le même nom et prénom)
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION creer_id_internet(p_nom VARCHAR, p_prenom VARCHAR)
RETURNS VARCHAR
LANGUAGE plpgsql
AS
$function$
DECLARE
    v_compteur INTEGER;
    v_id VARCHAR;
BEGIN
    SELECT COUNT(*) INTO v_compteur FROM client
    WHERE nom_client = p_nom AND prenom_client = p_prenom;
    IF v_compteur = 0 THEN
        v_id := UPPER(SUBSTRING(p_prenom, 1, 1)) || LOWER(p_nom);
    ELSE
        v_id := UPPER(SUBSTRING(p_prenom, 1, 1)) || LOWER(p_nom) || v_compteur;
    END IF;
    RETURN v_id;
END;
$function$;

-- ---------------------------------------------------------------------
-- Fonction creer_user_client() du TP précédent
-- Crée un rôle PostgreSQL (LOGIN) pour chaque client qui n'en a pas.
--
-- CORRECTION TD8 : PostgreSQL met en minuscules les noms de rôles écrits
-- sans guillemets (CREATE ROLE Pdupont crée le rôle "pdupont").
-- L'ancienne version comparait usename avec 'Pdupont' : elle ne trouvait
-- jamais le rôle et essayait de le recréer -> erreur "le rôle existe déjà".
-- On compare donc avec LOWER(identifiant_internet).
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION creer_user_client()
RETURNS INTEGER
LANGUAGE plpgsql
AS
$function$
DECLARE
    v_compteur INTEGER := 0;
    res client%ROWTYPE;
    v_existe INTEGER;
BEGIN
    FOR res IN SELECT * FROM client LOOP
        SELECT COUNT(*) INTO v_existe FROM pg_user
        WHERE usename = LOWER(res.identifiant_internet);   -- CORRECTION TD8
        IF v_existe = 0 THEN
            EXECUTE 'CREATE ROLE ' || res.identifiant_internet || ' WITH LOGIN PASSWORD ''' || res.mdp_internet || '''';
            v_compteur := v_compteur + 1;
        END IF;
    END LOOP;
    RETURN v_compteur;
END;
$function$;

-- ---------------------------------------------------------------------
-- Fonction trigger insert_nouveau_client()  (trigger BEFORE INSERT)
-- On remplit identifiant_internet et mdp_internet dans NEW AVANT que la
-- ligne soit écrite dans la table client.
-- Le mot de passe = l'identifiant, comme pour les clients déjà en base
-- (Pdupont / Pdupont).
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION insert_nouveau_client()
RETURNS TRIGGER
LANGUAGE plpgsql
AS
$function$
BEGIN
    NEW.identifiant_internet := creer_id_internet(NEW.nom_client, NEW.prenom_client);
    NEW.mdp_internet := NEW.identifiant_internet;

    -- Pour un trigger BEFORE, on doit retourner NEW : c'est cette ligne
    -- (modifiée) qui sera insérée
    RETURN NEW;
END;
$function$;

-- BEFORE INSERT : obligatoire pour pouvoir modifier NEW avant l'écriture
-- FOR EACH ROW  : une fois par client inséré
DROP TRIGGER IF EXISTS Trig_insert_nouveau_client ON client;
CREATE TRIGGER Trig_insert_nouveau_client
BEFORE INSERT ON client
FOR EACH ROW
EXECUTE FUNCTION insert_nouveau_client();

-- ---------------------------------------------------------------------
-- Fonction trigger insert_nouveau_client_user()  (trigger AFTER INSERT)
-- creer_user_client() parcourt la table client. Dans un trigger BEFORE,
-- le nouveau client n'est pas encore dans la table : la fonction ne le
-- verrait pas. Il faut donc l'appeler APRÈS l'insertion.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION insert_nouveau_client_user()
RETURNS TRIGGER
LANGUAGE plpgsql
AS
$function$
BEGIN
    -- PERFORM appelle la fonction sans garder son résultat
    PERFORM creer_user_client();
    RETURN NULL;
END;
$function$;

-- AFTER INSERT : la ligne du client est écrite, creer_user_client() la voit
DROP TRIGGER IF EXISTS Trig_insert_nouveau_client_user ON client;
CREATE TRIGGER Trig_insert_nouveau_client_user
AFTER INSERT ON client
FOR EACH ROW
EXECUTE FUNCTION insert_nouveau_client_user();


-- =====================================================================
-- EXERCICE 3 : pas de chevauchement des périodes de rémunération
-- =====================================================================

-- ---------------------------------------------------------------------
-- Fonction trigger insert_remuneration()
--
-- Définition du chevauchement (règle de l'énoncé) :
--   pour un même type de compte (id_type), le début de la nouvelle
--   période (NEW.date_de) doit être STRICTEMENT après la fin de la
--   période précédente, c'est-à-dire la plus grande date de fin (date)
--   déjà enregistrée pour ce type de compte.
--   Si NEW.date_de <= cette date de fin -> chevauchement -> refus.
--   Exemple : période précédente jusqu'au 31/12/2012
--             -> la nouvelle doit commencer le 01/01/2013 ou après.
--
-- On vérifie aussi que la fin de la période n'est pas avant son début.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION insert_remuneration()
RETURNS TRIGGER
LANGUAGE plpgsql
AS
$function$
DECLARE
    v_fin_precedente DATE;
BEGIN
    -- La période doit être dans le bon sens
    IF NEW.date < NEW.date_de THEN
        RAISE EXCEPTION 'Période invalide : la fin (%) est avant le début (%)',
            NEW.date, NEW.date_de;
    END IF;

    -- Fin de la période précédente pour ce type de compte
    -- (NULL s'il n'y a encore aucune rémunération pour ce type)
    SELECT MAX(date) INTO v_fin_precedente FROM remunerer
    WHERE id_type = NEW.id_type;

    IF v_fin_precedente IS NOT NULL AND NEW.date_de <= v_fin_precedente THEN
        RAISE EXCEPTION 'Chevauchement de période pour le type de compte % : la nouvelle période commence le % mais la période précédente se termine le %',
            NEW.id_type, NEW.date_de, v_fin_precedente;
    END IF;

    -- Pas de problème : on laisse l'insertion se faire
    RETURN NEW;
END;
$function$;

-- BEFORE INSERT : on vérifie AVANT d'écrire ; RAISE EXCEPTION annule
--                 l'insertion, la ligne n'est jamais enregistrée
-- FOR EACH ROW  : on vérifie chaque rémunération insérée
DROP TRIGGER IF EXISTS Trig_insert_remuneration ON remunerer;
CREATE TRIGGER Trig_insert_remuneration
BEFORE INSERT ON remunerer
FOR EACH ROW
EXECUTE FUNCTION insert_remuneration();
