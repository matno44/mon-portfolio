-- =====================================================================
-- TD8 - Authentification & validation par email
-- Modifications de la base `garage` (table utilisateur)
-- A rejouer avec : mysql -uroot garage < modifications_td8.sql
-- =====================================================================

-- --- Exercice 1 : mot de passe ---------------------------------------
-- Colonne mdp : stockera d'abord le mot de passe en clair (ex.1),
-- puis le haché SHA-256 (ex.2), long de 64 caractères hexadécimaux.
ALTER TABLE utilisateur ADD COLUMN mdp VARCHAR(64) DEFAULT NULL;

-- --- Partie 3 : validation par email ---------------------------------
-- Exercice 13 : adresse email de l'utilisateur.
ALTER TABLE utilisateur ADD COLUMN email VARCHAR(128) DEFAULT NULL;

-- Exercice 14 : nonce de validation. Tant qu'il n'est pas NULL,
-- le compte n'est pas validé et la connexion est refusée.
ALTER TABLE utilisateur ADD COLUMN nonce VARCHAR(32) DEFAULT NULL;

-- --- Exercice 11 : administrateur ------------------------------------
ALTER TABLE utilisateur ADD COLUMN admin BOOLEAN NOT NULL DEFAULT 0;

-- =====================================================================
-- Comptes de test (créés au fil du TD)
-- =====================================================================
-- Les hachés ci-dessous sont recalculés par le site lors de la création
-- via le formulaire ; ces INSERT servent de trace / de rejeu.
-- (voir td8/captures/journal.md pour les identifiants en clair)

-- Compte « victime » (ex.3/ex.4) : mot de passe réel = "password".
-- Créé via le formulaire ; le haché ci-dessous inclut la graine de l'ex.4.
-- INSERT INTO utilisateur (login,nom,prenom,mdp)
--   VALUES ('victime','Victime','Paul','254aac10dd84515c4e70da4e4bf81ff530c5f035c0bebe6f70cf14fb4899943e');

-- Compte non-admin de test (ex.5+) : matk / "matk2024".
-- UPDATE utilisateur SET mdp = <haché avec graine> WHERE login='matk';
-- Compte administrateur de test (ex.11) : admin1 / "admin2024", admin=1.
-- INSERT INTO utilisateur (login,nom,prenom,mdp,admin)
--   VALUES ('admin1','Chef','Ada', <haché avec graine>, 1);
