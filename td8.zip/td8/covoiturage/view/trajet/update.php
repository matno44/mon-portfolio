<?php
// Vue commune aux actions create et update.
// Variables initialisées par le contrôleur :
//   $id ('' pour create), $depart, $arrivee, $date, $nbplaces, $prix, $conducteur_login
//   $tab_u : liste des utilisateurs pour choisir le conducteur
//   $action_form : 'save' (create) ou 'updated' (update)
$tId         = htmlspecialchars($id);
$tDepart     = htmlspecialchars($depart);
$tArrivee    = htmlspecialchars($arrivee);
$tDate       = htmlspecialchars($date);
$tNbplaces   = htmlspecialchars($nbplaces);
$tPrix       = htmlspecialchars($prix);
$actionForm  = htmlspecialchars($action_form);
$controleur  = htmlspecialchars(static::$object);
$titreHTML   = htmlspecialchars($pagetitle);
?>
<?php // TD8 ex.15 : GET en debug (mot de passe visible dans l'URL), POST en production ?>
<form method="<?php echo Conf::getDebug() ? 'get' : 'post'; ?>" action="index.php">
    <fieldset>
        <legend><?php echo $titreHTML; ?> :</legend>
        <!-- Champs cachés : contrôleur et action transmis au routeur -->
        <input type="hidden" name="controller" value="<?php echo $controleur; ?>" />
        <input type="hidden" name="action" value="<?php echo $actionForm; ?>" />
        <?php if ($id !== '') { ?>
        <p>
            <!-- L'id est la clé primaire : affiché mais non modifiable -->
            <label for="id_id">Numéro du trajet</label> :
            <input type="text" name="id" id="id_id" value="<?php echo $tId; ?>" readonly />
        </p>
        <?php } ?>
        <p>
            <label for="depart_id">Départ</label> :
            <input type="text" placeholder="Ex : Lille" name="depart" id="depart_id"
                   value="<?php echo $tDepart; ?>" required />
        </p>
        <p>
            <label for="arrivee_id">Arrivée</label> :
            <input type="text" placeholder="Ex : Paris" name="arrivee" id="arrivee_id"
                   value="<?php echo $tArrivee; ?>" required />
        </p>
        <p>
            <label for="date_id">Date</label> :
            <input type="date" name="date" id="date_id"
                   value="<?php echo $tDate; ?>" required />
        </p>
        <p>
            <label for="nbplaces_id">Nombre de places</label> :
            <input type="number" min="1" name="nbplaces" id="nbplaces_id"
                   value="<?php echo $tNbplaces; ?>" required />
        </p>
        <p>
            <label for="prix_id">Prix (€)</label> :
            <input type="number" min="0" name="prix" id="prix_id"
                   value="<?php echo $tPrix; ?>" required />
        </p>
        <p>
            <label for="conducteur_id">Conducteur</label> :
            <select name="conducteur_login" id="conducteur_id" required>
                <?php
                foreach ($tab_u as $u) {
                    $uLoginHTML = htmlspecialchars($u->getLogin());
                    $uNomHTML   = htmlspecialchars($u->getPrenom() . ' ' . $u->getNom());
                    // on présélectionne le conducteur actuel (mise à jour)
                    $selected   = ($u->getLogin() == $conducteur_login) ? ' selected' : '';
                    echo '<option value="' . $uLoginHTML . '"' . $selected . '>'
                        . $uLoginHTML . ' (' . $uNomHTML . ')</option>';
                }
                ?>
            </select>
        </p>
        <p>
            <input type="submit" value="Envoyer" />
        </p>
    </fieldset>
</form>
