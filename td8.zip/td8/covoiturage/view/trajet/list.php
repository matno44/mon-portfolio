
        <?php
        foreach ($tab_t as $t) {
            $tIdHTML      = htmlspecialchars($t->getId());
            $tIdURL       = rawurlencode($t->getId());
            $tDepartHTML  = htmlspecialchars($t->getDepart());
            $tArriveeHTML = htmlspecialchars($t->getArrivee());
            $tDateHTML    = htmlspecialchars($t->getDate());
            $tPrixHTML    = htmlspecialchars($t->getPrix());
            echo '<p> Trajet <a href="index.php?controller=trajet&action=read&id=' . $tIdURL . '">n°' . $tIdHTML . '</a> : '
                . $tDepartHTML . ' → ' . $tArriveeHTML . ' le ' . $tDateHTML . ', ' . $tPrixHTML . ' €'
                . ' (<a href="index.php?controller=trajet&action=delete&id=' . $tIdURL . '">supprimer</a>)'
                . ' (<a href="index.php?controller=panier&action=ajouter&id=' . $tIdURL . '">ajouter au panier</a>).</p>';
        }
        ?>
<p><a href="index.php?controller=trajet&action=create">Ajouter un trajet</a></p>
