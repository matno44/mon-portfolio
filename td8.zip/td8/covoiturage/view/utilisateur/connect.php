<?php
// TD8 ex.5 : formulaire de connexion (login + mot de passe).
// À l'envoi, il appelle l'action « connected » du contrôleur utilisateur.
// La méthode est POST pour ne pas faire apparaître le mot de passe dans l'URL.
?>
<form method="post" action="index.php?controller=utilisateur&action=connected">
    <fieldset>
        <legend>Connexion :</legend>
        <p>
            <label for="login_id">Login</label> :
            <input type="text" placeholder="Ex : jdupont" name="login" id="login_id" required />
        </p>
        <p>
            <label for="mdp_id">Mot de passe</label> :
            <input type="password" name="mdp" id="mdp_id" required />
        </p>
        <p>
            <input type="submit" value="Se connecter" />
        </p>
    </fieldset>
</form>
