<?php
$uLogin    = htmlspecialchars($u->getLogin());
$uNom      = htmlspecialchars($u->getNom());
$uPrenom   = htmlspecialchars($u->getPrenom());
$uLoginURL = rawurlencode($u->getLogin());

echo '<p>Login : ' . $uLogin . '</p>';
echo '<p>Nom : ' . $uNom . '</p>';
echo '<p>Prénom : ' . $uPrenom . '</p>';
echo '<p><a href="index.php?controller=utilisateur&action=readTrajets&login=' . $uLoginURL . '">Voir ses trajets en tant que passager</a></p>';

// TD8 ex.8 : les liens « modifier » et « supprimer » ne s'affichent que pour
// l'utilisateur connecté sur sa propre fiche (ou, ex.11, pour un administrateur).
if (Session::is_user($u->getLogin()) || Session::is_admin()) {
    echo '<p><a href="index.php?controller=utilisateur&action=update&login=' . $uLoginURL . '">Mettre à jour l\'utilisateur</a></p>';
    echo '<p><a href="index.php?controller=utilisateur&action=delete&login=' . $uLoginURL . '">Supprimer l\'utilisateur</a></p>';
}
