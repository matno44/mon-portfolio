<?php
// TD8 ex.14 : affiche le résultat de la validation du compte (message simple).
$messageHTML = htmlspecialchars($message);
echo '<h2>Validation du compte</h2>';
echo '<p>' . $messageHTML . '</p>';
echo '<p><a href="index.php?controller=utilisateur&action=connect">Aller à la connexion</a></p>';
