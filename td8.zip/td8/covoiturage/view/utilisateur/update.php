<?php
// Vue commune aux actions create et update.
// Variables initialisées par le contrôleur :
//   $login, $nom, $prenom : valeurs des champs (chaînes vides pour create)
//   $champ_login : 'required' (create) ou 'readonly' (update)
//   $action_form : 'save' (create) ou 'updated' (update)
$uLogin      = htmlspecialchars($login);
$uNom        = htmlspecialchars($nom);
$uPrenom     = htmlspecialchars($prenom);
$uEmail      = htmlspecialchars(isset($email) ? $email : '');  // TD8 ex.13
$champLogin  = htmlspecialchars($champ_login);
$actionForm  = htmlspecialchars($action_form);
$controleur  = htmlspecialchars(static::$object);
$titreHTML   = htmlspecialchars($pagetitle);
?>
<?php // TD8 ex.15 : GET en debug (mot de passe visible dans l'URL), POST en production ?>
<form method="<?php echo Conf::getDebug() ? 'get' : 'post'; ?>" action="index.php">
    <fieldset>
        <legend><?php echo $titreHTML; ?> :</legend>
        <!-- Champs cachés : contrôleur et action transmis au routeur -->
        <input type="hidden" name="controller" value="<?php echo $controleur; ?>" />
        <input type="hidden" name="action" value="<?php echo $actionForm; ?>" />
        <p>
            <label for="login_id">Login</label> :
            <input type="text" placeholder="Ex : jdupont" name="login" id="login_id"
                   value="<?php echo $uLogin; ?>" <?php echo $champLogin; ?> />
        </p>
        <p>
            <label for="nom_id">Nom</label> :
            <input type="text" placeholder="Ex : Dupont" name="nom" id="nom_id"
                   value="<?php echo $uNom; ?>" required />
        </p>
        <p>
            <label for="prenom_id">Prénom</label> :
            <input type="text" placeholder="Ex : Jean" name="prenom" id="prenom_id"
                   value="<?php echo $uPrenom; ?>" required />
        </p>
        <!-- TD8 ex.13 : adresse email, contrôlée côté navigateur (type=email)
             ET côté serveur (filter_var) dans l'action save. -->
        <p>
            <label for="email_id">Email</label> :
            <input type="email" placeholder="Ex : jean@yopmail.com" name="email" id="email_id"
                   value="<?php echo $uEmail; ?>" <?php echo $champ_login === 'required' ? 'required' : ''; ?> />
        </p>
        <!-- TD8 ex.1 : deux champs mot de passe à saisir deux fois.
             En création ils sont obligatoires ; en mise à jour on peut les
             laisser vides pour conserver le mot de passe actuel. -->
        <p>
            <label for="mdp_id">Mot de passe</label> :
            <input type="password" name="mdp" id="mdp_id" <?php echo $champ_login === 'required' ? 'required' : ''; ?> />
        </p>
        <p>
            <label for="mdp2_id">Confirmation</label> :
            <input type="password" name="mdp2" id="mdp2_id" <?php echo $champ_login === 'required' ? 'required' : ''; ?> />
        </p>
<?php
// TD8 ex.12 : la case « Administrateur ? » n'est visible que pour un admin connecté.
// (La vérification réelle est refaite côté serveur dans updated().)
if (Session::is_admin()) {
    $checked = (isset($admin) && $admin) ? 'checked' : '';
    echo '<p>';
    echo '<label for="admin_id">Administrateur ?</label> : ';
    echo '<input type="checkbox" name="admin" id="admin_id" value="1" ' . $checked . ' />';
    echo '</p>';
}
?>
        <p>
            <input type="submit" value="Envoyer" />
        </p>
    </fieldset>
</form>
