<h2>Mon panier</h2>
<?php
if (empty($panier)) {
    echo '<p>Votre panier est vide.</p>';
} else {
    echo '<table border="1" cellpadding="5">';
    echo '<tr><th>Trajet</th><th>Prix unitaire</th><th>Places</th><th>Sous-total</th></tr>';
    foreach ($panier as $id => $ligne) {
        $trajetHTML = htmlspecialchars($ligne['depart'] . ' → ' . $ligne['arrivee']);
        echo '<tr><td>n°' . htmlspecialchars($id) . ' : ' . $trajetHTML . '</td>'
            . '<td>' . htmlspecialchars($ligne['prix']) . ' €</td>'
            . '<td>' . htmlspecialchars($ligne['quantite']) . '</td>'
            . '<td>' . htmlspecialchars($ligne['prix'] * $ligne['quantite']) . ' €</td></tr>';
    }
    echo '</table>';
}
// Le prix total vient de la session (calculé dans index.php)
echo '<p><strong>Prix total : ' . htmlspecialchars($prix_total) . ' €</strong></p>';
echo '<p>Le panier est vidé automatiquement après ' . DUREE_PANIER . ' secondes d\'inactivité.</p>';
?>
<p>
    <a href="index.php?controller=trajet&action=readAll">Ajouter des trajets</a> |
    <a href="index.php?controller=panier&action=vider">Vider le panier</a>
</p>
<h3>Contenu de $_SESSION (pour vérification)</h3>
<pre><?php var_dump($_SESSION); ?></pre>
