<?php
// TD8 - Classe utilitaire pour la sécurité (hachage des mots de passe).
class Security
{
    // TD8 ex.4 : graine privée (sel) concaténée au mot de passe avant hachage.
    // Elle est générée une fois, localement, et reste secrète (côté serveur).
    static private $seed = 'f3A7kQ9zL1mX6pR2uB8d';

    // Accesseur de la graine (utilisé par chiffrer()).
    public static function getSeed()
    {
        return self::$seed;
    }

    // TD8 ex.2 : chiffre (hache) un mot de passe avec SHA-256.
    // TD8 ex.4 : on concatène d'abord la graine privée (sel), puis on hache.
    // Le haché ne correspond donc plus au SHA-256 brut du mot de passe :
    // les dictionnaires de hachés « tout prêts » (ex.3) deviennent inutiles.
    // Le résultat fait 64 caractères hexadécimaux : il tient dans mdp VARCHAR(64).
    public static function chiffrer($chaine)
    {
        return hash('sha256', self::getSeed() . $chaine);
    }

    // TD8 ex.14 : génère une chaîne hexadécimale aléatoire de $longueur caractères
    // (par défaut 32), utilisée comme nonce de validation par email.
    public static function generateRandomHex($longueur = 32)
    {
        // bin2hex double la taille : on génère donc $longueur/2 octets.
        return substr(bin2hex(random_bytes((int)ceil($longueur / 2))), 0, $longueur);
    }
}
