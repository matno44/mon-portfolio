<?php
// TD8 - Classe utilitaire pour interroger la session (utilisateur connecté).
// Elle est incluse juste après le session_start() d'index.php.
class Session
{
    // TD8 ex.5 : login de l'utilisateur connecté, ou null si personne ne l'est.
    public static function getLogin()
    {
        return isset($_SESSION['login']) ? $_SESSION['login'] : null;
    }

    // TD8 ex.8 : vrai si l'utilisateur connecté est bien celui de login $login.
    public static function is_user($login)
    {
        return isset($_SESSION['login']) && $_SESSION['login'] === $login;
    }

    // TD8 ex.11 : vrai si l'utilisateur connecté est administrateur.
    public static function is_admin()
    {
        return isset($_SESSION['admin']) && $_SESSION['admin'];
    }
}
