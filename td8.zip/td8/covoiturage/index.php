<?php
// TD7 - Exercice 4
// 1. On démarre la session ici, dans index.php, pour que toutes les pages
//    du site puissent l'utiliser, et AVANT toute écriture de HTML.
session_start();

// TD8 ex.8 : classe utilitaire pour interroger la session (utilisateur connecté).
// Incluse juste après session_start() pour être disponible partout.
require_once __DIR__ . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'Session.php';

// 4. Durée de vie du panier en secondes : 10 s pour les tests, puis 10 minutes
define('DUREE_PANIER', 600);  // 10 minutes = 10 * 60 secondes

// 4. Si la dernière activité est trop ancienne, on supprime la session (et donc le panier)
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > DUREE_PANIER)) {
    session_unset();    // vide le tableau $_SESSION
    session_destroy();  // supprime les données de session sur le serveur
    session_start();    // on repart avec une nouvelle session vide
}
$_SESSION['LAST_ACTIVITY'] = time();  // date de la dernière activité

// 2. Tout le panier est stocké dans la session (tableau vide au départ)
if (!isset($_SESSION['panier'])) {
    $_SESSION['panier'] = array();
}

// 3. Le prix total est recalculé à chaque appel de page et inscrit dans la session
$prix_total = 0;
foreach ($_SESSION['panier'] as $ligne) {
    $prix_total = $prix_total + $ligne['prix'] * $ligne['quantite'];
}
$_SESSION['prix_total'] = $prix_total;

$DS          = DIRECTORY_SEPARATOR;
$ROOT_FOLDER = __DIR__;
require_once $ROOT_FOLDER . $DS . 'lib' . $DS . 'File.php';
require_once File::build_path(array('controller', 'routeur.php'));
?>
