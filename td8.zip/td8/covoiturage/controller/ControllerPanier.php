<?php

require_once File::build_path(array('model', 'ModelTrajet.php'));

// TD7 - Exercice 4 : panier de trajets stocké dans la session.
// La session est démarrée dans index.php ; le prix total est calculé dans index.php.
class ControllerPanier
{
    // Nom de l'objet géré : sert à la vue générique pour trouver le dossier view/panier/
    protected static $object = 'panier';

    // Action readAll : affiche le contenu du panier et son prix total.
    public static function readAll()
    {
        $panier     = $_SESSION['panier'];
        $prix_total = $_SESSION['prix_total'];
        $view       = 'list';
        $pagetitle  = 'Mon panier';
        require File::build_path(array('view', 'view.php'));
    }

    // Action ajouter : ajoute au panier le trajet dont l'id est passé dans l'URL.
    public static function ajouter()
    {
        $id = isset($_GET['id']) ? $_GET['id'] : null;
        $t  = ModelTrajet::select($id);

        if ($t === false) {
            $message    = 'Aucun trajet ne correspond à l\'identifiant ' . $id . '.';
            $view       = 'error';
            $pagetitle  = 'Erreur';
            require File::build_path(array('view', 'view.php'));
            return;
        }

        if (isset($_SESSION['panier'][$id])) {
            // trajet déjà dans le panier : une place de plus
            $_SESSION['panier'][$id]['quantite']++;
        } else {
            // le prix vient de la base de données, jamais de l'internaute
            $_SESSION['panier'][$id] = array(
                'depart'   => $t->getDepart(),
                'arrivee'  => $t->getArrivee(),
                'prix'     => $t->getPrix(),
                'quantite' => 1,
            );
        }

        // On recharge le panier : index.php recalcule alors le prix total
        header('Location: index.php?controller=panier&action=readAll');
        exit();
    }

    // Action vider : vide le panier.
    public static function vider()
    {
        $_SESSION['panier'] = array();
        header('Location: index.php?controller=panier&action=readAll');
        exit();
    }

    // Action error : affiche la vue d'erreur.
    public static function error()
    {
        $message    = "Cette action n'existe pas.";
        $view       = 'error';
        $pagetitle  = 'Erreur';
        require File::build_path(array('view', 'view.php'));
    }
}
