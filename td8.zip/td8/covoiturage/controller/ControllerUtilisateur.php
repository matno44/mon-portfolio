<?php

require_once File::build_path(array('model', 'ModelUtilisateur.php'));
require_once File::build_path(array('model', 'ModelTrajet.php'));  // trajets d'un passager
require_once File::build_path(array('lib', 'Security.php'));       // TD8 : hachage du mot de passe

class ControllerUtilisateur
{
    // Nom de l'objet géré : sert à la vue générique pour trouver le dossier view/utilisateur/
    protected static $object = 'utilisateur';

    // Une action correspond généralement à une page Web.

    // Action readAll : affiche tous les utilisateurs.
    public static function readAll()
    {
        $tab_u      = ModelUtilisateur::selectAll();           // appel au modèle pour gérer la BD
        $view       = 'list';
        $pagetitle  = 'Liste des utilisateurs';
        require File::build_path(array('view', 'view.php'));   // vue générique
    }

    // Action read : affiche le détail de l'utilisateur dont le login
    // est passé dans l'URL.
    public static function read()
    {
        $login = !is_null(myGet('login')) ? myGet('login') : null;
        $u     = ModelUtilisateur::select($login);

        if ($u === false) {
            $message    = "Aucun utilisateur ne correspond au login " . $login . '.';
            $view       = 'error';
            $pagetitle  = 'Erreur';
        } else {
            $view       = 'detail';
            $pagetitle  = "Détail de l'utilisateur";
        }
        require File::build_path(array('view', 'view.php'));
    }

    // Action create : affiche le formulaire (vide) de création d'un utilisateur.
    public static function create()
    {
        // Les champs du formulaire sont vides
        $login  = '';
        $nom    = '';
        $prenom = '';
        $email  = '';               // TD8 ex.13 : email vide à la création
        $admin  = 0;                // TD8 ex.12 : non administrateur par défaut

        $champ_login = 'required';  // on doit saisir le login
        $action_form = 'save';      // action appelée à l'envoi du formulaire

        $view       = 'update';
        $pagetitle  = "Création d'un utilisateur";
        require File::build_path(array('view', 'view.php'));
    }

    // Action save : enregistre l'utilisateur reçu puis réaffiche la liste.
    public static function save()
    {
        // On vérifie que les données du formulaire sont bien présentes
        if (is_null(myGet('login')) || is_null(myGet('nom')) || is_null(myGet('prenom'))
            || is_null(myGet('mdp')) || is_null(myGet('mdp2')) || is_null(myGet('email'))) {
            self::error();
            return;
        }

        // TD8 ex.1 : on vérifie que les deux champs mot de passe coïncident.
        if (myGet('mdp') !== myGet('mdp2')) {
            $message    = "Les deux mots de passe ne coïncident pas.";
            $view       = 'error';
            $pagetitle  = 'Erreur';
            require File::build_path(array('view', 'view.php'));
            return;
        }

        // TD8 ex.13 : validation de l'email CÔTÉ SERVEUR avec filter_var().
        // Le contrôle HTML (type="email") peut être contourné : on le refait ici.
        if (!filter_var(myGet('email'), FILTER_VALIDATE_EMAIL)) {
            $message    = "L'adresse email « " . myGet('email') . " » n'est pas valide.";
            $view       = 'error';
            $pagetitle  = 'Erreur';
            require File::build_path(array('view', 'view.php'));
            return;
        }

        // TD8 ex.14 : on génère un nonce de validation (32 caractères hexadécimaux).
        // Tant qu'il n'est pas NULL, le compte n'est pas validé (connexion refusée).
        $nonce = Security::generateRandomHex(32);

        // tableau associatif : les clés sont les noms des champs de la table
        $data = array(
            'login'  => myGet('login'),
            'nom'    => myGet('nom'),
            'prenom' => myGet('prenom'),
            'email'  => myGet('email'),   // TD8 ex.13 : email validé par filter_var
            // TD8 ex.2 : on enregistre le mot de passe haché (SHA-256), jamais en clair.
            'mdp'    => Security::chiffrer(myGet('mdp')),
            'nonce'  => $nonce,           // TD8 ex.14 : compte non validé à la création
        );

        if (ModelUtilisateur::save($data)) {
            // TD8 ex.14 : on envoie le mail de validation (vers Mailpit en local).
            self::envoyerMailValidation(myGet('login'), myGet('email'), $nonce);

            $tab_u      = ModelUtilisateur::selectAll();
            $view       = 'created';
            $pagetitle  = 'Utilisateur créé';
        } else {
            $message    = "L'utilisateur n'a pas pu être créé (login déjà utilisé ?).";
            $view       = 'error';
            $pagetitle  = 'Erreur';
        }
        require File::build_path(array('view', 'view.php'));
    }

    // TD8 ex.14 : envoie un mail HTML contenant le lien de validation du compte.
    // En local, le mail est intercepté par Mailpit (aucun vrai envoi).
    private static function envoyerMailValidation($login, $email, $nonce)
    {
        // Lien absolu vers l'action validate (login + nonce en GET).
        $lien = 'http://localhost:8000/covoiturage/index.php'
            . '?controller=utilisateur&action=validate'
            . '&login=' . rawurlencode($login)
            . '&nonce=' . rawurlencode($nonce);

        $sujet   = 'Validation de votre compte covoiturage';
        $corps   = '<html><body>'
            . '<h2>Bienvenue ' . htmlspecialchars($login) . ' !</h2>'
            . '<p>Pour activer votre compte, cliquez sur le lien de validation :</p>'
            . '<p><a href="' . $lien . '">Valider mon compte</a></p>'
            . '<p>Si le lien ne fonctionne pas, copiez cette adresse dans votre navigateur :<br>'
            . $lien . '</p>'
            . '</body></html>';

        // En-têtes pour un mail au format HTML.
        $entetes  = "MIME-Version: 1.0\r\n";
        $entetes .= "Content-Type: text/html; charset=UTF-8\r\n";
        $entetes .= "From: covoiturage@yopmail.com\r\n";

        // mail() utilise le sendmail_path configuré (redirigé vers Mailpit en local).
        mail($email, $sujet, $corps, $entetes);
    }

    // TD8 ex.14 : validation du compte. Si le couple (login, nonce) correspond,
    // on passe le nonce à NULL : le compte est alors validé et la connexion possible.
    public static function validate()
    {
        $login = !is_null(myGet('login')) ? myGet('login') : null;
        $nonce = !is_null(myGet('nonce')) ? myGet('nonce') : null;

        $u = ModelUtilisateur::select($login);

        if ($u !== false && $nonce !== null && $u->getNonce() === $nonce) {
            // Tout correspond : on valide le compte (nonce à NULL).
            ModelUtilisateur::update(array('login' => $login, 'nonce' => null));
            $message    = "Votre compte « " . htmlspecialchars($login) . " » est maintenant validé. Vous pouvez vous connecter.";
        } else {
            $message    = "Lien de validation invalide ou compte déjà validé.";
        }
        $view       = 'valide';  // vue dédiée au message de validation
        $pagetitle  = 'Validation du compte';
        require File::build_path(array('view', 'view.php'));
    }

    // Action update : affiche le formulaire de mise à jour pré-rempli.
    public static function update()
    {
        $login = !is_null(myGet('login')) ? myGet('login') : null;

        // TD8 ex.9 : on ne peut modifier que SA PROPRE fiche (ou être admin, ex.11).
        // Sinon on redirige vers le formulaire de connexion.
        if (!Session::is_user($login) && !Session::is_admin()) {
            header('Location: index.php?controller=utilisateur&action=connect');
            exit();
        }

        $u     = ModelUtilisateur::select($login);

        if ($u === false) {
            $message    = "Aucun utilisateur ne correspond au login " . $login . '.';
            $view       = 'error';
            $pagetitle  = 'Erreur';
        } else {
            // Les champs du formulaire sont pré-remplis avec l'utilisateur
            $login  = $u->getLogin();
            $nom    = $u->getNom();
            $prenom = $u->getPrenom();
            $email  = $u->getEmail();   // TD8 ex.13 : email actuel (pré-rempli)
            $admin  = $u->getAdmin();   // TD8 ex.12 : statut admin actuel (pour la case)

            $champ_login = 'readonly';  // on ne modifie pas la clé primaire
            $action_form = 'updated';   // action appelée à l'envoi du formulaire

            $view       = 'update';
            $pagetitle  = "Mise à jour d'un utilisateur";
        }
        require File::build_path(array('view', 'view.php'));
    }

    // Action updated : met à jour l'utilisateur puis affiche la liste.
    public static function updated()
    {
        // On vérifie que les données du formulaire sont bien présentes
        if (is_null(myGet('login')) || is_null(myGet('nom')) || is_null(myGet('prenom'))) {
            self::error();
            return;
        }

        $login = myGet('login');

        // TD8 ex.10 : on ne peut enregistrer une modification que sur SA PROPRE
        // fiche (ou être admin, ex.11). Empêche la mise à jour forgée par l'URL.
        if (!Session::is_user($login) && !Session::is_admin()) {
            header('Location: index.php?controller=utilisateur&action=connect');
            exit();
        }

        $data  = array(
            'login'  => $login,
            'nom'    => myGet('nom'),
            'prenom' => myGet('prenom'),
        );

        // TD8 ex.1 : si un nouveau mot de passe est saisi, les deux champs
        // doivent coïncider. Laissés vides, on conserve le mot de passe actuel.
        if (!is_null(myGet('mdp')) && myGet('mdp') !== '') {
            if (is_null(myGet('mdp2')) || myGet('mdp') !== myGet('mdp2')) {
                $message    = "Les deux mots de passe ne coïncident pas.";
                $view       = 'error';
                $pagetitle  = 'Erreur';
                require File::build_path(array('view', 'view.php'));
                return;
            }
            $data['mdp'] = Security::chiffrer(myGet('mdp'));   // TD8 ex.2 : haché SHA-256
        }

        // TD8 ex.12 : seul un administrateur peut modifier le champ admin.
        // La case cochée envoie admin=1 ; décochée, le paramètre est absent.
        // La vérification Session::is_admin() empêche un non-admin de se promouvoir
        // même en forgeant « &admin=1 » dans l'URL.
        if (Session::is_admin()) {
            $data['admin'] = !is_null(myGet('admin')) ? 1 : 0;
        }

        ModelUtilisateur::update($data);

        $tab_u      = ModelUtilisateur::selectAll();
        $view       = 'updated';
        $pagetitle  = 'Utilisateur mis à jour';
        require File::build_path(array('view', 'view.php'));
    }

    // Action delete : supprime l'utilisateur puis affiche la liste.
    // Attention : grâce aux clés étrangères ON DELETE CASCADE (TD3), ses trajets
    // de conducteur et ses inscriptions comme passager sont aussi supprimés.
    public static function delete()
    {
        if (is_null(myGet('login'))) {
            self::error();
            return;
        }
        $login = myGet('login');

        // TD8 ex.10 : on ne peut supprimer que SA PROPRE fiche (ou être admin).
        if (!Session::is_user($login) && !Session::is_admin()) {
            header('Location: index.php?controller=utilisateur&action=connect');
            exit();
        }

        ModelUtilisateur::delete($login);
        $tab_u      = ModelUtilisateur::selectAll();
        $view       = 'deleted';
        $pagetitle  = "Suppression d'un utilisateur";
        require File::build_path(array('view', 'view.php'));
    }

    // Action readTrajets : affiche les trajets dont l'utilisateur est passager.
    public static function readTrajets()
    {
        $login = !is_null(myGet('login')) ? myGet('login') : null;
        $u     = ModelUtilisateur::select($login);

        if ($u === false) {
            $message    = "Aucun utilisateur ne correspond au login " . $login . '.';
            $view       = 'error';
            $pagetitle  = 'Erreur';
        } else {
            $tab_t      = ModelUtilisateur::getTrajets($login);
            $view       = 'trajets';
            $pagetitle  = "Trajets de l'utilisateur";
        }
        require File::build_path(array('view', 'view.php'));
    }

    // TD8 ex.5 : affiche le formulaire de connexion.
    public static function connect()
    {
        $view       = 'connect';
        $pagetitle  = 'Connexion';
        require File::build_path(array('view', 'view.php'));
    }

    // TD8 ex.5 : traite le formulaire de connexion.
    // Le mot de passe (POST) est haché puis comparé en base avec checkPassword().
    public static function connected()
    {
        $login = !is_null(myGet('login')) ? myGet('login') : null;
        $mdp   = !is_null(myGet('mdp'))   ? myGet('mdp')   : null;

        if (is_null($login) || is_null($mdp)) {
            self::error();
            return;
        }

        // On ne compare jamais le mot de passe en clair : on hache d'abord.
        $mdp_chiffre = Security::chiffrer($mdp);

        if (ModelUtilisateur::checkPassword($login, $mdp_chiffre)) {
            // TD8 ex.14 : on refuse la connexion tant que le compte n'est pas validé
            // (nonce non NULL en base).
            $u = ModelUtilisateur::select($login);
            if ($u !== false && !is_null($u->getNonce())) {
                $message    = "Votre compte n'est pas encore validé. Cliquez sur le lien reçu par email.";
                $view       = 'error';
                $pagetitle  = 'Compte non validé';
                require File::build_path(array('view', 'view.php'));
                return;
            }

            // Connexion réussie : on mémorise le login dans la session.
            $_SESSION['login'] = $login;

            $u          = ModelUtilisateur::select($login);
            // TD8 ex.11 : on mémorise aussi le statut administrateur en session.
            $_SESSION['admin'] = (bool)$u->getAdmin();

            $view       = 'detail';
            $pagetitle  = "Détail de l'utilisateur";
        } else {
            $message    = "Login ou mot de passe incorrect.";
            $view       = 'error';
            $pagetitle  = 'Erreur';
        }
        require File::build_path(array('view', 'view.php'));
    }

    // TD8 ex.6 : déconnexion. On détruit la session puis on revient à l'accueil.
    public static function deconnect()
    {
        session_unset();    // vide le tableau $_SESSION
        session_destroy();  // supprime la session côté serveur
        header('Location: index.php');
        exit();
    }

    // Action error : affiche la vue d'erreur.
    public static function error()
    {
        $message    = "Cette action n'existe pas.";
        $view       = 'error';
        $pagetitle  = 'Erreur';
        require File::build_path(array('view', 'view.php'));
    }
}
