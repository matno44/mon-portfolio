<?php

// TD8 ex.15 : récupère une variable transmise par l'URL (GET), sinon par le
// corps de la requête (POST), sinon NULL. On évite ainsi de dépendre de la
// méthode du formulaire (GET en debug, POST en production, cf. vues create/update).
function myGet($nomvar)
{
    if (isset($_GET[$nomvar])) {
        return $_GET[$nomvar];
    }
    if (isset($_POST[$nomvar])) {
        return $_POST[$nomvar];
    }
    return null;
}

require_once File::build_path(array('controller', 'ControllerVoiture.php'));
require_once File::build_path(array('controller', 'ControllerUtilisateur.php'));
require_once File::build_path(array('controller', 'ControllerTrajet.php'));
require_once File::build_path(array('controller', 'ControllerPanier.php'));

// On récupère l'action passée dans l'URL (query string).
// Sans paramètre, on affiche la liste par défaut.
$action = !is_null(myGet('action')) ? myGet('action') : 'readAll';

// TD7 - Exercice 3 : contrôleur par défaut personnalisable par cookie.
// i. voiture par défaut
$controller_default = 'voiture';
// iii. si le cookie preference existe et contient une valeur autorisée,
//      il remplace le contrôleur par défaut
if (isset($_COOKIE['preference']) && in_array($_COOKIE['preference'], array('voiture', 'trajet', 'utilisateur'))) {
    $controller_default = $_COOKIE['preference'];
}

// ii. On récupère le contrôleur passé dans l'URL, $controller_default sinon.
$controller = !is_null(myGet('controller')) ? myGet('controller') : $controller_default;

// Nom de la classe du contrôleur : 'voiture' => 'ControllerVoiture'
$controller_class = 'Controller' . ucfirst($controller);

// On vérifie que la classe du contrôleur existe
// puis que $action est bien une méthode de ce contrôleur.
if (class_exists($controller_class) && in_array($action, get_class_methods($controller_class))) {
    $controller_class::$action();
} else {
    ControllerVoiture::error();
}
