<?php
// TD7 - Exercice 3 : enregistre la page d'accueil préférée dans un cookie

// Valeurs autorisées (= contrôleurs existants du site)
$preferences_autorisees = array('voiture', 'trajet', 'utilisateur');

// On récupère la valeur envoyée par le formulaire preference.html
if (isset($_GET['preference']) && in_array($_GET['preference'], $preferences_autorisees)) {
    // On dépose la valeur dans un cookie du même nom, valable 30 jours.
    // setcookie() est appelé avant toute sortie HTML (en-tête HTTP).
    setcookie('preference', $_GET['preference'], time() + 30 * 24 * 3600);
}

// Retour à la page d'accueil du site (le routeur lira le cookie)
header('Location: index.php');
exit();
