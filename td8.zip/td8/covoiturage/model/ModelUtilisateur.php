<?php

require_once File::build_path(array('model', 'Model.php'));

class ModelUtilisateur extends Model
{
    private $login;
    private $nom;
    private $prenom;
    private $mdp;     // TD8 ex.1 : mot de passe (clair ex.1, puis haché SHA-256 ex.2)
    private $admin;   // TD8 ex.11 : 1 si l'utilisateur est administrateur, 0 sinon
    private $email;   // TD8 ex.13 : adresse email de l'utilisateur
    private $nonce;   // TD8 ex.14 : nonce de validation (NULL = compte validé)
    protected static $object  = 'utilisateur';
    protected static $primary = 'login';

    // un constructeur
    // Avec PDO::FETCH_CLASS, PDO remplit les attributs AVANT d'appeler le
    // constructeur (sans paramètres) : il ne faut donc pas les écraser par null.
    public function __construct($l = NULL, $n = NULL, $p = NULL)
    {
        if (!is_null($l) && !is_null($n) && !is_null($p)) {
            $this->login  = $l;
            $this->nom    = $n;
            $this->prenom = $p;
        }
    }

    // un getter
    public function getLogin()
    {
        return $this->login;
    }

    public function setLogin($login2)
    {
        $this->login = $login2;
    }

    public function getNom()
    {
        return $this->nom;
    }

    public function setNom($nom2)
    {
        $this->nom = $nom2;
    }

    public function getPrenom()
    {
        return $this->prenom;
    }

    public function setPrenom($prenom2)
    {
        $this->prenom = $prenom2;
    }

    // TD8 ex.1 : getter / setter du mot de passe
    public function getMdp()
    {
        return $this->mdp;
    }

    public function setMdp($mdp2)
    {
        $this->mdp = $mdp2;
    }

    // TD8 ex.11 : getter / setter du statut administrateur
    public function getAdmin()
    {
        return $this->admin;
    }

    public function setAdmin($admin2)
    {
        $this->admin = $admin2;
    }

    // TD8 ex.13 : getter / setter de l'email
    public function getEmail()
    {
        return $this->email;
    }

    public function setEmail($email2)
    {
        $this->email = $email2;
    }

    // TD8 ex.14 : getter / setter du nonce de validation
    public function getNonce()
    {
        return $this->nonce;
    }

    public function setNonce($nonce2)
    {
        $this->nonce = $nonce2;
    }

    // La méthode statique pour récupérer tous les utilisateurs en BDD
    // est maintenant selectAll(), héritée de Model.

    // TD8 ex.5 : vérifie qu'il existe exactement un utilisateur dont le login
    // et le mot de passe haché correspondent. Renvoie true si c'est le cas.
    // $mdp_chiffre est déjà haché par Security::chiffrer() dans le contrôleur :
    // on ne manipule jamais le mot de passe en clair ici.
    public static function checkPassword($login, $mdp_chiffre)
    {
        try {
            $sql      = 'SELECT COUNT(*) AS nb FROM utilisateur '
                . 'WHERE login = :login AND mdp = :mdp';
            $req_prep = Model::$pdo->prepare($sql);
            $req_prep->execute(array(
                'login' => $login,
                'mdp'   => $mdp_chiffre,
            ));
            $ligne = $req_prep->fetch(PDO::FETCH_ASSOC);

            // true seulement s'il y a exactement un couple (login, mot de passe)
            return ((int)$ligne['nb'] === 1);
        } catch (PDOException $e) {
            if (Conf::getDebug()) {
                echo $e->getMessage();
            }
            return false;
        }
    }

    // Méthode statique qui renvoie les trajets (objets ModelTrajet) dont
    // l'utilisateur de login $login est passager (table de jointure passager, TD3).
    public static function getTrajets($login)
    {
        try {
            $sql      = 'SELECT t.* FROM trajet t '
                . 'JOIN passager p ON p.trajet_id = t.id '
                . 'WHERE p.utilisateur_login = :login_tag';
            // Préparation de la requête
            $req_prep = Model::$pdo->prepare($sql);
            $values   = array(
                'login_tag' => $login,
            );
            $req_prep->execute($values);
            $req_prep->setFetchMode(PDO::FETCH_CLASS, 'ModelTrajet');

            return $req_prep->fetchAll();
        } catch (PDOException $e) {
            if (Conf::getDebug()) {
                echo $e->getMessage();
            } else {
                echo 'Une erreur est survenue lors de la lecture des trajets.';
            }

            return array();
        }
    }
}
