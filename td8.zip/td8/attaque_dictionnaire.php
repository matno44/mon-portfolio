<?php
// =====================================================================
// TD8 - Exercice 3 : attaque par dictionnaire sur un haché SHA-256
// ---------------------------------------------------------------------
// Principe : un SHA-256 « simple » (sans graine) est toujours le même
// pour un mot de passe donné. L'attaquant n'a donc qu'à hacher une liste
// de mots de passe courants et à comparer chaque haché à celui volé en
// base. C'est exactement ce que font les sites de recherche de hachés
// (md5decrypt, crackstation...) avec d'immenses dictionnaires.
//
// Usage : php attaque_dictionnaire.php [haché]
// Sans argument, on attaque le haché du compte de test « victime ».
// =====================================================================

// Haché volé en base (compte « victime », mot de passe réel = "password").
$hache_cible = isset($argv[1])
    ? $argv[1]
    : '5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8';

// Petit dictionnaire de mots de passe parmi les plus utilisés au monde.
$dictionnaire = array(
    '123456', '123456789', 'qwerty', 'azerty', 'motdepasse',
    'admin', 'root', 'soleil', 'iloveyou', 'bonjour',
    'password', 'password1', 'P@ssw0rd', '000000', 'abc123',
);

echo "Haché cible   : $hache_cible\n";
echo "Dictionnaire  : " . count($dictionnaire) . " mots de passe à tester\n";
echo str_repeat('-', 60) . "\n";

$trouve = null;
foreach ($dictionnaire as $mot) {
    $h = hash('sha256', $mot);          // même calcul que Security::chiffrer() (ex.2)
    $egal = ($h === $hache_cible) ? '  <<< TROUVÉ' : '';
    echo str_pad($mot, 14) . ' -> ' . $h . $egal . "\n";
    if ($h === $hache_cible) {
        $trouve = $mot;
        break;
    }
}

echo str_repeat('-', 60) . "\n";
if ($trouve !== null) {
    echo "Mot de passe retrouvé : \"$trouve\"\n";
} else {
    echo "Mot de passe non trouvé dans ce dictionnaire.\n";
}
