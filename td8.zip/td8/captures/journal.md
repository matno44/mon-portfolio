# Journal des captures – TD8 Authentification & validation par email

Environnement : site du TD7 copié dans `td8/covoiturage/`, servi par le serveur intégré du PHP de XAMPP (`/Applications/XAMPP/xamppfiles/bin/php -S localhost:8000 -t td8`, PHP 8.0.28), base MySQL `garage` de XAMPP. Serveur lancé avec `sendmail_path` redirigé vers Mailpit pour la partie 3 (aucun vrai mail envoyé).

Captures navigateur : Playwright + Chromium, fenêtre 1280x800, PNG.
Captures de code : page HTML générée avec highlight.js 11.9.0 (thème GitHub clair), capturée avec Playwright.
Captures de base : résultat d'un SELECT rendu dans une page HTML simple, capturé avec Playwright.

Modifications de la base enregistrées dans `td8/sql/modifications_td8.sql`.

---

## Partie 1 – Authentification par mot de passe

### Exercice 1 – Mot de passe saisi deux fois (en clair)

Ajout de la colonne `mdp VARCHAR(64)` à la table `utilisateur`. Deux champs `password` (`mdp`, `mdp2`) ajoutés au formulaire `view/utilisateur/update.php` (commun création/mise à jour). Les actions `save` et `updated` de `ControllerUtilisateur` vérifient que les deux champs coïncident avant d'enregistrer.

| Capture | Étape | Ce qu'elle montre | Résultat |
|---|---|---|---|
| ex01_code_save.png | code | `save()` : test `$_GET['mdp'] !== $_GET['mdp2']` puis ajout de `mdp` au tableau `$data`. | – |
| ex01_formulaire_creation.png | formulaire | Formulaire de création avec les deux champs « Mot de passe » et « Confirmation » (type password). | – |
| ex01_mdp_differents.png | test KO | Envoi avec deux mots de passe différents. | Page d'erreur « Les deux mots de passe ne coïncident pas. » : rien n'est enregistré. |
| ex01_mdp_clair_base.png | base | `SELECT login,nom,prenom,mdp` après création de `testc` / `secret123`. | Le mot de passe est stocké **en clair** (`secret123`) : lisible par quiconque accède à la base. |

### Exercice 2 – Hachage SHA-256 (classe Security)

Création de `lib/Security.php` avec `Security::chiffrer()` (SHA-256). `ControllerUtilisateur` inclut la classe et enregistre `Security::chiffrer($_GET['mdp'])` au lieu du mot de passe en clair.

| Capture | Étape | Ce qu'elle montre | Résultat |
|---|---|---|---|
| ex02_code_security.php → ex02_code_security.png | code | Méthode `chiffrer()` : `return hash('sha256', $chaine);`. | – |
| ex02_code_controller.png | code | Appel `'mdp' => Security::chiffrer($_GET['mdp'])` dans `save()`. | – |
| ex02_mdp_hache_base.png | base | `SELECT login,prenom,mdp` des comptes `hache` et `victime`. | Les mots de passe sont stockés **hachés** (64 caractères hexadécimaux), illisibles. `victime` a pour mot de passe réel « password ». |

### Exercice 3 – Attaque par dictionnaire

Le compte de test `victime` a le mot de passe « password ». Son haché SHA-256 brut (`5e884898…1542d8`) est universel : les sites de crack le retrouvent instantanément.

| Capture | Étape | Ce qu'elle montre | Résultat |
|---|---|---|---|
| ex03_crackstation_captcha.png | site en ligne | Haché collé dans CrackStation (crackstation.net). | Le bouton « Crack Hashes » est bloqué par un **reCAPTCHA** : l'automatisation Playwright ne peut pas valider le formulaire. On bascule donc sur le script local, comme prévu par le sujet. |
| ex03_code_attaque.png | code | `td8/attaque_dictionnaire.php` : boucle qui hache une liste de mots de passe courants et compare au haché volé. | – |
| ex03_attaque_resultat.png | résultat | Exécution du script sur le haché de `victime`. | Dès le mot « password », le haché calculé est identique au haché cible : **mot de passe retrouvé « password »**. Un SHA-256 simple ne protège donc pas un mot de passe faible. |

### Exercice 4 – Graine privée (sel)

Ajout de `static $seed` (20 caractères) et `getSeed()` dans `Security` ; `chiffrer()` concatène la graine avant de hacher.

| Capture | Étape | Ce qu'elle montre | Résultat |
|---|---|---|---|
| ex04_code_seed.png | code | `Security` avec la graine et `hash('sha256', self::getSeed() . $chaine)`. | – |
| ex04_hache_different.png | comparaison | Haché de « password » sans graine (rouge) vs avec graine (vert). | Le même mot de passe donne un haché **totalement différent** du SHA-256 brut. |
| ex04_attaque_echec.png | résultat | Attaque par dictionnaire relancée sur le nouveau haché (`254aac…`). | **Mot de passe non trouvé** : les dictionnaires de hachés pré-calculés ne correspondent plus. |

---

## Partie 2 – Sécurisation avec les sessions

Comptes de test utilisés : `matk` / `matk2024` (non admin), `admin1` / `admin2024` (administrateur).

### Exercice 5 – Connexion (vue connect, checkPassword, action connected)

Vue `view/utilisateur/connect.php` (POST, login + mot de passe). `ModelUtilisateur::checkPassword()` compte en requête préparée les couples (login, mdp haché). `connected()` hache le mot de passe reçu, vérifie, met le login en session et affiche la fiche. La session est démarrée dans `index.php` (déjà fait au TD7).

| Capture | Étape | Ce qu'elle montre | Résultat |
|---|---|---|---|
| ex05_code_checkpassword.png | code | `checkPassword()` : `SELECT COUNT(*) ... WHERE login=:login AND mdp=:mdp`, true si exactement 1. | – |
| ex05_code_connected.png | code | `connected()` : hachage, `checkPassword`, `$_SESSION['login']`, vue detail. | – |
| ex05_vue_connect.png | formulaire | Le formulaire de connexion (login + mot de passe en type password). | – |
| ex07_connexion_correcte.png | résultat | Connexion de `matk` avec le bon mot de passe. | Fiche de `matk` affichée, en-tête « Bonjour matk / Déconnexion ». |

### Exercice 6 – Déconnexion

`deconnect()` : `session_unset()` + `session_destroy()` puis redirection vers l'accueil.

| Capture | Étape | Ce qu'elle montre | Résultat |
|---|---|---|---|
| ex06_code_deconnect.png | code | La méthode `deconnect()`. | – |
| ex07_deconnexion.png | résultat | Accueil après clic sur « Déconnexion ». | L'en-tête repasse à « Connexion » : la session est bien détruite. |

### Exercice 7 – Lien Connexion / Déconnexion dans l'en-tête

`view/view.php` : si `$_SESSION['login']` existe, message de bienvenue + lien Déconnexion ; sinon lien Connexion.

| Capture | Étape | Ce qu'elle montre | Résultat |
|---|---|---|---|
| ex07_code_nav.png | code | Le bloc `if (isset($_SESSION['login']))` du menu. | – |
| ex07_connexion_correcte.png | connecté | (voir ex.5) en-tête « Bonjour matk / Déconnexion ». | – |
| ex07_connexion_incorrecte.png | KO | Connexion de `matk` avec un mauvais mot de passe. | Page d'erreur « Login ou mot de passe incorrect. ». |
| ex07_deconnexion.png | déconnecté | En-tête « Connexion ». | – |

### Exercice 8 – Session::is_user() et liens réservés

`lib/Session.php` (inclus après `session_start()` dans `index.php`). La fiche `detail.php` n'affiche « modifier » / « supprimer » que pour l'utilisateur connecté (ou un admin, ex.11).

| Capture | Étape | Ce qu'elle montre | Résultat |
|---|---|---|---|
| ex08_code_session.png | code | `Session::is_user()` et `is_admin()`. | – |
| ex08_code_detail.png | code | Le `if (Session::is_user(...) \|\| Session::is_admin())` de detail.php. | – |
| ex08_fiche_soi_liens.png | soi | `matk` connecté sur sa propre fiche. | Les liens « Mettre à jour » et « Supprimer » sont présents. |
| ex08_fiche_autre_sans_liens.png | autre | `matk` connecté sur la fiche d'`alid`. | Les liens sont absents : on ne voit que « Voir ses trajets ». |

### Exercice 9 – Hack de l'action update par l'URL

| Capture | Étape | Ce qu'elle montre | Résultat |
|---|---|---|---|
| ex09_hack_update_url.png | hack | `matk` tape `action=update&login=alid` dans l'URL (bandeau rouge). | **Faille** : le formulaire de mise à jour d'`alid` s'affiche, pré-rempli. |
| ex09_code_fix.png | code | Ajout dans `update()` : `if (!Session::is_user($login) && !Session::is_admin())` → redirection vers `connect`. | – |
| ex09_hack_corrige.png | corrigé | Même URL forgée après correction (bandeau vert). | Redirection automatique vers le formulaire de connexion : la faille est fermée. |

### Exercice 10 – Hack de l'action updated (formulaire en GET) + delete

Le formulaire de mise à jour est en GET : les données passent par l'URL. Un attaquant peut donc forger directement `action=updated&...`.

| Capture | Étape | Ce qu'elle montre | Résultat |
|---|---|---|---|
| ex10_hack_updated_url.png | hack | `matk` force `action=updated&login=alid&nom=PIRATE&prenom=hacked` (bandeau rouge). | **Faille** : « L'utilisateur alid a bien été mis à jour. » ; en base, `alid` devient PIRATE/hacked (restauré ensuite). |
| ex10_code_fix.png | code | Même contrôle d'accès ajouté dans `updated()` ET `delete()`. | – |
| ex10_hack_corrige.png | corrigé | URL forgée après correction (bandeau vert). | Redirection vers `connect` ; `alid` reste intact. Vérifié aussi pour `delete`. |

### Exercice 11 – Administrateur

Colonne `admin BOOLEAN`. `connected()` enregistre `$_SESSION['admin']`. `Session::is_admin()`. Un admin passe tous les contrôles d'accès des ex.8/9/10.

| Capture | Étape | Ce qu'elle montre | Résultat |
|---|---|---|---|
| ex11_code_connected_admin.png | code | `$_SESSION['admin'] = (bool)$u->getAdmin();`. | – |
| ex11_admin_fiche_autre.png | résultat | `admin1` connecté sur la fiche d'`alid`. | Les liens « Mettre à jour » / « Supprimer » sont présents **même sur la fiche d'un autre** : l'admin a tous les droits. |

### Exercice 12 – Case « Administrateur ? » réservée aux admins

Case à cocher visible seulement si `Session::is_admin()`. `updated()` ne modifie le champ `admin` que si l'auteur est admin (vérification côté serveur).

| Capture | Étape | Ce qu'elle montre | Résultat |
|---|---|---|---|
| ex12_code_vue.png | code | La case affichée sous condition `Session::is_admin()`. | – |
| ex12_code_controller.png | code | `if (Session::is_admin()) { $data['admin'] = isset($_GET['admin']) ? 1 : 0; }`. | – |
| ex12_formulaire_admin.png | admin | Formulaire de mise à jour d'`alid` vu par `admin1`. | La case « Administrateur ? » est présente. |
| ex12_formulaire_non_admin.png | non-admin | Formulaire de `matk` vu par `matk`. | La case est absente. |
| ex12_promotion.png | promotion | `admin1` coche la case et valide sur `alid`. | `alid` passe `admin=1` en base. Test complémentaire : `matk` forgeant `&admin=1` reste `admin=0` (contrôle serveur). |

---

## Partie 3 – Validation par email

### Exercice 13 – Champ email (contrôle client + serveur)

Colonne `email VARCHAR(128)`. Champ `type="email"` ajouté au formulaire de création. Le contrôle HTML est doublé côté serveur par `filter_var(..., FILTER_VALIDATE_EMAIL)` dans `save()`.

| Capture | Étape | Ce qu'elle montre | Résultat |
|---|---|---|---|
| ex13_validation_navigateur.png | contrôle client | Saisie de « pasunemail » dans le champ email. | Le navigateur bloque l'envoi : « Veuillez inclure "@" dans l'adresse e-mail… ». |
| ex13_hack_contournement.png | hack | Attribut `type="email"` retiré via les outils du navigateur, puis envoi (bandeau rouge). | **Faille** : « L'utilisateur a bien été créé », email invalide « pasunemail » stocké en base. |
| ex13_code_filtervar.png | code | Ajout de `if (!filter_var($_GET['email'], FILTER_VALIDATE_EMAIL))` dans `save()`. | – |
| ex13_refus_serveur.png | corrigé | Même hack après ajout de `filter_var` (bandeau vert). | Page d'erreur « L'adresse email « pasunemail » n'est pas valide. » : rien n'est enregistré. |

### Exercice 14 – Nonce et validation par email (Mailpit)

Colonne `nonce VARCHAR(32)`. `Security::generateRandomHex()`. À la création, un nonce est généré et un mail HTML de validation est envoyé avec `mail()` (redirigé vers **Mailpit** en local, aucun vrai envoi). La connexion est refusée tant que le nonce n'est pas NULL. L'action `validate` (login + nonce en GET) passe le nonce à NULL.

Adresses `@yopmail.com` comme demandé par le sujet. Compte de démonstration : `demo14` / `lea2024` (email lea@yopmail.com).

| Capture | Étape | Ce qu'elle montre | Résultat |
|---|---|---|---|
| ex14_code_randomhex.png | code | `generateRandomHex()` avec `random_bytes` + `bin2hex`. | – |
| ex14_code_mail.png | code | Construction du lien de validation et envoi HTML via `mail()`. | – |
| ex14_code_refus.png | code | `connected()` : refus si `!is_null($u->getNonce())`. | – |
| ex14_code_validate.png | code | `validate()` : passe le nonce à NULL si (login, nonce) correspond. | – |
| ex14_inscription.png | 1. inscription | Création de `demo14` avec un email yopmail valide. | « L'utilisateur a bien été créé » ; en base, un nonce est généré. |
| ex14_connexion_refusee.png | 2. refus | Tentative de connexion de `demo14` avant validation. | « Votre compte n'est pas encore validé. Cliquez sur le lien reçu par email. » |
| ex14_mail_recu.png | 3. mail | Interface Mailpit (localhost:8025), mail « Validation de votre compte covoiturage ». | Mail HTML reçu avec le lien « Valider mon compte » et l'URL complète (login + nonce). |
| ex14_validation.png | 4. validation | Clic sur le lien de validation. | « Votre compte « demo14 » est maintenant validé. » ; en base, nonce = NULL. |
| ex14_connexion_acceptee.png | 5. connexion | Connexion de `demo14` après validation. | Connexion acceptée : fiche de l'utilisateur, en-tête « Bonjour demo14 ». |

---

## Partie 4 – Autres sécurisations

### Exercice 15 – myGet() et méthode des formulaires selon le mode

Fonction `myGet($nomvar)` dans `routeur.php` : renvoie `$_GET`, sinon `$_POST`, sinon NULL. Tous les `$_GET` de `routeur.php`, `ControllerUtilisateur.php` et `ControllerTrajet.php` sont remplacés par `myGet`, et les `isset($_GET[...])` par `!is_null(myGet(...))`. Les formulaires create/update sont en POST si `Conf::getDebug()` vaut false, en GET sinon (le formulaire de mise à jour retrouve ainsi une méthode « normale » après l'ex.10).

L'onglet Réseau des DevTools n'a pas pu être capturé avec Chrome visible + `screencapture` (permission « Enregistrement de l'écran » non accordée dans l'environnement automatisé). Comme prévu par le sujet, les données POST interceptées par Playwright sont affichées dans une page de debug imitant l'onglet « Charge utile » des DevTools.

| Capture | Étape | Ce qu'elle montre | Résultat |
|---|---|---|---|
| ex15_code_myget.png | code | La fonction `myGet()`. | – |
| ex15_code_usage.png | code | Exemples de remplacement des `$_GET` par `myGet()`. | – |
| ex15_code_form_method.png | code | `method="<?php echo Conf::getDebug() ? 'get' : 'post'; ?>"`. | – |
| ex15_debug_mdp_url.png | mode debug | Création d'un utilisateur, `Conf::getDebug()` = true (formulaire GET). | L'URL contient `...&mdp=secret123&mdp2=secret123` : **le mot de passe est visible dans l'URL** (et donc dans l'historique, les logs…). |
| ex15_prod_url_sans_mdp.png | mode production | Même création, `Conf::getDebug()` = false (formulaire POST). | L'URL se réduit à `index.php` : **le mot de passe n'apparaît plus dans l'URL**. |
| ex15_prod_reseau_mdp.png | mode production | Charge utile de la requête POST (données interceptées par Playwright). | Le mot de passe `secret123` circule malgré tout **en clair dans le corps de la requête** (champs `mdp`/`mdp2` surlignés) : seul HTTPS le chiffrerait pendant le transport. |
