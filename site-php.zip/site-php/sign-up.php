<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

if (isset($_POST['email'])) {
    require 'fonctions.php';

    // 1. On initialise la connexion BDD en premier !
    $bdd = getBdd();

    $login    = $_POST['email'];
    $reqLogin = 'SELECT * FROM utilis WHERE LoginUtil = ?';
    $resLogin = $bdd->prepare($reqLogin);
    $resLogin->execute(array($login));
    $utilisateur = $resLogin->fetch();

    // 2. On vérifie d'abord si l'utilisateur existe (fetch retourne false s'il ne trouve rien)
    if ($utilisateur) {
        $message = "L'email existe déjà. Veuillez vous connecter.";
    }
    // 3. On s'assure que le champ confirm_mdp existe avant de le comparer
    else if (!isset($_POST['confirm_mdp']) || $_POST['mdp'] !== $_POST['confirm_mdp']) {
        $message = 'Les mots de passe ne correspondent pas.';
    } else {
        try {
            // 4. On prépare la requête d'insertion
            $stmt = $bdd->prepare('INSERT INTO utilis (NomUtil, PrenomUtil, LoginUtil, PassUtil)
             VALUES (:nom, :pre, :login, :pass)');

            // Hachage du mot de passe pour la sécurité
            $mdp_hache = password_hash($_POST['mdp'], PASSWORD_DEFAULT);

            $stmt->execute([
                               ':nom'   => $_POST['nom'],
                               ':pre'   => $_POST['prenom'],
                               ':login' => $_POST['email'],
                               ':pass'  => $mdp_hache  // On insère le mot de passe haché
                           ]);

            $message = "L'ajout a réussi !";

            // REDIRECTION AUTOMATIQUE
            header('Location: index.php');
            exit();
        } catch (Exception $erreur) {
            $message = 'Erreur : ' . $erreur->getMessage();
        }
    }
}
?>
<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Création compte</title>
    <link rel="stylesheet" type="text/css" href="css/login_styles.css">
</head>
<body>
    <header>
        <img src="images/DA site/logo.png" alt="logo">
        <h1>Stream Verse meilleur site de streaming.</h1>
    </header>
    <form action="sign-up.php" method="post"> 
        <label><h1>Création utilisateur</h1></label>
       
        <label for="nom">Nom : </label>
        <input type="text" name="nom" id="nom" required /><br>
        
        <label for="prenom">Prénom : </label>
        <input type="text" name="prenom" id="prenom" required /><br>
        
        <label for="email">Email : </label>
        <input type="email" name="email" id="email" required /><br>

        <label for="mdp">Mot de passe : </label>
        <input type="password" name="mdp" id="mdp" required /><br>

        <label for="confirm_mdp">Confirmer le mot de passe : </label>
        <input type="password" name="confirm_mdp" id="confirm_mdp" required /><br>

        <input type="submit" value="S'inscrire">
        
        <?php if (isset($message)): ?>
        <p style="color: red;"><?php echo $message; ?></p>
        <?php endif; ?>
        <input type="submit" value="se connecter" onclick="window.location.href='login.php'; return false;">
        
    </form>
    
</body>
</html>