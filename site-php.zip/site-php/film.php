<?php
session_start();
require 'fonctions.php';  // Inclus une seule fois ici, c'est suffisant pour tout le fichier

// 1. Connexion à la BDD
$bdd = getBdd();

// 2. On récupère l'ID passé dans l'URL (et on s'assure que c'est bien un nombre entier)
$id_film = isset($_GET['id']) ? (int) $_GET['id'] : 0;

// 3. On prépare la requête SQL
$req = $bdd->prepare('SELECT * FROM films WHERE id_film = ?');
$req->execute(array($id_film));

// 4. On récupère les données du film
$filmActuel = $req->fetch();

// 5. On vérifie si le film a été trouvé dans la BDD
if (!$filmActuel) {
    die("<h1>Erreur : Ce film n'existe pas.</h1><a href='index.php'>Retour à l'accueil</a>");
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title><?= htmlspecialchars($filmActuel['titre']) ?> - Stream Verse</title>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
    <aside>
        <nav>
            <ul>
                <ol>
                <?php
                if (isset($_SESSION['prenom'])) {
                    // require 'fonctions.php'; <- Supprimé car déjà présent à la ligne 3
                    echo 'session de : ' . escape($_SESSION['prenom']);
                }
                ?>
                </ol>
                <ol><a href="index.php"> 🏠Home</a></ol>
            </ul>
        </nav>
    </aside>

    <main class="page-details-film">
        <div class="film-container">
            <div class="film-affiche">
                <img src="<?= htmlspecialchars($filmActuel['image_path']) ?>" alt="Affiche de <?= htmlspecialchars($filmActuel['titre']) ?>">
            </div>
            
            <div class="film-infos">
                <h2><?= htmlspecialchars($filmActuel['titre']) ?></h2>
                <p><strong>Réalisateur :</strong> <?= htmlspecialchars($filmActuel['realisateur']) ?></p>
                <p><strong>Acteurs principaux :</strong> <?= htmlspecialchars($filmActuel['acteurs']) ?></p>
                <p><strong>Genre :</strong> <?= htmlspecialchars($filmActuel['genre']) ?></p>
                <p><strong>Date de sortie :</strong> <?= htmlspecialchars($filmActuel['annee_sortie']) ?></p>
                
                <div class="synopsis">
                    <h3>Synopsis</h3>
                    <p><?= htmlspecialchars($filmActuel['description']) ?></p>
                </div>
                
                <a href="#" class="btn-lecture">▶ Lancer le film</a>
            </div>
        </div>
    </main>
</body>
</html>