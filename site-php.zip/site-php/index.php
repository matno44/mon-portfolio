<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>
<?php
session_start();  // INDISPENSABLE en haut du fichier
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Stream Verse</title>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <header>
        <img src="images/DA site/logo.png" alt="logo">
        <h1>Stream Verse meilleur site de streaming.</h1>
    </header>
    <aside>
        <nav>
            <ul>
                <ol><?php
// On vérifie si la session contient bien le prénom
if (isset($_SESSION['prenom'])) {
    require_once 'fonctions.php';  // Pour utiliser la fonction escape
    echo 'session de : ' . escape($_SESSION['prenom']) . '';
}
?></ol>
                <ol><a href="index.php"> 🏠Home</a></ol>
                <li><a href="#MCU">MCU</a></li>
                <li><a href="#Star Wars">Star Wars</a></li>
                <li><a href="login.php">deconexion</a></li>
            </ul>
        </nav>
    </aside>
    <main>
        <article>
            <div class="article-1">
                <h1 id="MCU"><span class="N">l'</span>univers du MCU</h1>
                <section class="films_mcu">
                    <div class="card-mcu-1">
                        <div class="banniere">
                            <span class="films">Captain america</span>
                            <span class="prix">free</span>
                            <a href="film.php?id=1" class="plus">en savoir plus</a>
                        </div>
                    </div>
                    <div class="card-mcu-2">
                        <div class="banniere">
                            <span class="films">Iron man</span>
                            <span class="prix">free</span>
                            <a href="film.php?id=2" class="plus">en savoir plus</a>
                        </div>
                    </div>
                    <div class="card-mcu-3">
                        <div class="banniere">
                            <span class="films">Avengers Endgame</span>
                            <span class="prix">prenium</span>
                            <a href="film.php?id=3" class="plus">en savoir plus</a>
                        </div>
                    </div>
                </section>
            </div>
            
            <div class="article-2">
                <h1 id="Star Wars">la saga star wars</h1>
                <section class="films_sw">
                    <div class="card-sw-1">
                        <div class="banniere">
                            <span class="films">la menace fantome</span>
                            <span class="prix">free</span>
                            <a href="film.php?id=4" class="plus">en savoir plus</a>
                        </div>
                    </div>
                    <div class="card-sw-2">
                        <div class="banniere">
                            <span class="films">l'attaque des clones</span>
                            <span class="prix">free</span>
                            <a href="film.php?id=5" class="plus">en savoir plus</a>
                        </div>
                    </div>
                    <div class="card-sw-3">
                        <div class="banniere">
                            <span class="films">la revanche des sith</span>
                            <span class="prix">prenium</span>
                            <a href="film.php?id=6" class="plus">en savoir plus</a>
                        </div>
                    </div>
                </section>
            </div>
        </article>
    </main>
    <footer>
        &copy;2025 Stream Verse <span>condition general de ventes</span>
</footer>
</body>

</html>