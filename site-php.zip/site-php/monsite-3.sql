-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : lun. 18 mai 2026 à 16:49
-- Version du serveur : 10.4.28-MariaDB
-- Version de PHP : 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `monsite`
--

-- --------------------------------------------------------

--
-- Structure de la table `films`
--

CREATE TABLE `films` (
  `id_film` int(11) NOT NULL,
  `titre` varchar(150) NOT NULL,
  `realisateur` varchar(100) NOT NULL,
  `acteurs` varchar(255) NOT NULL,
  `genre` varchar(100) NOT NULL,
  `annee_sortie` varchar(4) NOT NULL,
  `description` text NOT NULL,
  `image_path` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `films`
--

INSERT INTO `films` (`id_film`, `titre`, `realisateur`, `acteurs`, `genre`, `annee_sortie`, `description`, `image_path`) VALUES
(1, 'Captain America: First Avenger', 'Joe Johnston', 'Chris Evans, Tommy Lee Jones, Hugo Weaving', 'Action, Aventure, Science-Fiction', '2011', 'Steve Rogers, un jeune homme frêle, se porte volontaire pour participer à un programme expérimental qui va le transformer en un Super-Soldat connu sous le nom de Captain America.', 'images/film mcu/captain america firs avanger.jpg'),
(2, 'Iron Man', 'Jon Favreau', 'Robert Downey Jr., Terrence Howard, Jeff Bridges', 'Action, Science-Fiction', '2008', 'Tony Stark, inventeur de génie et milliardaire, est kidnappé. Il construit une armure high-tech pour s\'échapper et décide de l\'utiliser pour protéger le monde.', 'images/film mcu/iron man 1.webp'),
(3, 'Avengers: Endgame', 'Anthony et Joe Russo', 'Robert Downey Jr., Chris Evans, Mark Ruffalo', 'Action, Science-Fiction', '2019', 'Après les événements dévastateurs d\'Avengers: Infinity War, les Avengers restants se rassemblent une fois de plus pour annuler les actions de Thanos et restaurer l\'ordre dans l\'univers.', 'images/film mcu/endgame.jpeg'),
(4, 'Star Wars, épisode I : La Menace fantôme', 'George Lucas', 'Liam Neeson, Ewan McGregor, Natalie Portman', 'Science-Fiction, Aventure', '1999', 'La République Galactique est en pleine ébullition. La Fédération du commerce a imposé un blocus à la petite planète Naboo. Deux chevaliers Jedi, Qui-Gon Jinn et Obi-Wan Kenobi, sont envoyés pour résoudre le conflit.', 'images/star wars/star wars 1.jpg'),
(5, 'Star Wars, épisode II : L\'Attaque des clones', 'George Lucas', 'Hayden Christensen, Ewan McGregor, Natalie Portman', 'Science-Fiction, Aventure', '2002', 'Dix ans ont passé. Un mouvement séparatiste menace la République. Obi-Wan Kenobi enquête sur une tentative d\'assassinat contre la sénatrice Padmé Amidala, tandis qu\'Anakin Skywalker est chargé de sa protection.', 'images/star wars/star wars 2.jpg'),
(6, 'Star Wars, épisode III : La Revanche des Sith', 'George Lucas', 'Hayden Christensen, Ewan McGregor, Ian McDiarmid', 'Science-Fiction, Action', '2005', 'La Guerre des Clones fait rage. Le chancelier Palpatine est kidnappé. Anakin Skywalker se rapproche dangereusement du côté obscur de la Force, menaçant l\'Ordre Jedi et la galaxie tout entière.', 'images/star wars/star wars 3.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `utilis`
--

CREATE TABLE `utilis` (
  `NumUtil` int(11) NOT NULL,
  `NomUtil` varchar(30) NOT NULL,
  `PrenomUtil` varchar(30) NOT NULL,
  `LoginUtil` varchar(200) NOT NULL,
  `PassUtil` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `utilis`
--

INSERT INTO `utilis` (`NumUtil`, `NomUtil`, `PrenomUtil`, `LoginUtil`, `PassUtil`) VALUES
(1, 'Alizan', 'Gaspar', 'galiz', 'azerty'),
(2, 'Diossy', 'Daisy', 'ddios', '12345'),
(3, 'matisse', 'kra', 'matisse.kra@gmail.com', '$2y$10$8uvGd9D1aG/08SyZWgGE6.sSR8v.NLUoLsRLO3UT4ERciDDthW7qy');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `films`
--
ALTER TABLE `films`
  ADD PRIMARY KEY (`id_film`);

--
-- Index pour la table `utilis`
--
ALTER TABLE `utilis`
  ADD PRIMARY KEY (`NumUtil`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `films`
--
ALTER TABLE `films`
  MODIFY `id_film` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `utilis`
--
ALTER TABLE `utilis`
  MODIFY `NumUtil` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
