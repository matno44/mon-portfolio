<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

if (isset($_POST['login']) && isset($_POST['mdp'])) {
    require 'fonctions.php';
    $bdd = getBdd();

    $login = $_POST['login'];
    $mdp   = $_POST['mdp'];

    // 1. On cherche d'abord si le login existe seul
    $reqLogin = 'SELECT * FROM utilis WHERE LoginUtil = ?';
    $resLogin = $bdd->prepare($reqLogin);
    $resLogin->execute(array($login));
    $utilisateur = $resLogin->fetch();

    if ($utilisateur) {
        // Le login existe, on vérifie maintenant le mot de passe
        if ($utilisateur['PassUtil'] == $mdp) {
            // Tout est bon
            $_SESSION['login']  = $login;
            $_SESSION['nom']    = $utilisateur['NomUtil'];
            $_SESSION['prenom'] = $utilisateur['PrenomUtil'];

            // REDIRECTION AUTOMATIQUE
            header('Location: index.php');
            exit();  // Toujours mettre un exit() après une redirection pour stopper le script
        } else {
            $erreur = 'Mot de passe incorrect.';
        }
    } else {
        $erreur = 'Login inconnu.';
    }
}
?>
<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Connexion</title>
    <link rel="stylesheet" type="text/css" href="css/login_styles.css">
</head>
<body>
    <header>
        <img src="images/DA site/logo.png" alt="logo">
        <h1>Stream Verse meilleur site de streaming.</h1>
    </header>

    
    
    <form action="login.php" method="post"> 
        <label for="Connexion"><h1>Connexion utilisateur</h1></label>
        <label for="login">login : </label>
        <input type="text" name="login" id="login" required /><br>

        <label for="mdp">Mot de passe : </label>
        <input type="password" name="mdp" id="mdp" required /><br>

        <input type="submit" value="Connexion">
        
        <?php if (isset($erreur)): ?>
        <p style="color: red;">Erreur : <?php echo $erreur; ?></p>
        <?php endif; ?>
        
        <input type="submit" value="s'inscrire" onclick="window.location.href='sign-up.php'; return false;">
    </form>
    
</body>
</html>