<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

if (isset($_POST['login']) && isset($_POST['mdp'])) {
    require 'fonctions.php';
    $bdd = getBdd();

    $login = $_POST['login'];
    $mdp   = $_POST['mdp'];

    // 1. On cherche d'abord si le login existe seul
    $reqLogin = 'SELECT * FROM utilis WHERE LoginUtil = ?';
    $resLogin = $bdd->prepare($reqLogin);
    $resLogin->execute(array($login));
    $utilisateur = $resLogin->fetch();

    if ($utilisateur) {
        // Le login existe, on vérifie maintenant le mot de passe
        if ($utilisateur['PassUtil'] == $mdp) {
            // Tout est bon
            $_SESSION['login']  = $login;
            $_SESSION['nom']    = $utilisateur['NomUtil'];
            $_SESSION['prenom'] = $utilisateur['PrenomUtil'];
            $authOK             = true;
        } else {
            // Login trouvé mais mauvais mot de passe
            $erreur = 'Mot de passe incorrect.';
        }
    } else {
        // Le login n'existe pas dans la base
        $erreur = 'Login inconnu.';
    }
}
?>

<!doctype html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Résultat de l'authentification</title>
</head>
<body>
    <h1>Résultat de l'authentification</h1>

    <?php if (isset($authOK)): ?>
        <p>Vous avez été reconnu(e) en tant que <?php echo escape($_SESSION['prenom']); ?></p>
        <a href="index.php">Poursuivre vers la page d'accueil</a>
    <?php else: ?>
        <p>Vous n'avez pas été reconnu(e)</p>
        <?php if (isset($erreur)): ?>
            <p style="color: red;">Erreur : <?php echo $erreur; ?></p>
        <?php endif; ?>
        <p><a href="login.php">Nouvel essai</a></p>
    <?php endif; ?>
</body>
</html>