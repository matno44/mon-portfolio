<?php
// fonctions.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

/**
 * Initialise la connexion à la base de données
 */
function getBdd()
{
    return new PDO('mysql:host=localhost;dbname=monsite;charset=utf8', 'monsite_util', 'secret',
                   array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
}

/**
 * Sécurise les données contre les injections XSS
 */
function escape($valeur)
{
    return htmlspecialchars($valeur, ENT_QUOTES, 'UTF-8', false);
}
?>