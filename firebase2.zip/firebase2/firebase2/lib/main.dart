import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

void main() => runApp(const InitializeApp());

class InitializeApp extends StatelessWidget {
  const InitializeApp({super.key});

  // Future créé une seule fois : Firebase n'est pas ré-initialisé à chaque build
  static final Future<FirebaseApp> _initialization = Firebase.initializeApp();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: _initialization,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return const ErrorFirebase();
        }
        if (snapshot.connectionState == ConnectionState.done) {
          return MyApp();
        }
        return const Loading();
      },
    );
  }
}

class ErrorFirebase extends StatelessWidget {
  const ErrorFirebase({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Container(
          color: Colors.white,
          child: const Center(child: Text('Erreur de chargement des données')),
        ),
      ),
    );
  }
}

class Loading extends StatelessWidget {
  const Loading({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Container(
          color: Colors.white,
          child: const Center(child: Text('Chargement')),
        ),
      ),
    );
  }
}

class MyApp extends StatelessWidget {
  MyApp({super.key});
  final databaseReference = FirebaseFirestore.instance;
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.amber),
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Firebase Todolist'),
          backgroundColor: Colors.blue,
        ),
        body: Column(
          children: [
            Center(
              child: ElevatedButton(
                onPressed: () {
                  addDataToFirebase();
                },
                child: const Text('Ajouter des données'),
              ),
            ),
            FormSection(),
            Expanded(child: ListSection()),
          ],
        ),
      ),
    );
  }

  void addDataToFirebase() {
    try {
      // Mêmes champs que FormSection.addItem() : text, time, done
      databaseReference
          .collection("items")
          .add({
            "text": "Lire un livre pendant 30 minutes",
            "time": DateFormat('HH:mm').format(DateTime.now()),
            "done": false,
          })
          .then((value) {
            debugPrint(value.id);
          });
    } catch (e) {
      debugPrint(e.toString());
    }
  }
}

class ListSection extends StatelessWidget {
  ListSection({super.key});
  final databaseReference = FirebaseFirestore.instance;
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: databaseReference.collection('items').snapshots(),
      builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text('Erreur : ${snapshot.error}'));
        }
        if (!snapshot.hasData) return const Text('Loading...');
        return ListView(
          children: snapshot.data!.docs.map((document) {
            // Lecture via data() avec valeurs par défaut : un document
            // auquel il manque un champ ne fait plus planter la liste
            // ("field does not exist")
            final data = document.data() as Map<String, dynamic>;
            final String text = data['text'] ?? '';
            final String time = data['time'] ?? '';
            final bool done = data['done'] ?? false;
            return CheckboxListTile(
              title: Text(
                text,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(time),
              value: done,
              activeColor: Colors.amber,
              secondary: IconButton(
                icon: Icon(
                  Icons.delete,
                  color: Colors.red.withValues(alpha: 0.6),
                ),
                onPressed: () {
                  deleteItem(document.id);
                },
              ),
              onChanged: (bool? value) {
                updateItem(document.id, value ?? false);
              },
            );
          }).toList(),
        );
      },
    );
  }

  void deleteItem(String itemID) {
    databaseReference.collection("items").doc(itemID).delete();
  }

  void updateItem(String itemID, bool itemDone) {
    databaseReference.collection("items").doc(itemID).update({
      "done": itemDone,
    });
  }
}

class FormSection extends StatelessWidget {
  FormSection({super.key});
  final databaseReference = FirebaseFirestore.instance;
  final myController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      margin: const EdgeInsets.only(bottom: 10),
      color: Colors.grey.withValues(alpha: 0.1),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: myController,
              decoration: const InputDecoration(
                hintText: 'Entrez une nouvelle tâche',
              ),
            ),
          ),
          Container(
            margin: const EdgeInsets.fromLTRB(20, 0, 0, 0),
            width: 45,
            height: 45,
            decoration: BoxDecoration(
              color: Colors.orange,
              borderRadius: BorderRadius.circular(5),
            ),
            child: IconButton(
              icon: const Icon(Icons.add, color: Colors.white),
              onPressed: () {
                addItem();
              },
            ),
          ),
        ],
      ),
    );
  }

  void addItem() {
    final text = myController.text.trim();
    if (text.isEmpty) return; // pas de tâche vide
    try {
      var now = DateTime.now();
      var hourAndMinutes = DateFormat('HH:mm');
      databaseReference
          .collection("items")
          .add({
            "text": text,
            "time": hourAndMinutes.format(now),
            "done": false,
          })
          .then((value) {
            debugPrint(value.id);
            myController.clear();
          });
    } catch (e) {
      debugPrint(e.toString());
    }
  }
}
