CREATE OR REPLACE function creer_user_client() RETURNS INTEGER
LANGUAGE plpgsql
AS
$function$
DECLARE
    v_compteur INTEGER := 0;
    res client%ROWTYPE;
    v_existe INTEGER; 
BEGIN
    FOR res IN SELECT * FROM client LOOP
        SELECT COUNT(*) INTO v_existe FROM pg_user WHERE usename = res.identifiant_internet;
        IF v_existe = 0 THEN
            EXECUTE 'CREATE ROLE ' || res.identifiant_internet || ' WITH LOGIN PASSWORD ''' || res.mdp_internet || '''';
            v_compteur := v_compteur + 1;
        END IF;   
    END LOOP;
    RETURN v_compteur;
END;
$function$;
