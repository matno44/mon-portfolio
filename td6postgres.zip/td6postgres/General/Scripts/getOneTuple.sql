CREATE OR REPLACE FUNCTION lesClients() RETURNS SETOF client
LANGUAGE plpgsql
AS $function$
declare
res client%ROWTYPE ;
begin
for res in select * from client
loop
return next res ;
end loop;
return;
end ;
$function$ ;