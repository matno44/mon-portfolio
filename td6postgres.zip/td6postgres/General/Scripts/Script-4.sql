CREATE OR REPLACE FUNCTION getCountryClient(ville Varchar) RETURNS INTEGER
LANGUAGE plpgsql
AS
$function$
declare
v_nombre INTEGER ;
begin
select COUNT(*) INTO v_nombre FROM client 
WHERE adresse_client ILIKE '%' || ville || '%';
RETURN v_nombre;
end;
$function$ ;