--DROP SCHEMA public;

--CREATE SCHEMA public AUTHORIZATION pg_database_owner;

COMMENT ON SCHEMA public IS 'standard public schema';
-- public.agence definition

-- Drop table

-- DROP TABLE public.agence;

CREATE TABLE public.agence ( num_agence int4 NOT NULL, nom_agence varchar(50) NULL, adresse_agence varchar(192) NULL, tel_agence bpchar(10) NULL, CONSTRAINT agence_num_agence_not_null NOT NULL num_agence, CONSTRAINT pk_agence PRIMARY KEY (num_agence));

-- Permissions

ALTER TABLE public.agence OWNER TO devakwabanm;
GRANT ALL ON TABLE public.agence TO devakwabanm;


-- public.client definition

-- Drop table

-- DROP TABLE public.client;

CREATE TABLE public.client ( num_client int4 NOT NULL, nom_client varchar(30) NULL, prenom_client varchar(30) NULL, adresse_client varchar(192) NULL, identifiant_internet varchar(30) NULL, mdp_internet varchar(30) NULL, CONSTRAINT client_num_client_not_null NOT NULL num_client, CONSTRAINT pk_client PRIMARY KEY (num_client));

-- Permissions

ALTER TABLE public.client OWNER TO devakwabanm;
GRANT ALL ON TABLE public.client TO devakwabanm;


-- public."date" definition

-- Drop table

-- DROP TABLE public."date";

CREATE TABLE public."date" ( "date" date NOT NULL, CONSTRAINT date_date_not_null NOT NULL date, CONSTRAINT pk_date PRIMARY KEY (date));

-- Permissions

ALTER TABLE public."date" OWNER TO devakwabanm;
GRANT ALL ON TABLE public."date" TO devakwabanm;


-- public.type_compte definition

-- Drop table

-- DROP TABLE public.type_compte;

CREATE TABLE public.type_compte ( id_type int2 NOT NULL, designation varchar(50) NULL, CONSTRAINT pk_type_compte PRIMARY KEY (id_type), CONSTRAINT type_compte_id_type_not_null NOT NULL id_type);

-- Permissions

ALTER TABLE public.type_compte OWNER TO devakwabanm;
GRANT ALL ON TABLE public.type_compte TO devakwabanm;


-- public.affecter definition

-- Drop table

-- DROP TABLE public.affecter;

CREATE TABLE public.affecter ( num_client int4 NOT NULL, "date" date NOT NULL, num_agence int4 NULL, CONSTRAINT affecter_date_not_null NOT NULL date, CONSTRAINT affecter_num_client_not_null NOT NULL num_client, CONSTRAINT pk_affecter PRIMARY KEY (num_client, date), CONSTRAINT fk_affecter_agence FOREIGN KEY (num_agence) REFERENCES public.agence(num_agence), CONSTRAINT fk_affecter_client FOREIGN KEY (num_client) REFERENCES public.client(num_client), CONSTRAINT fk_affecter_date FOREIGN KEY ("date") REFERENCES public."date"("date"));
CREATE INDEX i_fk_affecter_agence ON public.affecter USING btree (num_agence);
CREATE INDEX i_fk_affecter_client ON public.affecter USING btree (num_client);
CREATE INDEX i_fk_affecter_date ON public.affecter USING btree (date);

-- Permissions

ALTER TABLE public.affecter OWNER TO devakwabanm;
GRANT ALL ON TABLE public.affecter TO devakwabanm;


-- public.compte definition

-- Drop table

-- DROP TABLE public.compte;

CREATE TABLE public.compte ( id_type int2 NOT NULL, num_compte int4 NOT NULL, date_fermer date NULL, date_ouvrir date NOT NULL, solde int4 NULL, CONSTRAINT compte_date_ouvrir_not_null NOT NULL date_ouvrir, CONSTRAINT compte_id_type_not_null NOT NULL id_type, CONSTRAINT compte_num_compte_not_null NOT NULL num_compte, CONSTRAINT pk_compte PRIMARY KEY (id_type, num_compte), CONSTRAINT fk_compte_date FOREIGN KEY (date_fermer) REFERENCES public."date"("date"), CONSTRAINT fk_compte_date2 FOREIGN KEY (date_ouvrir) REFERENCES public."date"("date"), CONSTRAINT fk_compte_type_compte FOREIGN KEY (id_type) REFERENCES public.type_compte(id_type));
CREATE INDEX i_fk_compte_date ON public.compte USING btree (date_fermer);
CREATE INDEX i_fk_compte_date2 ON public.compte USING btree (date_ouvrir);
CREATE INDEX i_fk_compte_type_compte ON public.compte USING btree (id_type);

-- Permissions

ALTER TABLE public.compte OWNER TO devakwabanm;
GRANT ALL ON TABLE public.compte TO devakwabanm;


-- public.operation definition

-- Drop table

-- DROP TABLE public.operation;

CREATE TABLE public.operation ( id_operation int8 NOT NULL, num_compte int4 NOT NULL, "date" date NOT NULL, id_type int2 NOT NULL, id_type_vers int2 NULL, num_compte_vers int4 NULL, designation varchar(50) NULL, type_operation varchar(20) NULL, montant int4 NULL, CONSTRAINT operation_date_not_null NOT NULL date, CONSTRAINT operation_id_operation_not_null NOT NULL id_operation, CONSTRAINT operation_id_type_not_null NOT NULL id_type, CONSTRAINT operation_num_compte_not_null NOT NULL num_compte, CONSTRAINT pk_operation PRIMARY KEY (id_operation), CONSTRAINT fk_operation_compte FOREIGN KEY (id_type,num_compte) REFERENCES public.compte(id_type,num_compte), CONSTRAINT fk_operation_compte1 FOREIGN KEY (id_type_vers,num_compte_vers) REFERENCES public.compte(id_type,num_compte), CONSTRAINT fk_operation_date FOREIGN KEY ("date") REFERENCES public."date"("date"));
CREATE INDEX i_fk_operation_compte ON public.operation USING btree (id_type, num_compte);
CREATE INDEX i_fk_operation_compte1 ON public.operation USING btree (id_type_vers, num_compte_vers);
CREATE INDEX i_fk_operation_date ON public.operation USING btree (date);

-- Permissions

ALTER TABLE public.operation OWNER TO devakwabanm;
GRANT ALL ON TABLE public.operation TO devakwabanm;


-- public.posseder definition

-- Drop table

-- DROP TABLE public.posseder;

CREATE TABLE public.posseder ( num_client int4 NOT NULL, id_type int2 NOT NULL, num_compte int4 NOT NULL, CONSTRAINT pk_posseder PRIMARY KEY (num_client, id_type, num_compte), CONSTRAINT posseder_id_type_not_null NOT NULL id_type, CONSTRAINT posseder_num_client_not_null NOT NULL num_client, CONSTRAINT posseder_num_compte_not_null NOT NULL num_compte, CONSTRAINT fk_posseder_client FOREIGN KEY (num_client) REFERENCES public.client(num_client), CONSTRAINT fk_posseder_compte FOREIGN KEY (id_type,num_compte) REFERENCES public.compte(id_type,num_compte));
CREATE INDEX i_fk_posseder_client ON public.posseder USING btree (num_client);
CREATE INDEX i_fk_posseder_compte ON public.posseder USING btree (id_type, num_compte);

-- Permissions

ALTER TABLE public.posseder OWNER TO devakwabanm;
GRANT ALL ON TABLE public.posseder TO devakwabanm;


-- public.remunerer definition

-- Drop table

-- DROP TABLE public.remunerer;

CREATE TABLE public.remunerer ( "date" date NOT NULL, date_de date NOT NULL, id_type int2 NOT NULL, taux_interet int4 NULL, CONSTRAINT pk_remunerer PRIMARY KEY (date, date_de, id_type), CONSTRAINT remunerer_date_de_not_null NOT NULL date_de, CONSTRAINT remunerer_date_not_null NOT NULL date, CONSTRAINT remunerer_id_type_not_null NOT NULL id_type, CONSTRAINT fk_remunerer_date FOREIGN KEY ("date") REFERENCES public."date"("date"), CONSTRAINT fk_remunerer_date1 FOREIGN KEY (date_de) REFERENCES public."date"("date"), CONSTRAINT fk_remunerer_type_compte FOREIGN KEY (id_type) REFERENCES public.type_compte(id_type));
CREATE INDEX i_fk_remunerer_date ON public.remunerer USING btree (date);
CREATE INDEX i_fk_remunerer_date1 ON public.remunerer USING btree (date_de);
CREATE INDEX i_fk_remunerer_type_compte ON public.remunerer USING btree (id_type);

-- Permissions

ALTER TABLE public.remunerer OWNER TO devakwabanm;
GRANT ALL ON TABLE public.remunerer TO devakwabanm;



-- DROP FUNCTION public.get_nb_clients_debiteurs();

CREATE OR REPLACE FUNCTION public.get_nb_clients_debiteurs()
 RETURNS integer
 LANGUAGE plpgsql
AS $function$
DECLARE
    
    nb_debiteurs INTEGER;
BEGIN
    
    SELECT COUNT(DISTINCT client.num_client) INTO nb_debiteurs
    FROM client
    
    INNER JOIN posseder ON client.num_client = posseder.num_client
  
    INNER JOIN compte ON posseder.id_type = compte.id_type AND posseder.num_compte = compte.num_compte
    
    WHERE compte.solde < 0 
    AND date_part('year', compte.date_ouvrir) = 2012;

    RETURN nb_debiteurs;
END;
$function$
;

-- Permissions

ALTER FUNCTION public.get_nb_clients_debiteurs() OWNER TO devakwabanm;
GRANT ALL ON FUNCTION public.get_nb_clients_debiteurs() TO devakwabanm;

-- DROP FUNCTION public.inserer_client(varchar, varchar, varchar, varchar, varchar);

CREATE OR REPLACE FUNCTION public.inserer_client(p_nom character varying, p_prenom character varying, p_adresse character varying, p_identifiant character varying, p_mdp character varying)
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
DECLARE
    nouveau_num_client INTEGER;
BEGIN
    -- 1. On cherche le plus grand numéro actuel et on ajoute 1
    -- (La fonction COALESCE permet de renvoyer 0 si la table est complètement vide)
    SELECT COALESCE(MAX(num_client), 0) + 1 INTO nouveau_num_client 
    FROM client;

    -- 2. On insère le nouveau client avec le numéro calculé
    INSERT INTO client (num_client, nom_client, prenom_client, adresse_client, identifiant_internet, mdp_internet)
    VALUES (nouveau_num_client, p_nom, p_prenom, p_adresse, p_identifiant, p_mdp);

    -- 3. Si on arrive ici, c'est que l'insertion a fonctionné
    RETURN 'Succès : Client ' || p_nom || ' enregistré avec le numéro ' || nouveau_num_client;

-- 4. En cas de problème lors de l'insertion, on capture l'erreur
EXCEPTION WHEN OTHERS THEN
    RETURN 'Échec : Impossible d''enregistrer le client.';
END;
$function$
;

-- Permissions

ALTER FUNCTION public.inserer_client(varchar, varchar, varchar, varchar, varchar) OWNER TO devakwabanm;
GRANT ALL ON FUNCTION public.inserer_client(varchar, varchar, varchar, varchar, varchar) TO devakwabanm;


-- Permissions

GRANT ALL ON SCHEMA public TO pg_database_owner;
GRANT ALL ON SCHEMA public TO devakwabanm;
GRANT ALL ON SCHEMA public TO public;