<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Création d'utilisateur</title>
    </head>
    <body>
        <?php

        require_once 'utilisateur.php';

        if (!empty($_POST)) {
            $login  = $_POST['login'];
            $nom    = $_POST['nom'];
            $prenom = $_POST['prenom'];

            $monUtilisateur = new Utilisateur($login, $nom, $prenom);

            echo '<h2>Utilisateur créé avec succès (via POST) :</h2>';
            $monUtilisateur->afficher();
        } else {
            echo '<h2>Aucune donnée reçue (POST vide)</h2>';
        }
        ?>
    </body>
</html>
