<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title> Mon premier php </title>
    </head>
   
    <body>
        <?php
        require_once 'voiture.php';
        $voiture1 = new Voiture('Renault', 'rouge', 'AB-123-CD');
        $voiture1->afficher();
        ?>
    </body>
</html>