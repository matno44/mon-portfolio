<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title> Mon premier php </title>
    </head>
   
    <body>
        Voici le résultat du script PHP : 
        <?php

        // 1. Création d'une liste de voitures (tableau indexé par des entiers contenant des tableaux associatifs)
        $voitures = array(
            array(
                'marque'          => 'Peugeot',
                'couleur'         => 'bleu',
                'immatriculation' => 'AB-123-CD'
            ),
            array(
                'marque'          => 'Renault',
                'couleur'         => 'rouge',
                'immatriculation' => 'EF-456-GH'
            )
        );

        // 3. Affichage HTML de la liste
        echo '<h2>Liste des voitures :</h2>';

        // 4. Test si le tableau est vide et affichage conditionnel
        if (empty($voitures)) {
            echo '<p>Il n’y a aucune voiture.</p>';
        } else {
            echo '<ul>';
            foreach ($voitures as $v) {
                echo '<li>Voiture ' . $v['immatriculation'] . ' de marque ' . $v['marque'] . ' (couleur ' . $v['couleur'] . ')</li>';
            }
            echo '</ul>';
        }
        ?>
        

        
    </body>
</html> 
