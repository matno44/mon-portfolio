<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Création de voiture</title>
    </head>
    <body>
        <?php
        // On inclut la définition de la classe Voiture
        require_once 'voiture.php';

        // On vérifie que le tableau $_POST n'est pas vide
        if (!empty($_POST)) {
            // Récupération des paramètres du corps de la requête HTTP
            $immatriculation = $_POST['immatriculation'];
            $marque          = $_POST['marque'];
            $couleur         = $_POST['couleur'];

            $maVoiture = new Voiture($marque, $couleur, $immatriculation);

            echo '<h2>Voiture créée avec succès (via POST) :</h2>';
            $maVoiture->afficher();
        } else {
            echo '<h2>Aucune donnée reçue (POST vide)</h2>';
        }
        ?>
    </body>
</html>
