<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Création de trajet</title>
    </head>
    <body>
        <?php

        require_once 'trajet.php';

        if (!empty($_POST)) {
            $depart           = $_POST['depart'];
            $arrivee          = $_POST['arrivee'];
            $date             = $_POST['date'];
            $nbplaces         = $_POST['nbplaces'];
            $prix             = $_POST['prix'];
            $conducteur_login = $_POST['conducteur_login'];

            $monTrajet = new Trajet([
                                        'depart'           => $depart,
                                        'arrivee'          => $arrivee,
                                        'date'             => $date,
                                        'nbplaces'         => $nbplaces,
                                        'prix'             => $prix,
                                        'conducteur_login' => $conducteur_login
                                    ]);

            echo '<h2>Trajet créé avec succès (via POST) :</h2>';
            $monTrajet->afficher();
        } else {
            echo '<h2>Aucune donnée reçue (POST vide)</h2>';
        }
        ?>
        <form method="post" action="formulaireTrajet.html">
            <p>
                <input type="submit" value="créer un nouveau trajet" />
            </p>
        </form>
    </body>
</html>
