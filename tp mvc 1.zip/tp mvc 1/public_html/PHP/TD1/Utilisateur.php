<?php
class Utilisateur
{
    private $login;
    private $nom;
    private $prenom;

    public function __construct($login, $nom, $prenom)
    {
        $this->login  = $login;
        $this->nom    = $nom;
        $this->prenom = $prenom;
    }

    public function afficher()
    {
        echo 'Login: ' . $this->login . '<br>';
        echo 'Nom: ' . $this->nom . '<br>';
        echo 'Prénom: ' . $this->prenom . '<br>';
    }
}

?>
